import csv
import os
from typing import Dict, Optional
from datetime import datetime


class PricingManager:
    """
    Manages AWS resource pricing by reading from CSV files.
    
    Supports:
    - EC2 instances from Amazon_EC2_Instance_Comparison.csv
    - RDS instances from Amazon_RDS_Instance_Comparison.csv
    """
    
    def __init__(self, csv_directory: str = None):
        """
        Initialize the pricing manager.

        Args:
            csv_directory: Directory containing the CSV files. If None, uses 'data' subdirectory.
        """
        if csv_directory is None:
            # Default to 'data' subdirectory relative to project root
            script_dir = os.path.dirname(os.path.abspath(__file__))
            project_root = os.path.dirname(script_dir)  # Go up one level from src/
            csv_directory = os.path.join(project_root, 'data')
        self.csv_directory = csv_directory
        self.ec2_pricing = {}
        self.rds_pricing = {}
        self.last_loaded = None
        
        # CSV file paths
        self.ec2_csv_path = os.path.join(self.csv_directory, "Amazon EC2 Instance Comparison.csv")
        self.rds_csv_path = os.path.join(self.csv_directory, "Amazon RDS Instance Comparison.csv")
        
        # Load pricing data
        self._load_pricing_data()
    
    def _load_pricing_data(self):
        """Load pricing data from CSV files."""
        try:
            self._load_ec2_pricing()
            self._load_rds_pricing()
            self.last_loaded = datetime.now()
            print(f"Loaded pricing data: {len(self.ec2_pricing)} EC2 types, {len(self.rds_pricing)} RDS types")
        except Exception as e:
            print(f"WARNING: Error loading pricing data: {e}")
            self._load_fallback_pricing()
    
    def _load_ec2_pricing(self):
        """Load EC2 pricing from CSV file."""
        if not os.path.exists(self.ec2_csv_path):
            print(f"WARNING: EC2 CSV file not found: {self.ec2_csv_path}")
            return
        
        try:
            with open(self.ec2_csv_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    api_name = row.get('API Name', '').strip()
                    hourly_price = row.get('On Demand', '').strip()
                    
                    if api_name and hourly_price and hourly_price != 'unavailable':
                        # Parse hourly price (format: "$0.0110 hourly")
                        try:
                            price_value = float(hourly_price.replace('$', '').replace(' hourly', ''))
                            # Convert to monthly (hours per month = 24 * 30.44)
                            monthly_price = price_value * 24 * 30.44
                            self.ec2_pricing[api_name] = monthly_price
                        except ValueError:
                            continue
        
        except Exception as e:
            print(f"WARNING: Error reading EC2 CSV: {e}")
    
    def _load_rds_pricing(self):
        """Load RDS pricing from CSV file."""
        if not os.path.exists(self.rds_csv_path):
            print(f"WARNING: RDS CSV file not found: {self.rds_csv_path}")
            return
        
        try:
            with open(self.rds_csv_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    api_name = row.get('API Name', '').strip()
                    
                    # Try different RDS pricing columns (PostgreSQL is most common)
                    price_columns = [
                        'PostgreSQL', 'MySQL On Demand Cost', 'Aurora Postgres & MySQL On Demand Cost',
                        'MariaDB On Demand Cost'
                    ]
                    
                    hourly_price = None
                    for col in price_columns:
                        price_val = row.get(col, '').strip()
                        if price_val and price_val != 'unavailable':
                            hourly_price = price_val
                            break
                    
                    if api_name and hourly_price:
                        try:
                            # Parse hourly price (format: "$0.0230 hourly")
                            price_value = float(hourly_price.replace('$', '').replace(' hourly', ''))
                            # Convert to monthly
                            monthly_price = price_value * 24 * 30.44
                            self.rds_pricing[api_name] = monthly_price
                        except ValueError:
                            continue
        
        except Exception as e:
            print(f"WARNING: Error reading RDS CSV: {e}")
    
    def _load_fallback_pricing(self):
        """Load fallback pricing if CSV files fail."""
        print("Using fallback pricing data...")
        
        # Basic EC2 fallback pricing (monthly USD)
        self.ec2_pricing = {
            't3.micro': 7.96, 't3.small': 15.94, 't3.medium': 31.94,
            't3.large': 63.89, 't3.xlarge': 127.77, 't3.2xlarge': 255.55,
            't4g.micro': 6.08, 't4g.small': 12.16, 't4g.medium': 24.33,
            't4g.large': 48.65, 't4g.xlarge': 97.31, 't4g.2xlarge': 194.62,
            'm5.large': 73.87, 'm5.xlarge': 147.83, 'm5.2xlarge': 295.57,
            'c5.large': 65.18, 'c5.xlarge': 130.44, 'c5.2xlarge': 261.20,
            'r5.large': 97.02, 'r5.xlarge': 193.34, 'r5.2xlarge': 386.90,
        }
        
        # Basic RDS fallback pricing (monthly USD)
        self.rds_pricing = {
            'db.t3.micro': 15.33, 'db.t3.small': 30.66, 'db.t3.medium': 61.32,
            'db.t3.large': 122.64, 'db.t3.xlarge': 245.28,
            'db.m5.large': 147.74, 'db.m5.xlarge': 295.47,
            'db.r5.large': 194.04, 'db.r5.xlarge': 388.08,
        }
    
    def get_ec2_cost(self, instance_type: str) -> float:
        """
        Get monthly cost for an EC2 instance type.
        
        Args:
            instance_type: EC2 instance type (e.g., 't3.medium')
        
        Returns:
            Monthly cost in USD
        """
        cost = self.ec2_pricing.get(instance_type)
        if cost is None:
            print(f"WARNING: No pricing data for EC2 instance {instance_type}, using default $50")
            return 50.0
        return cost
    
    def get_rds_cost(self, instance_type: str) -> float:
        """
        Get monthly cost for an RDS instance type.
        
        Args:
            instance_type: RDS instance type (e.g., 'db.t3.medium')
        
        Returns:
            Monthly cost in USD
        """
        cost = self.rds_pricing.get(instance_type)
        if cost is None:
            print(f"WARNING: No pricing data for RDS instance {instance_type}, using default $100")
            return 100.0
        return cost
    
    def get_resource_cost(self, resource_type: str, resource_id: str, region: str = None) -> float:
        """
        Get monthly cost for any AWS resource.
        
        Args:
            resource_type: Type of resource ('ec2', 'rds', etc.)
            resource_id: Resource identifier (instance type for EC2/RDS)
            region: AWS region (not used for pricing, kept for compatibility)
        
        Returns:
            Monthly cost in USD
        """
        if resource_type == 'ec2':
            return self.get_ec2_cost(resource_id)
        elif resource_type == 'rds':
            return self.get_rds_cost(resource_id)
        else:
            # Other resource types with fixed costs
            other_costs = {
                'ebs_volume': 0.10,  # per GB per month
                'elastic_ip': 3.65,  # per month when unassociated
                'nat_gateway': 32.85,  # per month (base cost)
                'load_balancer': 16.43,  # ALB per month
                'classic_load_balancer': 18.25,  # CLB per month
                'kms_key': 1.00,  # per month
                'ebs_snapshot': 0.048,  # per GB per month
            }
            return other_costs.get(resource_type, 10.0)  # Default fallback
    
    def refresh_pricing(self):
        """Refresh pricing data from CSV files."""
        print("Refreshing pricing data...")
        self.ec2_pricing.clear()
        self.rds_pricing.clear()
        self._load_pricing_data()
    
    def get_pricing_stats(self) -> Dict:
        """Get statistics about loaded pricing data."""
        return {
            'ec2_instances': len(self.ec2_pricing),
            'rds_instances': len(self.rds_pricing),
            'last_loaded': self.last_loaded.isoformat() if self.last_loaded else None,
            'ec2_csv_exists': os.path.exists(self.ec2_csv_path),
            'rds_csv_exists': os.path.exists(self.rds_csv_path)
        }
    
    def list_available_instance_types(self, resource_type: str = None) -> Dict:
        """List all available instance types and their costs."""
        result = {}
        
        if resource_type is None or resource_type == 'ec2':
            result['ec2'] = dict(sorted(self.ec2_pricing.items()))
        
        if resource_type is None or resource_type == 'rds':
            result['rds'] = dict(sorted(self.rds_pricing.items()))
        
        return result


# Global instance for easy import
pricing_manager = PricingManager()