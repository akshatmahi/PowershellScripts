#!/usr/bin/env python3
"""
AWS Profile Manager
Handles AWS profile discovery, validation, and session management
"""

import boto3
import configparser
import os
from typing import Dict, List, Optional
from dataclasses import dataclass
from botocore.exceptions import NoCredentialsError, ClientError, ProfileNotFound

@dataclass
class ProfileInfo:
    name: str
    display_name: str
    account_id: Optional[str] = None
    region: Optional[str] = None
    role_arn: Optional[str] = None
    is_sso: bool = False

class AWSProfileManager:
    """Manages AWS profiles and authentication"""
    
    def __init__(self):
        self.profiles: List[ProfileInfo] = []
        self._discover_profiles()
    
    def _discover_profiles(self):
        """Discover available AWS profiles from credentials and config files"""
        credentials_path = os.path.expanduser('~/.aws/credentials')
        config_path = os.path.expanduser('~/.aws/config')
        
        profiles = set()
        
        # Parse credentials file
        if os.path.exists(credentials_path):
            creds_config = configparser.ConfigParser()
            creds_config.read(credentials_path)
            profiles.update(creds_config.sections())
        
        # Parse config file
        if os.path.exists(config_path):
            aws_config = configparser.ConfigParser()
            aws_config.read(config_path)
            for section in aws_config.sections():
                if section.startswith('profile '):
                    profiles.add(section.replace('profile ', ''))
                elif section == 'default':
                    profiles.add('default')
        
        # Also try to get profiles from boto3
        try:
            session = boto3.Session()
            available_profiles = session.available_profiles
            profiles.update(available_profiles)
        except Exception:
            pass
        
        # Ensure we have at least a default profile
        if not profiles:
            profiles.add('default')
        
        # Create ProfileInfo objects
        for profile_name in sorted(profiles):
            profile_info = self._get_profile_info(profile_name)
            if profile_info:
                self.profiles.append(profile_info)
    
    def _get_profile_info(self, profile_name: str) -> Optional[ProfileInfo]:
        """Get detailed information about a profile"""
        display_name = profile_name
        account_id = None
        region = None
        role_arn = None
        is_sso = False
        
        try:
            session = boto3.Session(profile_name=profile_name if profile_name != 'default' else None)
            
            # Get default region from session or config
            region = session.region_name or 'us-east-1'
            
            # Check if it's an SSO profile first (no network call needed)
            config_path = os.path.expanduser('~/.aws/config')
            if os.path.exists(config_path):
                aws_config = configparser.ConfigParser()
                aws_config.read(config_path)
                section_name = f'profile {profile_name}' if profile_name != 'default' else 'default'
                if section_name in aws_config.sections():
                    section = aws_config[section_name]
                    if 'sso_start_url' in section or 'sso_session' in section:
                        is_sso = True
                        # For SSO profiles, don't try to validate immediately
                        display_name = f"{profile_name} (SSO - validation deferred)"
                        return ProfileInfo(
                            name=profile_name,
                            display_name=display_name,
                            account_id=None,  # Will be validated later when actually used
                            region=region,
                            role_arn=role_arn,
                            is_sso=is_sso
                        )
            
            # Only try to validate credentials for non-SSO profiles, and with timeout
            if not is_sso:
                try:
                    # Set shorter timeout for faster failure on network issues
                    import botocore.config
                    config = botocore.config.Config(
                        connect_timeout=5,
                        read_timeout=5,
                        retries={'max_attempts': 1}
                    )
                    sts = session.client('sts', region_name='us-east-1', config=config)
                    identity = sts.get_caller_identity()
                    account_id = identity.get('Account')
                    
                    # Extract role info if present
                    arn = identity.get('Arn', '')
                    if 'assumed-role' in arn:
                        role_arn = arn
                        
                    # Create display name with account info
                    if account_id:
                        display_name = f"{profile_name} ({account_id})"
                        
                except Exception as e:
                    # Network or credential issues - still return profile but mark as unvalidated
                    if 'SSL' in str(e) or 'timeout' in str(e).lower() or 'network' in str(e).lower():
                        display_name = f"{profile_name} (network issue - validation deferred)"
                    else:
                        error_msg = str(e)[:30] + "..." if len(str(e)) > 30 else str(e)
                        display_name = f"{profile_name} (⚠️ {error_msg})"
            
        except Exception as e:
            # Profile configuration issues
            error_msg = str(e)[:30] + "..." if len(str(e)) > 30 else str(e)
            display_name = f"{profile_name} (config error)"
        
        return ProfileInfo(
            name=profile_name,
            display_name=display_name,
            account_id=account_id,
            region=region,
            role_arn=role_arn,
            is_sso=is_sso
        )
    
    def get_available_profiles(self) -> List[ProfileInfo]:
        """Get list of available profiles"""
        return self.profiles
    
    def get_accessible_profiles(self) -> List[ProfileInfo]:
        """Get list of accessible profiles (those we can authenticate with)"""
        # Include SSO profiles and profiles with deferred validation as potentially accessible
        return [p for p in self.profiles if (
            p.account_id is not None or 
            p.is_sso or 
            "validation deferred" in p.display_name.lower()
        )]
    
    def validate_profile(self, profile_name: str) -> bool:
        """Validate that a profile exists and is accessible"""
        for profile in self.profiles:
            if profile.name == profile_name:
                # Accept profiles with deferred validation or SSO profiles
                return (profile.account_id is not None or 
                       profile.is_sso or 
                       "validation deferred" in profile.display_name.lower())
        return False
    
    def create_session(self, profile_name: str, region: str = None) -> boto3.Session:
        """Create a boto3 session for the specified profile"""
        try:
            if profile_name == 'default' or profile_name is None:
                return boto3.Session(region_name=region)
            else:
                return boto3.Session(profile_name=profile_name, region_name=region)
        except ProfileNotFound:
            raise ValueError(f"Profile '{profile_name}' not found")
        except NoCredentialsError:
            raise ValueError(f"No credentials available for profile '{profile_name}'")
    
    def interactive_profile_selection(self, allow_multiple: bool = True) -> List[str]:
        """Interactive profile selection similar to PowerShell implementation"""
        accessible_profiles = self.get_accessible_profiles()
        
        if not accessible_profiles:
            print("ERROR: No accessible AWS profiles found.")
            print("   Please configure AWS credentials using one of these methods:")
            print("   - aws configure (for default profile)")
            print("   - aws configure --profile <name> (for named profiles)")
            print("   - Set environment variables (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY)")
            print("   - Use IAM roles (on EC2 instances)")
            raise ValueError("No accessible AWS profiles found. Please configure AWS CLI profiles first.")
        
        print("\nAvailable AWS profiles:")
        for i, profile in enumerate(accessible_profiles, 1):
            status = "[OK]" if profile.account_id else "[!]"
            sso_indicator = "[SSO]" if profile.is_sso else ""
            print(f"  {i}. {status} {profile.display_name} {sso_indicator}")
        
        print("\nSelection options:")
        if allow_multiple:
            print("  - Enter 'all' to analyze all accessible profiles")
            print("  - Enter numbers separated by commas (e.g., 1,3,5)")
            print("  - Enter a single number for one profile")
        else:
            print("  - Enter a single number to select a profile")
        
        while True:
            choice = input("\nYour selection: ").strip()
            
            if not choice:
                print("ERROR: Please enter a valid selection.")
                continue
            
            if choice.lower() == 'all' and allow_multiple:
                selected_names = [p.name for p in accessible_profiles]
                print(f"Selected all profiles: {', '.join([p.display_name for p in accessible_profiles])}")
                return selected_names
            
            try:
                if ',' in choice:
                    # Multiple selections
                    if not allow_multiple:
                        print("ERROR: Multiple selections not allowed. Please enter a single number.")
                        continue
                    
                    numbers = [int(n.strip()) for n in choice.split(',')]
                    selected_profiles = []
                    selected_display = []
                    
                    for num in numbers:
                        if 1 <= num <= len(accessible_profiles):
                            profile = accessible_profiles[num - 1]
                            selected_profiles.append(profile.name)
                            selected_display.append(profile.display_name)
                        else:
                            print(f"ERROR: Invalid selection: {num}. Please use numbers 1-{len(accessible_profiles)}.")
                            selected_profiles = []
                            break
                    
                    if selected_profiles:
                        print(f"Selected profiles: {', '.join(selected_display)}")
                        return selected_profiles
                
                else:
                    # Single selection
                    num = int(choice)
                    if 1 <= num <= len(accessible_profiles):
                        profile = accessible_profiles[num - 1]
                        print(f"Selected profile: {profile.display_name}")
                        return [profile.name]
                    else:
                        print(f"ERROR: Invalid selection: {num}. Please use numbers 1-{len(accessible_profiles)}.")
            
            except ValueError:
                print("ERROR: Invalid input. Please enter numbers or 'all'.")
    
    def get_profile_info_by_name(self, profile_name: str) -> Optional[ProfileInfo]:
        """Get profile info by name"""
        for profile in self.profiles:
            if profile.name == profile_name:
                return profile
        return None
    
    def interactive_region_selection(self, default_regions: List[str] = None) -> List[str]:
        """Interactive AWS region selection"""
        
        # Common AWS regions with descriptions
        common_regions = [
            ("us-east-1", "US East (N. Virginia)"),
            ("us-west-2", "US West (Oregon)"),
            ("us-west-1", "US West (N. California)"),
            ("eu-west-1", "Europe (Ireland)"),
            ("eu-west-2", "Europe (London)"),
            ("eu-central-1", "Europe (Frankfurt)"),
            ("ap-southeast-1", "Asia Pacific (Singapore)"),
            ("ap-southeast-2", "Asia Pacific (Sydney)"),
            ("ap-northeast-1", "Asia Pacific (Tokyo)"),
            ("ca-central-1", "Canada (Central)"),
            ("sa-east-1", "South America (São Paulo)")
        ]
        
        default_regions = default_regions or ["us-east-1", "us-west-2"]
        
        print("\nAWS Region Selection:")
        print("Select regions to analyze for cost optimization opportunities.")
        print()
        
        for i, (region, description) in enumerate(common_regions, 1):
            selected_indicator = "[*]" if region in default_regions else "   "
            print(f"  {i:2d}. {selected_indicator} {region:15} ({description})")
        
        print()
        print("Selection options:")
        print("  - Enter 'all' to analyze all regions (slower)")
        print("  - Enter 'default' to use recommended regions")
        print("  - Enter numbers separated by commas (e.g., 1,2,4)")
        print("  - Enter region codes directly (e.g., us-east-1,eu-west-1)")
        
        while True:
            choice = input("\nYour region selection: ").strip()
            
            if not choice:
                print("ERROR: Please enter a valid selection.")
                continue
            
            if choice.lower() == 'default':
                print(f"Using default regions: {', '.join(default_regions)}")
                return default_regions
            
            if choice.lower() == 'all':
                all_regions = [region for region, _ in common_regions]
                print(f"Selected all regions: {', '.join(all_regions)}")
                print("NOTE: Analyzing all regions will take significantly longer.")
                return all_regions
            
            # Check if user entered region codes directly
            if any(choice.startswith(prefix) for prefix in ['us-', 'eu-', 'ap-', 'ca-', 'sa-']):
                regions = [r.strip() for r in choice.split(',')]
                valid_regions = [region for region, _ in common_regions]
                invalid_regions = [r for r in regions if r not in valid_regions]
                
                if invalid_regions:
                    print(f"ERROR: Invalid regions: {', '.join(invalid_regions)}")
                    print(f"Valid regions: {', '.join(valid_regions)}")
                    continue
                
                print(f"Selected regions: {', '.join(regions)}")
                return regions
            
            # Handle numbered selection
            try:
                if ',' in choice:
                    numbers = [int(n.strip()) for n in choice.split(',')]
                else:
                    numbers = [int(choice.strip())]
                
                selected_regions = []
                selected_descriptions = []
                
                for num in numbers:
                    if 1 <= num <= len(common_regions):
                        region, description = common_regions[num - 1]
                        selected_regions.append(region)
                        selected_descriptions.append(f"{region} ({description})")
                    else:
                        print(f"ERROR: Invalid selection: {num}. Please use numbers 1-{len(common_regions)}.")
                        selected_regions = []
                        break
                
                if selected_regions:
                    print(f"Selected regions: {', '.join(selected_descriptions)}")
                    return selected_regions
            
            except ValueError:
                print("ERROR: Invalid input. Please enter numbers, region codes, 'all', or 'default'.")
    
    def interactive_lookback_days_selection(self, default_days: int = 30) -> int:
        """Interactive lookback period selection"""
        
        # Common lookback periods with descriptions
        common_periods = [
            (7, "1 week - Recent activity only (faster analysis)"),
            (14, "2 weeks - Short-term usage patterns"),
            (30, "1 month - Standard analysis period (recommended)"),
            (60, "2 months - Extended usage patterns"),
            (90, "3 months - Long-term analysis (slower, more comprehensive)")
        ]
        
        print("\nAnalysis Lookback Period:")
        print("Choose how far back to analyze resource usage patterns.")
        print()
        
        for i, (days, description) in enumerate(common_periods, 1):
            selected_indicator = "[*]" if days == default_days else "   "
            print(f"  {i}. {selected_indicator} {days:2d} days - {description}")
        
        print()
        print("Selection options:")
        print("  - Enter a number (1-5) to select a preset period")
        print("  - Enter 'custom' to specify exact number of days")
        print("  - Enter 'default' to use recommended 30 days")
        
        while True:
            choice = input(f"\nYour selection (default: {default_days} days): ").strip()
            
            if not choice or choice.lower() == 'default':
                print(f"Using default: {default_days} days")
                return default_days
            
            if choice.lower() == 'custom':
                while True:
                    try:
                        custom_days = int(input("Enter number of days (1-365): ").strip())
                        if 1 <= custom_days <= 365:
                            print(f"Custom lookback period: {custom_days} days")
                            if custom_days > 90:
                                print("NOTE: Long lookback periods may result in slower analysis.")
                            return custom_days
                        else:
                            print("ERROR: Please enter a number between 1 and 365.")
                    except ValueError:
                        print("ERROR: Please enter a valid number.")
            
            try:
                num = int(choice)
                if 1 <= num <= len(common_periods):
                    selected_days, description = common_periods[num - 1]
                    print(f"Selected: {selected_days} days - {description}")
                    return selected_days
                else:
                    print(f"ERROR: Invalid selection: {num}. Please use numbers 1-{len(common_periods)}.")
            
            except ValueError:
                print("ERROR: Invalid input. Please enter a number, 'custom', or 'default'.")