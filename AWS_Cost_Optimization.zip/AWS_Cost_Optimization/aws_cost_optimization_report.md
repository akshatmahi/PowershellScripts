# AWS Cost Optimization & Security Cleanup Report

Generated on: 2025-11-07 12:41:25

## SUMMARY: Executive Summary

- **Total Resources Analyzed**: 107
- **🔒 Security-Focused Items**: 39
- **💰 Cost-Focused Items**: 68
- **⚠️ High Risk Items**: 49
- **Estimated Monthly Savings**: $1,044.21
- **Estimated Annual Savings**: $12,530.50
- **Regions Analyzed**: us-west-2
- **👥 Profiles Analyzed**: 1
- **🏢 AWS Accounts**: 1

## 💰 Cost Breakdown

### 🗄️ RDS Instance (5 resources)

**Potential Monthly Savings**: $757.59

1. **N/A** (us-west-2) - $208.94/month 🟢
2. **testrail** (us-west-2) - $182.64/month 🟡
3. **line2data** (us-west-2) - $130.04/month 🟡
   *...and 2 more resources with $235.97/month potential savings*

### 💾 EBS Snapshot (28 resources)

**Potential Monthly Savings**: $118.66

1. **N/A** (us-west-2) - $12.00/month 🔴
2. **N/A** (us-west-2) - $11.81/month 🔴
3. **N/A** (us-west-2) - $9.60/month 🔴
   *...and 25 more resources with $85.25/month potential savings*

### 💾 EBS Volume (8 resources)

**Potential Monthly Savings**: $100.00

1. **N/A** (us-west-2) - $20.00/month 🟢
2. **N/A** (us-west-2) - $20.00/month 🟢
3. **N/A** (us-west-2) - $20.00/month 🟢
   *...and 5 more resources with $40.00/month potential savings*

### ⚖️ Network Load Balancer (2 resources)

**Potential Monthly Savings**: $41.48

1. **Informatica-BDM-prod-NLB** (us-west-2) - $20.74/month 🟡
2. **cfg-informatica-bdm-prd-nlb** (us-west-2) - $20.74/month 🟡

### ⚖️ Application Load Balancer (1 resources)

**Potential Monthly Savings**: $20.74

1. **Alteryx-prod-ALB** (us-west-2) - $20.74/month 🟡

### ⚡ Lambda Function (14 resources)

**Potential Monthly Savings**: $5.74

1. **cfg-oracle-secret-rotation-prod-lambda** (us-west-2) - $4.84/month 🟡
2. **cfg-mssql-secret-rotation-prod-lambda** (us-west-2) - $0.47/month 🟡
3. **cfg-mysql-secret-rotation-prod-lambda** (us-west-2) - $0.42/month 🟡
   *...and 11 more resources with $0.00/month potential savings*



## 👥 Multi-Account Analysis

**Single profile analysis - no cross-account comparison available.**


## 🔐 Security Analysis Summary

**Security Resources Identified**: 39

**🔴 Critical Security Issues (21)**:
- Security Group: sg-040b186bf2b736d92 - Security group is not attached to any resource and has security concerns: Port all open to internet
- Security Group: sg-0fb5f72a09b169edf - Security group is not attached to any resource and has security concerns: Port all open to internet
- IAM Role: AWSReservedSSO_CFG-Cloud-Security-Read-Only_1f62cb6222a07a27 - Role has not been used for 827 days

**🟡 Security Concerns (10)**:
- IAM Role: AWSReservedSSO_AWSAdministratorAccess_4a7633df4fe9d7a3
- IAM Role: AWSReservedSSO_AWSOrganizationsFullAccess_6fa23a12378c4754
- IAM Role: AWSReservedSSO_AWSPowerUserAccess_a7596e7f1d89b740



## 💰 Cost Optimization Opportunities

### 💰 RDS Instance (5 resources)

**Potential Monthly Savings**: $757.59

#### 🟢 N/A

- **Resource ID**: `cro-risk-ext-prd`
- **Region**: us-west-2
- **Current Monthly Cost**: $208.94
- **Potential Monthly Savings**: $208.94
- **Risk Level**: 🟢 Low
- **Reason**: RDS instance shows database activity but no reported connections: ReadIOPS=0.3, WriteIOPS=2.4 | avg=0.82 connections | max=9 connections
- **Recommended Action**: Review metrics completeness and verify actual usage before terminating
- **Tags**: aws:cloudformation:stack-name:rds-postgres-cro-risk-ext, ApplicationName:CRO_RISK_EXT, Backup_LTR:RDS, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:504748092445:stack/rds-postgres-cro-risk-ext/d99ffc00-175e-11ef-81ac-06cd9fa26ccb, DBEngine:Postgres, DBEdition:Postgres, cfg:environment:prod, DBVersion:, DailyBackups:RDS, ApplicationOwner:Dan Rao, cfg:app-name:CRO_RISK_EXT, DBAOwner:Ilya Rubijevsky, Environment:prod, aws:cloudformation:logical-id:RDSPostgresDB

---

#### 🟡 testrail

- **Resource ID**: `testrail-prod`
- **Region**: us-west-2
- **Current Monthly Cost**: $182.64
- **Potential Monthly Savings**: $182.64
- **Risk Level**: 🟡 Medium
- **Reason**: RDS instance with connection issues over 90 days: 7007873 connection attempts but avg=0.83 successful connections | max=131 connections | recent 7d avg=0.68 | Database active: ReadIOPS=2.4, WriteIOPS=8.5
- **Recommended Action**: Investigate connection failures (check credentials, security groups, network config) before terminating
- **Tags**: DBEngineEdition:, DailyBackups:RDS, ApplicationName:testrail, ApplicationOwner:Igor Scripco, DBEngineVersion:8, Backup_LTR:RDS, cfg:app-name:testrail, DBAOwner:Krishna Kumar, DBEngine:MySql, Environment:prod, cfg:environment:prod

---

#### 🟡 line2data

- **Resource ID**: `infosec-l2-prod`
- **Region**: us-west-2
- **Current Monthly Cost**: $130.04
- **Potential Monthly Savings**: $130.04
- **Risk Level**: 🟡 Medium
- **Reason**: RDS instance with connection issues over 90 days: 37839 connection attempts but avg=0.42 successful connections | max=10 connections | recent 7d avg=0.00 | Database active: ReadIOPS=0.3, WriteIOPS=0.4
- **Recommended Action**: Investigate connection failures (check credentials, security groups, network config) before terminating
- **Tags**: DailyBackups:RDS, ApplicationOwner:Abid Rehman, Backup_LTR:RDS, cfg:app-name:Infosec, DBAOwner:Ilya Rubijevsky, DBEngine:MySQL, cfg:environment:prod

---

#### 🟢 N/A

- **Resource ID**: `nexus-prd`
- **Region**: us-west-2
- **Current Monthly Cost**: $130.04
- **Potential Monthly Savings**: $130.04
- **Risk Level**: 🟢 Low
- **Reason**: RDS instance shows database activity but no reported connections: ReadIOPS=2.0, WriteIOPS=3.6 | avg=0.97 connections | max=18 connections
- **Recommended Action**: Review metrics completeness and verify actual usage before terminating
- **Tags**: aws:cloudformation:stack-name:createRDS-postgres-Nexus-prd, ApplicationName:Nexus, Backup_LTR:RDS, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:504748092445:stack/createRDS-postgres-Nexus-prd/ba0441a0-481c-11ef-9282-0a117aba626b, DBEngine:Postgres, DBEdition:, cfg:environment:prod, DBVersion:, DailyBackups:RDS, ApplicationOwner:Siddhartha Pendharkar, cfg:app-name:Nexus, DBAOwner:Ilya Rubijevsky, Environment:prod, aws:cloudformation:logical-id:RDSPostgresDB

---

#### 🟡 N/A

- **Resource ID**: `ipam-telecomdb-prd`
- **Region**: us-west-2
- **Current Monthly Cost**: $105.93
- **Potential Monthly Savings**: $105.93
- **Risk Level**: 🟡 Medium
- **Reason**: RDS instance with connection issues over 90 days: 1075147 connection attempts but avg=0.00 successful connections | max=2 connections | recent 7d avg=0.00 | Database active: ReadIOPS=0.3, WriteIOPS=0.5
- **Recommended Action**: Investigate connection failures (check credentials, security groups, network config) before terminating
- **Tags**: application-name:ipam-telecomdb, Backup_LTR:RDS, map-migrated-app:NA, DBEngine:mysql, application-owner:akhil.chandra@cetera.com, resource-name:rds, cfg:environment:prod, Name:cfg-oregon-shared-infra-prod-rds-ipam-telecomdb, aws-migration-project-id:MPE11706, broker-services:NA, cost-center:1369, DailyBackups:RDS, environment:production, ApplicationOwner:Akhil Chandra, cfg:app-name:ipam-telecomdb, DBAOwner:Ilya Rubijevsky, business-unit:IT-Infra, map-dba:d-server-03ig6rnv8u2q5a

---

### 💰 Network Load Balancer (2 resources)

**Potential Monthly Savings**: $41.48

#### 🟡 Informatica-BDM-prod-NLB

- **Resource ID**: `Informatica-BDM-prod-NLB`
- **Region**: us-west-2
- **Current Monthly Cost**: $20.74
- **Potential Monthly Savings**: $20.74
- **Risk Level**: 🟡 Medium
- **Reason**: No healthy targets in target groups
- **Recommended Action**: Delete unused load balancer

---

#### 🟡 cfg-informatica-bdm-prd-nlb

- **Resource ID**: `cfg-informatica-bdm-prd-nlb`
- **Region**: us-west-2
- **Current Monthly Cost**: $20.74
- **Potential Monthly Savings**: $20.74
- **Risk Level**: 🟡 Medium
- **Reason**: No healthy targets in target groups
- **Recommended Action**: Delete unused load balancer
- **Tags**: cfg:app-name:informatica-bdm, cfg:environment:prd

---

### 💰 Application Load Balancer (1 resources)

**Potential Monthly Savings**: $20.74

#### 🟡 Alteryx-prod-ALB

- **Resource ID**: `Alteryx-prod-ALB`
- **Region**: us-west-2
- **Current Monthly Cost**: $20.74
- **Potential Monthly Savings**: $20.74
- **Risk Level**: 🟡 Medium
- **Reason**: No healthy targets in target groups
- **Recommended Action**: Delete unused load balancer

---

### 💰 EBS Volume (8 resources)

**Potential Monthly Savings**: $100.00

#### 🟢 N/A

- **Resource ID**: `vol-0bbc67a9450ca5e24`
- **Region**: us-west-2
- **Current Monthly Cost**: $20.00
- **Potential Monthly Savings**: $20.00
- **Risk Level**: 🟢 Low
- **Reason**: Volume is unattached and not in use
- **Recommended Action**: Create snapshot and delete volume

---

#### 🟢 N/A

- **Resource ID**: `vol-0a4f8517832eb779d`
- **Region**: us-west-2
- **Current Monthly Cost**: $20.00
- **Potential Monthly Savings**: $20.00
- **Risk Level**: 🟢 Low
- **Reason**: Volume is unattached and not in use
- **Recommended Action**: Create snapshot and delete volume

---

#### 🟢 N/A

- **Resource ID**: `vol-08ab6e8b2c2d592f7`
- **Region**: us-west-2
- **Current Monthly Cost**: $20.00
- **Potential Monthly Savings**: $20.00
- **Risk Level**: 🟢 Low
- **Reason**: Volume is unattached and not in use
- **Recommended Action**: Create snapshot and delete volume

---

#### 🟢 N/A

- **Resource ID**: `vol-0f0a55d6cefd9a628`
- **Region**: us-west-2
- **Current Monthly Cost**: $20.00
- **Potential Monthly Savings**: $20.00
- **Risk Level**: 🟢 Low
- **Reason**: Volume is unattached and not in use
- **Recommended Action**: Create snapshot and delete volume

---

#### 🟢 N/A

- **Resource ID**: `vol-0bf1ec7b52a49fef1`
- **Region**: us-west-2
- **Current Monthly Cost**: $5.00
- **Potential Monthly Savings**: $5.00
- **Risk Level**: 🟢 Low
- **Reason**: Volume is unattached and not in use
- **Recommended Action**: Create snapshot and delete volume

---

#### 🟢 N/A

- **Resource ID**: `vol-038d2bdd22e076f8a`
- **Region**: us-west-2
- **Current Monthly Cost**: $5.00
- **Potential Monthly Savings**: $5.00
- **Risk Level**: 🟢 Low
- **Reason**: Volume is unattached and not in use
- **Recommended Action**: Create snapshot and delete volume

---

#### 🟢 N/A

- **Resource ID**: `vol-0738bceab499c69e8`
- **Region**: us-west-2
- **Current Monthly Cost**: $5.00
- **Potential Monthly Savings**: $5.00
- **Risk Level**: 🟢 Low
- **Reason**: Volume is unattached and not in use
- **Recommended Action**: Create snapshot and delete volume

---

#### 🟢 N/A

- **Resource ID**: `vol-042cd6196674c7ba9`
- **Region**: us-west-2
- **Current Monthly Cost**: $5.00
- **Potential Monthly Savings**: $5.00
- **Risk Level**: 🟢 Low
- **Reason**: Volume is unattached and not in use
- **Recommended Action**: Create snapshot and delete volume

---

### 💰 EBS Snapshot (28 resources)

**Potential Monthly Savings**: $118.66

#### 🔴 N/A

- **Resource ID**: `snap-0f28f921392334205`
- **Region**: us-west-2
- **Current Monthly Cost**: $12.00
- **Potential Monthly Savings**: $12.00
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 841 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0b42db193a607ac46`
- **Region**: us-west-2
- **Current Monthly Cost**: $11.81
- **Potential Monthly Savings**: $11.81
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 883 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0163c6fcfd35aa899`
- **Region**: us-west-2
- **Current Monthly Cost**: $9.60
- **Potential Monthly Savings**: $9.60
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 397 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-092efd9ed3e4d3e73`
- **Region**: us-west-2
- **Current Monthly Cost**: $9.60
- **Potential Monthly Savings**: $9.60
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 397 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0b601b241a02b3546`
- **Region**: us-west-2
- **Current Monthly Cost**: $9.60
- **Potential Monthly Savings**: $9.60
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 397 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0e9a5b7a6e69ca829`
- **Region**: us-west-2
- **Current Monthly Cost**: $9.60
- **Potential Monthly Savings**: $9.60
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 397 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0b67f53dfae01f5fd`
- **Region**: us-west-2
- **Current Monthly Cost**: $7.20
- **Potential Monthly Savings**: $7.20
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 397 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0b33f8929898be528`
- **Region**: us-west-2
- **Current Monthly Cost**: $7.20
- **Potential Monthly Savings**: $7.20
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 397 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0e9c0c9516a1c344a`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 883 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0e6dc2e66ff393e55`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 397 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0563984dbad3891c1`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 841 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0d61ee2e7d1e4b607`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 530 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0ac37e9cee4fb7893`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.16
- **Potential Monthly Savings**: $2.16
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 530 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-060db44fd4b25adbd`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1254 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-075adb61342b16c29`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 397 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0afee0cac9e9a4efa`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 397 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0c27af6e5028a1979`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 397 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-00399f3bda8efaa97`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1254 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0ab34df7232fd0c59`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 397 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0d0ca69fbbcd16987`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 530 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0a186b23c1cddfb4a`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 397 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-032912b3fb491e926`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 397 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0e75abdc90d560045`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 397 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-03e7f2ecd016d5ef5`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.20
- **Potential Monthly Savings**: $1.20
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 397 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-08bf5b6f9086f39cd`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.72
- **Potential Monthly Savings**: $0.72
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 397 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0f62a16ee130339d3`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.72
- **Potential Monthly Savings**: $0.72
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 397 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-08fe6ae3c008d9fc4`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.38
- **Potential Monthly Savings**: $0.38
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 397 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-031a4b79570373538`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.38
- **Potential Monthly Savings**: $0.38
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 397 days old, exceeding 365-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

### 💰 Lambda Function (14 resources)

**Potential Monthly Savings**: $5.74

#### 🟡 cfg-oracle-secret-rotation-prod-lambda

- **Resource ID**: `cfg-oracle-secret-rotation-prod-lambda`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.84
- **Potential Monthly Savings**: $4.84
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 90 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:RdsSecretsRotationLambda, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:504748092445:stack/cfg-oracle-rds-secret-rotation-prod-lambda/6d475bc0-470f-11f0-a07d-026baadb3619, aws:cloudformation:stack-name:cfg-oracle-rds-secret-rotation-prod-lambda, cfg:app-portfolio:data-and-analytics, cfg:environment:prod

---

#### 🟡 cfg-mssql-secret-rotation-prod-lambda

- **Resource ID**: `cfg-mssql-secret-rotation-prod-lambda`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.47
- **Potential Monthly Savings**: $0.47
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 90 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:RdsSecretsRotationLambda, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:504748092445:stack/cfg-mssql-rds-secret-rotation-prod-lambda/15088700-470e-11f0-a2fe-0af8693777ff, aws:cloudformation:stack-name:cfg-mssql-rds-secret-rotation-prod-lambda, cfg:app-portfolio:data-and-analytics

---

#### 🟡 cfg-mysql-secret-rotation-prod-lambda

- **Resource ID**: `cfg-mysql-secret-rotation-prod-lambda`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.42
- **Potential Monthly Savings**: $0.42
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 90 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:RdsSecretsRotationLambda, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:504748092445:stack/cfg-mysql-rds-secret-rotation-prod-lambda/cc5d94b0-470c-11f0-91ec-06d786a4fb61, aws:cloudformation:stack-name:cfg-mysql-rds-secret-rotation-prod-lambda, cfg:app-portfolio:data-and-analytics

---

#### 🟡 cfg-nice-ingestion-prod-daily-lambda

- **Resource ID**: `cfg-nice-ingestion-prod-daily-lambda`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 90 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:CfgNiceIngestionDailyLambda, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:504748092445:stack/cfg-nice-prod-resources-stack/c57fa830-ef29-11ef-af01-0ace51c6a781, aws:cloudformation:stack-name:cfg-nice-prod-resources-stack, cfg:app-name:nice, cfg:environment:prod

---

#### 🟡 cfg-edh-api-datashare-url-prod-lambda

- **Resource ID**: `cfg-edh-api-datashare-url-prod-lambda`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 90 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:DataShareURLLambdaFunction, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:504748092445:stack/cfg-edh-api-prod-resources-stack/52c3cd40-102a-11f0-b6fa-06596f54ec5d, aws:cloudformation:stack-name:cfg-edh-api-prod-resources-stack, cfg:app-name:edh, cfg:environment:prod

---

#### 🟡 cfg-edh-api-datashare-s3-prod-lambda

- **Resource ID**: `cfg-edh-api-datashare-s3-prod-lambda`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 90 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:DataShareS3LambdaFunction, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:504748092445:stack/cfg-edh-api-prod-resources-stack/52c3cd40-102a-11f0-b6fa-06596f54ec5d, aws:cloudformation:stack-name:cfg-edh-api-prod-resources-stack, cfg:app-name:edh, cfg:environment:prod

---

#### 🟡 cfg-cfn-macros-ExplodeMacroStack-I5T-MacroFunction-rutZCyAoLC3T

- **Resource ID**: `cfg-cfn-macros-ExplodeMacroStack-I5T-MacroFunction-rutZCyAoLC3T`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 90 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:MacroFunction, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:504748092445:stack/cfg-cfn-macros-ExplodeMacroStack-I5T5O79BB4S8/3bf00440-7a4d-11ee-861a-0a590db4d40d, aws:cloudformation:stack-name:cfg-cfn-macros-ExplodeMacroStack-I5T5O79BB4S8, lambda:createdBy:SAM

---

#### 🟡 GlueJobFailureAlert

- **Resource ID**: `GlueJobFailureAlert`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 90 days
- **Recommended Action**: Review and delete if no longer needed

---

#### 🟡 replication-macro

- **Resource ID**: `replication-macro`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 90 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:rTransformFunction, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:504748092445:stack/cfg-cfn-macros-ReplicationMacroStack-CYLM3GMLC351/3bcfd210-7a4d-11ee-8cea-06d9e5209111, aws:cloudformation:stack-name:cfg-cfn-macros-ReplicationMacroStack-CYLM3GMLC351

---

#### 🟡 trigger_salesforce_product_ingestion

- **Resource ID**: `trigger_salesforce_product_ingestion`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 90 days
- **Recommended Action**: Review and delete if no longer needed

---

#### 🟡 cfg-eden-prd-reprocess

- **Resource ID**: `cfg-eden-prd-reprocess`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 90 days
- **Recommended Action**: Review and delete if no longer needed

---

#### 🟡 trigger_salesforce_fund_family_ingestion

- **Resource ID**: `trigger_salesforce_fund_family_ingestion`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 90 days
- **Recommended Action**: Review and delete if no longer needed

---

#### 🟡 trigger_salesforce_account_ingestion

- **Resource ID**: `trigger_salesforce_account_ingestion`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 90 days
- **Recommended Action**: Review and delete if no longer needed

---

#### 🟡 cfg-cfn-macros-PyPlateMacroStack-TransformFunction-y4uibW5MeQOj

- **Resource ID**: `cfg-cfn-macros-PyPlateMacroStack-TransformFunction-y4uibW5MeQOj`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 90 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:TransformFunction, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:504748092445:stack/cfg-cfn-macros-PyPlateMacroStack-1FLND37JTV9JQ/3bd6afe0-7a4d-11ee-b4bd-0a098df2595d, aws:cloudformation:stack-name:cfg-cfn-macros-PyPlateMacroStack-1FLND37JTV9JQ

---

### 💰 Network Interface (7 resources)

**Potential Monthly Savings**: $0.00

#### 🟢 N/A

- **Resource ID**: `eni-09403bd1279d24c34`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Network interface is not attached to any resource
- **Recommended Action**: Delete if not needed for future use
- **Tags**: aws-glue-service-resource:AWSGlue

---

#### 🟢 N/A

- **Resource ID**: `eni-0ef8d7e75d2a8c93f`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Network interface is not attached to any resource
- **Recommended Action**: Delete if not needed for future use
- **Tags**: aws-glue-service-resource:AWSGlue

---

#### 🟢 N/A

- **Resource ID**: `eni-021c8a5fb5bc66c17`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Network interface is not attached to any resource
- **Recommended Action**: Delete if not needed for future use
- **Tags**: aws-glue-service-resource:AWSGlue

---

#### 🟢 N/A

- **Resource ID**: `eni-0e576247a287278c7`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Network interface is not attached to any resource
- **Recommended Action**: Delete if not needed for future use
- **Tags**: aws-glue-service-resource:AWSGlue

---

#### 🟢 PPAXWAL000-ENI

- **Resource ID**: `eni-0aeeb083faba2cc90`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Network interface is not attached to any resource
- **Recommended Action**: Delete if not needed for future use
- **Tags**: Name:PPAXWAL000-ENI

---

#### 🟢 N/A

- **Resource ID**: `eni-01d472137d90f2645`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Network interface is not attached to any resource
- **Recommended Action**: Delete if not needed for future use

---

#### 🟢 N/A

- **Resource ID**: `eni-00d775cc423b11bc8`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Network interface is not attached to any resource
- **Recommended Action**: Delete if not needed for future use

---

### 🔒 Security Group (10 resources)

**Potential Monthly Savings**: $0.00

#### 🟢 cfg-dataanalytics-bi-sapbi-efs-prod-sg

- **Resource ID**: `sg-0e5720b63fd84c0fb`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface

---

#### 🟢 ElasticMapReduce-ServiceAccess

- **Resource ID**: `sg-05fe2e538a736a708`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: sg:auto terminated, for-use-with-amazon-emr-managed-policies:true

---

#### 🟢 cfg-mdm-glue-jobs-prod-SG

- **Resource ID**: `sg-02f2e670c820d0afc`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: cfg:project-code:200447, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:504748092445:stack/cfg-mdm-prod-resources-creation-stack/89cfc0e0-f083-11ee-9d55-06fd66bd9af7, cfg:dept-id:0386, aws:cloudformation:logical-id:MdmGlueJobsSg, aws:cloudformation:stack-name:cfg-mdm-prod-resources-creation-stack, cfg:environment:prod, cfg:IT-App-Owner:Isaac Kamalesh, cfg:SME:Vikas Lather, cfg:app-name:mdm, cfg:cost-center:0386, cfg:business-criticality:Low, cfg:dl-code:665603

---

#### 🔴 ElasticMapReduce-Master-Private

- **Resource ID**: `sg-040b186bf2b736d92`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Security group is not attached to any resource and has security concerns: Port all open to internet
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: sg:auto terminated, for-use-with-amazon-emr-managed-policies:true

---

#### 🟢 cfg-datateam-etl-db-egress-prod-SG

- **Resource ID**: `sg-017848e84c72465ff`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: for-use-with-amazon-emr-managed-policies:true, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:504748092445:stack/cfg-datateam-etl-db-egress-prod-sg-stack/ad136760-160d-11ee-b60b-02eaad0ba711, aws:cloudformation:stack-name:cfg-datateam-etl-db-egress-prod-sg-stack, aws:cloudformation:logical-id:cfgdataanalyticsdbprodsg

---

#### 🟢 cfg-oregon-emr-prod-sg-EMRSlavePrivate

- **Resource ID**: `sg-040b78fe9fa4774df`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: aws:cloudformation:stack-name:cfg-EMR-Prod-securitygroups-stack, aws:cloudformation:logical-id:EMRSlavePrivateSecurityGroup, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:504748092445:stack/cfg-EMR-Prod-securitygroups-stack/94dd1930-b68b-11ec-a600-0abc2495f221

---

#### 🟢 cfg-glue-edh-dataload-prod-sg

- **Resource ID**: `sg-0cfa159580d84018e`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: RequestId:CHG0064259

---

#### 🟢 cfg-dataanalytics-adi-prod-sg

- **Resource ID**: `sg-0447ccee64baa73eb`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface

---

#### 🟢 cfg-oregon-emr-prod-sg-EMRMasterPrivate

- **Resource ID**: `sg-07b062e6559f5126e`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: aws:cloudformation:logical-id:EMRMasterPrivateSecurityGroup, aws:cloudformation:stack-name:cfg-EMR-Prod-securitygroups-stack, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:504748092445:stack/cfg-EMR-Prod-securitygroups-stack/94dd1930-b68b-11ec-a600-0abc2495f221

---

#### 🔴 ElasticMapReduce-Slave-Private

- **Resource ID**: `sg-0fb5f72a09b169edf`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Security group is not attached to any resource and has security concerns: Port all open to internet
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: for-use-with-amazon-emr-managed-policies:true, sg:auto terminated

---

### 🔒 IAM Role (27 resources)

**Potential Monthly Savings**: $0.00

#### 🟡 AWSReservedSSO_AWSAdministratorAccess_4a7633df4fe9d7a3

- **Resource ID**: `AWSReservedSSO_AWSAdministratorAccess_4a7633df4fe9d7a3`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 AWSReservedSSO_AWSOrganizationsFullAccess_6fa23a12378c4754

- **Resource ID**: `AWSReservedSSO_AWSOrganizationsFullAccess_6fa23a12378c4754`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 AWSReservedSSO_AWSPowerUserAccess_a7596e7f1d89b740

- **Resource ID**: `AWSReservedSSO_AWSPowerUserAccess_a7596e7f1d89b740`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 AWSReservedSSO_AWSReadOnlyAccess_94c67f0e68a80973

- **Resource ID**: `AWSReservedSSO_AWSReadOnlyAccess_94c67f0e68a80973`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 AWSReservedSSO_CFG-auditor-ro-role_d454280d83c7fcf2

- **Resource ID**: `AWSReservedSSO_CFG-auditor-ro-role_d454280d83c7fcf2`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🔴 AWSReservedSSO_CFG-Cloud-Security-Read-Only_1f62cb6222a07a27

- **Resource ID**: `AWSReservedSSO_CFG-Cloud-Security-Read-Only_1f62cb6222a07a27`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 827 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🔴 AWSReservedSSO_CFG-DataAnalytics-ProdSupportL2_17b4e51fe2344b44

- **Resource ID**: `AWSReservedSSO_CFG-DataAnalytics-ProdSupportL2_17b4e51fe2344b44`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 408 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🔴 AWSReservedSSO_CFG-DataAnalytics-ProdSupportL3_18e9ce88f8ec8511

- **Resource ID**: `AWSReservedSSO_CFG-DataAnalytics-ProdSupportL3_18e9ce88f8ec8511`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 408 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🔴 AWSReservedSSO_CFG-DataAnalytics-ProdSuprtL2v2_5fcb19a8a0c3b7c6

- **Resource ID**: `AWSReservedSSO_CFG-DataAnalytics-ProdSuprtL2v2_5fcb19a8a0c3b7c6`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 408 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🔴 AWSReservedSSO_CFG-Dataanalytics-RDSAccess-V2_d7ab4582376e90b2

- **Resource ID**: `AWSReservedSSO_CFG-Dataanalytics-RDSAccess-V2_d7ab4582376e90b2`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 114 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🔴 AWSReservedSSO_CFG-Dataanalytics-RDSAccess_d997cdcf58659d7b

- **Resource ID**: `AWSReservedSSO_CFG-Dataanalytics-RDSAccess_d997cdcf58659d7b`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 114 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🔴 AWSReservedSSO_CFG-DataAnalytics-sailpoint-dev_cf6e51c1f0e3a38f

- **Resource ID**: `AWSReservedSSO_CFG-DataAnalytics-sailpoint-dev_cf6e51c1f0e3a38f`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 338 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🔴 AWSReservedSSO_CFG-NOC-L3_2dfdb7ba9cfba642

- **Resource ID**: `AWSReservedSSO_CFG-NOC-L3_2dfdb7ba9cfba642`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 486 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🟡 AWSReservedSSO_CFG-PowerUser_75e229b3aa1730d8

- **Resource ID**: `AWSReservedSSO_CFG-PowerUser_75e229b3aa1730d8`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 AWSReservedSSO_CFG-Security-RO_18b7281abc74381f

- **Resource ID**: `AWSReservedSSO_CFG-Security-RO_18b7281abc74381f`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🔴 AWSReservedSSO_CFG-SOC-Team-Member_56e038c9af2b25f4

- **Resource ID**: `AWSReservedSSO_CFG-SOC-Team-Member_56e038c9af2b25f4`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 534 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🔴 AWSReservedSSO_CFG-System-Administrator_7d1ed4296f1c19d2

- **Resource ID**: `AWSReservedSSO_CFG-System-Administrator_7d1ed4296f1c19d2`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 133 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🟡 AWSReservedSSO_CFG-TSI-DATA-VALIDATOR_403890e4589c0dda

- **Resource ID**: `AWSReservedSSO_CFG-TSI-DATA-VALIDATOR_403890e4589c0dda`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 BackupCopyRole-PROD

- **Resource ID**: `BackupCopyRole-PROD`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk
- **Tags**: Environment:PROD, Account:504748092445, Purpose:RDS-Backup-Copy, ManagedBy:CloudFormation

---

#### 🔴 cdw-inscape-iam-role

- **Resource ID**: `cdw-inscape-iam-role`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 199 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🔴 cfg-asm-prd-github-cfn-deployment-role

- **Resource ID**: `cfg-asm-prd-github-cfn-deployment-role`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 132 days
- **Recommended Action**: Review and delete if no longer needed (security risk)
- **Tags**: cfg:app-name:asm, cfg:environment:prd

---

#### 🔴 cfg-asm-stg-github-cfn-deployment-role

- **Resource ID**: `cfg-asm-stg-github-cfn-deployment-role`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 136 days
- **Recommended Action**: Review and delete if no longer needed (security risk)
- **Tags**: cfg:app-name:asm, cfg:environment:stg

---

#### 🟡 cfg-cfn-macros-ExplodeMacroStack--MacroFunctionRole-yvP6H2FnG8rm

- **Resource ID**: `cfg-cfn-macros-ExplodeMacroStack--MacroFunctionRole-yvP6H2FnG8rm`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk
- **Tags**: lambda:createdBy:SAM

---

#### 🔴 cfg-cfn-macros-PyPlateMacroS-TransformExecutionRole-rFrZlLMSNLpY

- **Resource ID**: `cfg-cfn-macros-PyPlateMacroS-TransformExecutionRole-rFrZlLMSNLpY`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 735 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🔴 cfg-cfn-macros-ReplicationM-rTransformExecutionRole-aDKvTc3GkJJd

- **Resource ID**: `cfg-cfn-macros-ReplicationM-rTransformExecutionRole-aDKvTc3GkJJd`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 443 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🔴 cfg-cloudformation-emr-role-prod

- **Resource ID**: `cfg-cloudformation-emr-role-prod`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 304 days
- **Recommended Action**: Review and delete if no longer needed (security risk)
- **Tags**: RequestId:CHG0061226

---

#### 🔴 cfg-EMR-prod-stack-3-EMRClusterinstanceProfileRole-1UQNH7L6RHRE9

- **Resource ID**: `cfg-EMR-prod-stack-3-EMRClusterinstanceProfileRole-1UQNH7L6RHRE9`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 872 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

### 🔒 ACM Certificate (2 resources)

**Potential Monthly Savings**: $0.00

#### 🔴 tradecorrectionsystem-prod.cetera.com

- **Resource ID**: `0df3daf6-64a7-4591-ba3f-f59f6e79d055`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Certificate has expired
- **Recommended Action**: Delete expired certificate
- **Tags**: cfg:app-name:trade correction system, cfg:app-owner:Isaac

---

#### 🔴 tradecorrectionsystem-prod.ceterainternal.com

- **Resource ID**: `ac5b3669-758d-46c9-a9b4-71fcf78e9dbc`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Certificate has expired
- **Recommended Action**: Delete expired certificate
- **Tags**: cfg:applicaiton-owner:Isaac, cfg:app-name:trade correction application

---

### 💰 S3 Bucket (3 resources)

**Potential Monthly Savings**: $0.00

#### 🟢 504748092445-athena-query-results-bucket

- **Resource ID**: `504748092445-athena-query-results-bucket`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: S3 bucket is empty and unused
- **Recommended Action**: Delete empty bucket to reduce management overhead
- **Tags**: aws:cloudformation:stack-name:cfg-504748092445-athena-query-results-bucket-stack, aws:cloudformation:logical-id:S3Bucket, cfg:cost-allocation:portfolio:infrastructure-and-operations, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:504748092445:stack/cfg-504748092445-athena-query-results-bucket-stack/d5c5fbe0-7e9e-11f0-ab15-0673b09f3847

---

#### 🟢 aws-glue-scripts-504748092445-us-west-2

- **Resource ID**: `aws-glue-scripts-504748092445-us-west-2`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: S3 bucket is empty and unused
- **Recommended Action**: Delete empty bucket to reduce management overhead
- **Tags**: aws:cloudformation:stack-name:aws-glue-scripts-504748092445-us-west-2-s3-stack, cfg:build-date:, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:504748092445:stack/aws-glue-scripts-504748092445-us-west-2-s3-stack/7d8751d0-6ecf-11ee-8ca1-02c47c3388e7, cfg:app-name:EDEN, aws:cloudformation:logical-id:S3Bucket, application-owner:Isaac, cfg:environment:prod

---

#### 🟢 aws-glue-temporary-504748092445-us-west-2

- **Resource ID**: `aws-glue-temporary-504748092445-us-west-2`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: S3 bucket is empty and unused
- **Recommended Action**: Delete empty bucket to reduce management overhead
- **Tags**: aws:cloudformation:stack-name:aws-glue-temporary-504748092445-us-west-2-s3-stack, cfg:build-date:10192023, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:504748092445:stack/aws-glue-temporary-504748092445-us-west-2-s3-stack/bcb2e3b0-6ecf-11ee-a0a2-02640ea6b981, cfg:app-name:EDEN, aws:cloudformation:logical-id:S3Bucket, application-owner:Isaac, cfg:environment:prod

---

## TARGET: Prioritized Action Plan

### 🔴 High Priority (Immediate Action)
**Resources**: 49 | **Monthly Savings**: $118.66 (11.4%)

- 🔴 EBS Snapshot: `snap-0f28f921392334205` ($12.00/month)
- 🔴 EBS Snapshot: `snap-0b42db193a607ac46` ($11.81/month)
- 🔴 EBS Snapshot: `snap-0163c6fcfd35aa899` ($9.60/month)
- 🔴 EBS Snapshot: `snap-092efd9ed3e4d3e73` ($9.60/month)
- 🔴 EBS Snapshot: `snap-0b601b241a02b3546` ($9.60/month)
- ... and 44 more resources



### 🟡 Medium Priority (Review Required)
**Resources**: 30 | **Monthly Savings**: $486.57 (46.6%)

- 🟡 RDS Instance: `testrail-prod` ($182.64/month)
- 🟡 RDS Instance: `infosec-l2-prod` ($130.04/month)
- 🟡 RDS Instance: `ipam-telecomdb-prd` ($105.93/month)
- 🟡 Network Load Balancer: `Informatica-BDM-prod-NLB` ($20.74/month)
- 🟡 Network Load Balancer: `cfg-informatica-bdm-prd-nlb` ($20.74/month)
- ... and 25 more resources



### 🟢 Low Priority (Safe to Remove)
**Resources**: 28 | **Monthly Savings**: $438.98 (42.0%)

- 🟢 RDS Instance: `cro-risk-ext-prd` ($208.94/month)
- 🟢 RDS Instance: `nexus-prd` ($130.04/month)
- 🟢 EBS Volume: `vol-0bbc67a9450ca5e24` ($20.00/month)
- 🟢 EBS Volume: `vol-0a4f8517832eb779d` ($20.00/month)
- 🟢 EBS Volume: `vol-08ab6e8b2c2d592f7` ($20.00/month)
- ... and 23 more resources



## ⚠️ Risk Assessment

- **🔴 High Risk**: Manual review required, potential service disruption or security impact
- **🟡 Medium Risk**: Verify with application teams before action
- **🟢 Low Risk**: Generally safe to remove with minimal impact

## 🔐 Security Recommendations

### Immediate Security Actions:

1. **Review 10 unused security groups** - These pose security risks and should be deleted
2. **Audit 27 dormant IAM roles** - Follow principle of least privilege
3. **Clean up 2 expired certificates** - Prevent service disruptions

### Security Best Practices:

- Implement automated resource tagging for better governance
- Set up CloudTrail for resource usage monitoring
- Enable Config rules for compliance monitoring
- Schedule regular security and cost reviews



## 📋 Implementation Checklist

### Before Taking Action:
- [ ] Review all High Risk items with security team
- [ ] Create backups/snapshots where applicable
- [ ] Notify application teams of planned changes
- [ ] Schedule maintenance windows for critical resources

### Implementation Order:
1. **Start with Low Risk items** to gain confidence
2. **Address Security Groups** to reduce attack surface
3. **Clean up IAM roles** to improve security posture
4. **Remove expired certificates** to prevent outages
5. **Delete unused storage** to reduce costs
6. **Monitor services** after each batch of changes

## 📈 Expected Benefits

- **Cost Reduction**: $1,044.21/month ($12,530.50/year)
- **Security Improvement**: Reduced attack surface and compliance posture
- **Operational Excellence**: Simplified resource management
- **Risk Mitigation**: Eliminated orphaned resources and expired certificates

---
*This report was generated by the Enhanced AWS Cost Optimization & Security Analyzer*
