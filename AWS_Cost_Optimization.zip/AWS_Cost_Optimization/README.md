# AWS Cost Optimization & Security Analyzer

A simple Python tool to find unused AWS resources and save money on your cloud bill. Also identifies security risks from orphaned resources.

## What Does It Do?

- Finds unused AWS resources that are costing you money
- Shows how much you can save per month and per year
- Identifies security risks from orphaned resources
- Creates easy-to-read reports with recommendations
- Works across multiple AWS accounts
- Safe to run - it only analyzes, never deletes anything

## What Resources Does It Find?

The tool scans for 15+ types of unused resources including:

- Unattached storage volumes (EBS)
- Idle IP addresses (Elastic IPs)
- Unused or underutilized servers (EC2 instances)
- Abandoned databases (RDS)
- Unused load balancers
- Unused security groups (security risk!)
- Unused IAM roles (security risk!)
- Expired certificates
- Old snapshots
- Empty S3 buckets
- And more...

## Before You Start

You need:
- Python 3.7 or newer installed on your computer
- AWS account credentials configured
- Read-only permissions in AWS (the tool only reads data, never deletes)

## Quick Start (Windows)

1. **First Time Setup**
   - Double-click `simple-setup.cmd`
   - This will install everything you need automatically

2. **Run the Analysis**
   - **Easy:** Double-click `quick-run.cmd` - Opens interactive mode with prompts
   - **Advanced:** Run from command line with custom options (see examples below)
   - Done!

## Manual Setup (All Platforms)

1. **Download the files**
   ```bash
   cd Cost_Optimization
   ```

2. **Install required packages**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure your AWS credentials** (if not already done)
   ```bash
   aws configure
   ```
   You'll need to enter:
   - AWS Access Key ID
   - AWS Secret Access Key
   - Default region (e.g., us-east-1)

## How to Use

### Command Line Examples

```bash
# Interactive mode (recommended for beginners)
python src/aws_cost_optimizer.py --interactive

# Analyze your default AWS account
python src/aws_cost_optimizer.py

# Analyze specific AWS regions
python src/aws_cost_optimizer.py --regions us-east-1 us-west-2

# Analyze a named AWS profile
python src/aws_cost_optimizer.py --profile production

# Generate both report types (Markdown + CSV)
python src/aws_cost_optimizer.py --format both

# Windows: Run with venv (if not using quick-run.cmd)
aws_cost_optimizer_venv\Scripts\python.exe src\aws_cost_optimizer.py --interactive
```

### Common Options

- `--profile <name>`: Use a specific AWS profile
- `--regions <list>`: Which regions to scan (space-separated)
- `--lookback-days <number>`: How many days of history to check (default: 30)
- `--format both`: Create both Markdown and CSV reports
- `--output <filename>`: Name for the report file

## What You'll Get

After running the analysis, you'll get a detailed report showing:

- **Executive Summary**: How much you can save and what needs attention
- **Cost Breakdown**: Savings by resource type
- **Security Issues**: Unused resources that pose security risks
- **Action Plan**: Prioritized list of what to do (High/Medium/Low priority)
- **Implementation Steps**: Safe instructions for cleaning up resources

Reports use color indicators:
- 🔴 High Priority - Take action soon
- 🟡 Medium Priority - Review when convenient
- 🟢 Low Priority - Safe to clean up anytime

## Example Output

```
Analysis Complete!
• Total opportunities: 23
• High-risk items: 3
• Monthly savings: $2,847.50
• Annual savings: $34,170.00

Top Opportunities:
  1. RDS Database: production-analytics-db
     Save: $842/month - No connections for 30 days
  2. Elastic IP: 54.123.45.67
     Save: $3.65/month - Not attached to any instance
  3. Security Group: sg-unused-web (Security Risk!)
     Save: $0/month - Unused but open to internet
```

## Important Safety Notes

- **This tool only reads data - it NEVER deletes anything**
- Resources tagged as "Critical" are automatically excluded
- Always create backups before deleting resources
- Review high-priority items with your team before taking action
- Start with low-risk items first

## Project Structure

```
Cost_Optimization/
├── quick-run.cmd             # Windows: One-click run (START HERE)
├── simple-setup.cmd          # Windows: One-click setup
├── requirements.txt          # Python packages needed
├── README.md                 # This file
├── src/                      # Source code
│   ├── aws_cost_optimizer.py    # Main analysis engine
│   ├── aws_profile_manager.py   # AWS profile management
│   └── pricing_manager.py       # Pricing calculations
├── config/                   # Configuration files
│   └── config.json              # Settings and thresholds
└── data/                     # Pricing data files
    ├── Amazon EC2 Instance Comparison.csv
    └── Amazon RDS Instance Comparison.csv
```

## Troubleshooting

**"AccessDenied" errors:**
- Make sure AWS credentials are configured: `aws configure`
- Check that your IAM user has read permissions

**"No resources found":**
- Verify you're checking the right regions
- Make sure you have resources in your AWS account

**"Python not found" (Windows):**
- Install Python from python.org
- Make sure to check "Add Python to PATH" during installation

## Need Help?

- Run `python src/aws_cost_optimizer.py --help` to see all options
- Review the [config/config.json](config/config.json) file for customization options
- Check the detailed examples in the code comments

## Important Reminder

**This tool only analyzes - it never deletes anything automatically.**

Always review recommendations with your team before making changes to AWS resources. Start with low-priority items to gain confidence.