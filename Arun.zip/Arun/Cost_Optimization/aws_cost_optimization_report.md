# AWS Cost Optimization & Security Cleanup Report

Generated on: 2025-10-29 03:47:49

## SUMMARY: Executive Summary

- **Total Resources Analyzed**: 611
- **🔒 Security-Focused Items**: 145
- **💰 Cost-Focused Items**: 466
- **⚠️ High Risk Items**: 353
- **Estimated Monthly Savings**: $1,769.41
- **Estimated Annual Savings**: $21,232.92
- **Regions Analyzed**: us-west-2
- **👥 Profiles Analyzed**: 1
- **🏢 AWS Accounts**: 1

## 💰 Cost Breakdown

### 💾 EBS Snapshot (394 resources)

**Potential Monthly Savings**: $970.70

1. **N/A** (us-west-2) - $24.00/month 🔴
2. **N/A** (us-west-2) - $12.00/month 🔴
3. **aac-linux-image-062021** (us-west-2) - $12.00/month 🔴
   *...and 391 more resources with $922.70/month potential savings*

### 🖥️ EC2 Instance (9 resources)

**Potential Monthly Savings**: $467.70

1. **Server_2025_Golden_Ami** (us-west-2) - $131.50/month 🟢
2. **aws-cloud9-cld9-eks-sl1-test-b53313bf7fc54a128a3cac340889c64e** (us-west-2) - $74.52/month 🟢
3. **aws-cloud9-cfg-cloud-engineering-8de7403747b84cb2b2ab275eeb8c1de9** (us-west-2) - $74.52/month 🟢
   *...and 6 more resources with $187.17/month potential savings*

### ⚖️ Application Load Balancer (7 resources)

**Potential Monthly Savings**: $145.18

1. **telecom-dev-alb** (us-west-2) - $20.74/month 🟡
2. **dsnqalb** (us-west-2) - $20.74/month 🟡
3. **artifactory-dev** (us-west-2) - $20.74/month 🟡
   *...and 4 more resources with $82.96/month potential savings*

### 🗄️ RDS Instance (1 resources)

**Potential Monthly Savings**: $130.04

1. **N/A** (us-west-2) - $130.04/month 🔴

### ⚖️ Network Load Balancer (2 resources)

**Potential Monthly Savings**: $41.48

1. **cfg-sso-broker-qa-nlb** (us-west-2) - $20.74/month 🟡
2. **aac-qa-NLB-Win** (us-west-2) - $20.74/month 🟡

### 💰 Elastic IP (2 resources)

**Potential Monthly Savings**: $7.30

1. **N/A** (us-west-2) - $3.65/month 🟢
2. **N/A** (us-west-2) - $3.65/month 🟢

### 💾 EBS Volume (2 resources)

**Potential Monthly Savings**: $7.00

1. **N/A** (us-west-2) - $4.00/month 🟢
2. **N/A** (us-west-2) - $3.00/month 🟢

### ⚡ Lambda Function (27 resources)

**Potential Monthly Savings**: $0.00

1. **tagging-MyLambdaFunction-Zi9WHGji07i7** (us-west-2) - $0.00/month 🟡
2. **cfg-cfn-macros-ExplodeMacroStack-47B-MacroFunction-PWIe69AswRl9** (us-west-2) - $0.00/month 🟡
3. **tagging-CreateInputFolderLambdaFunction-flyAGnnfdttY** (us-west-2) - $0.00/month 🟡
   *...and 24 more resources with $0.00/month potential savings*



## 👥 Multi-Account Analysis

**Single profile analysis - no cross-account comparison available.**


## 🔐 Security Analysis Summary

**Security Resources Identified**: 145

**🔴 Critical Security Issues (34)**:
- Security Group: sg-0839e6cb60e7c83a0 - Security group is not attached to any resource and has security concerns: Port 443 open to internet
- Security Group: sg-064d292cbee5cdc18 - Security group is not attached to any resource and has security concerns: Port 443 open to internet
- Security Group: sg-0e0c0653a833d7a43 - Security group is not attached to any resource and has security concerns: Port 443 open to internet

**🟡 Security Concerns (42)**:
- IAM Role: aac-lin-Lambda-TargetAssign-Role
- IAM Role: aac-win-Lambda-Restart-Role
- IAM Role: aac-win-Lambda-TGUpdater-Role



## 💰 Cost Optimization Opportunities

### 💰 EC2 Instance (9 resources)

**Potential Monthly Savings**: $467.70

#### 🟢 Server_2025_Golden_Ami

- **Resource ID**: `i-0f9d5c6dc1bce961d`
- **Region**: us-west-2
- **Current Monthly Cost**: $131.50
- **Potential Monthly Savings**: $131.50
- **Risk Level**: 🟢 Low
- **Reason**: Instance has been stopped with no CloudWatch activity data for 30+ days
- **Recommended Action**: High priority for termination - appears to be unused long-term
- **Tags**: cfg:icfr:na, aws-migration-project-id:na, cfg:app-id:na, cfg:app-name:Windows, cfg:environment:dev, cfg:build-date:05272025, cfg:owner-operated:na, cfg:os-version:2025, Name:Server_2025_Golden_Ami, cfg:business-criticality:na, map-migrated:na, cfg:cost-center:na, cfg:data-classification:na

---

#### 🟢 aws-cloud9-cld9-eks-sl1-test-b53313bf7fc54a128a3cac340889c64e

- **Resource ID**: `i-0a6325c43d530ee34`
- **Region**: us-west-2
- **Current Monthly Cost**: $74.52
- **Potential Monthly Savings**: $74.52
- **Risk Level**: 🟢 Low
- **Reason**: Instance has been stopped with no CloudWatch activity data for 30+ days
- **Recommended Action**: High priority for termination - appears to be unused long-term
- **Tags**: cfg:build-date:11172022, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/aws-cloud9-cld9-eks-sl1-test-b53313bf7fc54a128a3cac340889c64e/6d88f330-6672-11ed-969b-020ef27d5e45, cfg:icfr:false, cfg:os-version:rhel, cfg:app-id:867-5309, aws:cloudformation:stack-name:aws-cloud9-cld9-eks-sl1-test-b53313bf7fc54a128a3cac340889c64e, aws-migration-project-id:MPE11706, cfg:business-criticality:low, aws:cloud9:owner:AROAUUCI63FS3R2PFUKK4:Durga.Prasad@cetera.com, map-migrated:n/a, cfg:app-name:adviceworks, cfg:data-classification:internal, cfg:cost-center:1369, Name:aws-cloud9-cld9-eks-sl1-test-b53313bf7fc54a128a3cac340889c64e, cfg:environment:test, cfg:owner-operated:true, aws:cloud9:environment:b53313bf7fc54a128a3cac340889c64e, aws:cloudformation:logical-id:Instance

---

#### 🟢 aws-cloud9-cfg-cloud-engineering-8de7403747b84cb2b2ab275eeb8c1de9

- **Resource ID**: `i-0dd6e6768b3e564fe`
- **Region**: us-west-2
- **Current Monthly Cost**: $74.52
- **Potential Monthly Savings**: $74.52
- **Risk Level**: 🟢 Low
- **Reason**: Instance has been stopped with no CloudWatch activity data for 30+ days
- **Recommended Action**: High priority for termination - appears to be unused long-term
- **Tags**: cfg:cost-center:2500, cfg:business-criticality:low, map-migrated:n/a, cfg:environment:nonprod, aws:cloud9:environment:8de7403747b84cb2b2ab275eeb8c1de9, cfg:app-name:cloud9, cfg:owner-operated:true, aws:cloud9:owner:AROAUUCI63FS52ERANCRV:ADM-JSanchez@ceteracorp.com, Name:aws-cloud9-cfg-cloud-engineering-8de7403747b84cb2b2ab275eeb8c1de9, aws:cloudformation:logical-id:Instance, cfg:icfr:false, aws-migration-project-id:n/a, aws:cloudformation:stack-name:aws-cloud9-cfg-cloud-engineering-8de7403747b84cb2b2ab275eeb8c1de9, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/aws-cloud9-cfg-cloud-engineering-8de7403747b84cb2b2ab275eeb8c1de9/18e5d090-f622-11ef-864d-024eb058e5d3, cfg:build-date:02282025, cfg:data-classification:internal, cfg:app-id:867-5309, cfg:os-version:linux

---

#### 🟢 N/A

- **Resource ID**: `i-0db47c7b00638e196`
- **Region**: us-west-2
- **Current Monthly Cost**: $67.80
- **Potential Monthly Savings**: $67.80
- **Risk Level**: 🟢 Low
- **Reason**: Instance has been stopped with no CloudWatch activity data for 30+ days
- **Recommended Action**: High priority for termination - appears to be unused long-term
- **Tags**: awsmigrationprojectid :MPE11706, cfg:IT-App-Owner:NA, cfg:os-version:w2022, Backup:default-ec2, aws:ec2launchtemplate:id:lt-02c01a48b0237b471, cfg:app-id:867-5309, cfg:builddate:06232023, cfg:dataclassification:internal, cfg:Anti-Virus:Yes, applicationowner:Noc, cfg:businesscriticality:low, cfg:Description:Service-Catalog-EC2-Reference-Architecture, cfg:cost-center:1369, aws:ec2launchtemplate:version:1, cfg:icfr:no, cfg:build by:NA, cfg:Monitoring:Yes, Patch Group:windows, cfg:owneroperated:yes, cfg:app-name:GoldenAMI, cfg:Environment:Dev, cfg:SME:NA

---

#### 🟢 DSNQAWL001.one.ad

- **Resource ID**: `i-0a98654a86e0bddcb`
- **Region**: us-west-2
- **Current Monthly Cost**: $54.94
- **Potential Monthly Savings**: $54.94
- **Risk Level**: 🟢 Low
- **Reason**: Instance stopped 10 days ago with minimal historical usage (avg CPU 8.7%)
- **Recommended Action**: Strong candidate for termination - create AMI backup if needed
- **Tags**: cfg:app-name:SonarQube, cfg:environment:dev, Name:DSNQAWL001.one.ad, cfg:IT-App-Owner:Hitesh Patel, cfg:build by:NOC Team, aws:servicecatalog:provisioningArtifactIdentifier:pa-xvbccjehcjyve, cfg:build-date:03222022, aws:cloudformation:logical-id:LinuxInstance, Backup:default-ec2, cfg:business-criticality:low, cfg:Hostname:DSNQAWL001.one.ad, cfg:cost-center:1369, cfg:Description:Service-Catalog-EC2-Linux-Provisioning, cfg:Anti-Virus:Yes, aws:cloudformation:stack-name:SC-317980596581-pp-zrgsyhnuukwng, cfg:os-version:rhel8, ApplyPatch:true, cfg:Monitoring:Yes, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/SC-317980596581-pp-zrgsyhnuukwng/61583b90-aa0a-11ec-902c-0ae1f1091119, aws:servicecatalog:provisioningPrincipalArn:arn:aws:sts::317980596581:assumed-role/AWSReservedSSO_CFG-Administrator_8f451a0d4fc00e50/ADM-PKunchala@ceteracorp.com, cfg:data-classification:internal, cfg:SME:Hitesh Patel, aws:servicecatalog:provisionedProductArn:arn:aws:servicecatalog:us-west-2:317980596581:stack/PSNQAWL001/pp-zrgsyhnuukwng, Patch Group:rhel, aws:servicecatalog:portfolioArn:arn:aws:catalog:us-west-2:317980596581:portfolio/port-pxd52jhq2zf2u, aws:servicecatalog:productArn:arn:aws:catalog:us-west-2:317980596581:product/prod-qplbx4ta4vbf4

---

#### 🟢 cfg-shared-infra-non-prod-ec2-nginx-connections-DR

- **Resource ID**: `i-081a6b73121987c86`
- **Region**: us-west-2
- **Current Monthly Cost**: $32.22
- **Potential Monthly Savings**: $32.22
- **Risk Level**: 🟢 Low
- **Reason**: Instance has been stopped with no CloudWatch activity data for 30+ days
- **Recommended Action**: High priority for termination - appears to be unused long-term
- **Tags**: Name:cfg-shared-infra-non-prod-ec2-nginx-connections-DR, Patch Group:rhel, cfg:app-name:Connections, cfg:business-criticality:high, cfg:cost-center:2000, application-owner:petricia.wijono@cetera.com, cfg:data-classification:internal, cfg:os-version:rhel7, ApplyPatch:true, cfg:build-date:07022021, cfg:environment:dev, Original id:i-0c2c1d7c2045f8756, CloudEndure creation time:2021-06-30T18:54:23.066659Z, application-name:connections, cost-center:1369, Backup:default-ec2

---

#### 🟢 DJFRAWL001

- **Resource ID**: `i-091018420cfabc406`
- **Region**: us-west-2
- **Current Monthly Cost**: $32.22
- **Potential Monthly Savings**: $32.22
- **Risk Level**: 🟢 Low
- **Reason**: Instance stopped 10 days ago with minimal historical usage (avg CPU 8.8%)
- **Recommended Action**: Strong candidate for termination - create AMI backup if needed
- **Tags**: cfg:build-by:NOC Team, cfg:business-criticality:low, ApplyPatch:true, cfg:data-classification:internal, cfg:Anti-Virus:Yes, cfg:cost-center:1369, cfg:Hostname:DJFRAWL001, aws:ec2launchtemplate:version:1, cfg:Monitoring:Yes, cfg:app-name:JFrog Artifactory, cfg:SME:Hitesh Patel, cfg:Description:Service-Catalog-EC2-Reference-Architecture, cfg:os-version:rhel8, Name:DJFRAWL001, Backup:default-ec2, Patch Group:rhel, cfg:environment:dev, cfg:build-date:07192023, aws:ec2launchtemplate:id:lt-0d5975cd88f72d0c6, cfg:IT-App-Owner:Hitesh Patel

---

#### 🟢 DMANAWW001.one.ad

- **Resource ID**: `i-046339015c503682b`
- **Region**: us-west-2
- **Current Monthly Cost**: $67.80
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Instance stopped recently (0 days ago) - may be temporarily stopped for weekends/maintenance
- **Recommended Action**: Monitor usage pattern - consider scheduling or rightsizing if consistently underused
- **Tags**: cfg:os-version:w2019, cfg:cost-center:1369, cfg:Monitoring:Yes, cfg:IT-App-Owner:Alex Tsekhanskiy, cfg:Hostname:DMANAWW001.one.ad, Patch Group:windows, cfg:app-name:Server Management, aws:servicecatalog:provisioningArtifactIdentifier:pa-w72regqkru6b6, aws:cloudformation:stack-name:SC-317980596581-pp-kn42ybl2dgj2w, aws:servicecatalog:provisioningPrincipalArn:arn:aws:sts::317980596581:assumed-role/AWSReservedSSO_CFG-Administrator_8f451a0d4fc00e50/ADM-NHiebert@ceteracorp.com, cfg:business-criticality:low, InstanceScheduler-LastAction:Stopped By cfg-instance-scheduler-hub-nonprod 2025/10/29 01:00UTC, cfg:Anti-Virus:Yes, cfg:schedule:cfg-instance-scheduler-nonprod-schedule-server-management-1, aws:servicecatalog:provisionedProductArn:arn:aws:servicecatalog:us-west-2:317980596581:stack/DMANAWW001/pp-kn42ybl2dgj2w, aws:servicecatalog:productArn:arn:aws:catalog:us-west-2:317980596581:product/prod-4irgrv6fsmkjg, Backup:default-ec2, cfg:SME:Nathan Hiebert, Name:DMANAWW001.one.ad, cfg:build by:Nathan Hiebert, aws:cloudformation:logical-id:WindowsInstance, cfg:Description:Service-Catalog-EC2-Reference-Architecture, aws:servicecatalog:portfolioArn:arn:aws:catalog:us-west-2:317980596581:portfolio/port-pxd52jhq2zf2u, cfg:environment:dev, cfg:build-date:01262023, ApplyPatch:true, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/SC-317980596581-pp-kn42ybl2dgj2w/6522b3b0-9dc3-11ed-a54e-0a591ec2db67, cfg:data-classification:internal

---

#### 🟢 DMANAWW004.ceteracorp.com

- **Resource ID**: `i-0e82cbddcd7bfffdc`
- **Region**: us-west-2
- **Current Monthly Cost**: $77.15
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Instance stopped recently (0 days ago) - may be temporarily stopped for weekends/maintenance
- **Recommended Action**: Monitor usage pattern - consider scheduling or rightsizing if consistently underused
- **Tags**: cfg:cost-center:1369, cfg:Monitoring:Yes, aws:servicecatalog:provisionedProductArn:arn:aws:servicecatalog:us-west-2:317980596581:stack/DMANAWW004/pp-fk5dzaliypwic, cfg:app-name:Server Management, cfg:os-version:w2019, Name:DMANAWW004.ceteracorp.com, Patch Group:windows, aws:servicecatalog:provisioningPrincipalArn:arn:aws:sts::317980596581:assumed-role/AWSReservedSSO_CFG-NOC-L2-System-Administrator_b792fe50754436de/ADM-VRaj@ceteracorp.com, aws:cloudformation:stack-name:SC-317980596581-pp-fk5dzaliypwic, aws:servicecatalog:provisioningArtifactIdentifier:pa-w72regqkru6b6, cfg:business-criticality:low, cfg:build-date:1272023, InstanceScheduler-LastAction:Stopped By cfg-instance-scheduler-hub-nonprod 2025/10/29 01:00UTC, cfg:Anti-Virus:Yes, cfg:IT-App-Owner:Narendran Ravindran, cfg:build by:NOC Team, cfg:schedule:cfg-instance-scheduler-nonprod-schedule-server-management-2, cfg:SME:Eric Edralin, cfg:environment:dev, aws:servicecatalog:productArn:arn:aws:catalog:us-west-2:317980596581:product/prod-4irgrv6fsmkjg, cfg:Hostname:DMANAWW004.ceteracorp.com, Backup:default-ec2, cfg:Description:Service-Catalog-EC2-Reference-Architecture, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/SC-317980596581-pp-fk5dzaliypwic/0ba5dfa0-9e91-11ed-9845-02cb1f966a6b, aws:cloudformation:logical-id:WindowsInstance, aws:servicecatalog:portfolioArn:arn:aws:catalog:us-west-2:317980596581:portfolio/port-pxd52jhq2zf2u, cfg:data-classification:internal, ApplyPatch:true

---

### 💰 RDS Instance (1 resources)

**Potential Monthly Savings**: $130.04

#### 🔴 N/A

- **Resource ID**: `cfg-connections-non-prod-db-se`
- **Region**: us-west-2
- **Current Monthly Cost**: $130.04
- **Potential Monthly Savings**: $130.04
- **Risk Level**: 🔴 High
- **Reason**: No database connections over 30 days
- **Recommended Action**: Create final snapshot and terminate
- **Tags**: application-name:connections, map-migrated-app:NA, application-owner:petricia.wijono@cetera.com, resource-name:rds, aws-migration-project-id:MPE11706, broker-services:NA, cost-center:1369, map-migrated:d-server-02f0gef5g24uv2, environment:non-prod, application-portfolio:corporate-applications, business-unit:IT, map-dba:d-server-023qfxhskulc0a

---

### 💰 EBS Snapshot (394 resources)

**Potential Monthly Savings**: $970.70

#### 🔴 N/A

- **Resource ID**: `snap-0555d9defae3714b4`
- **Region**: us-west-2
- **Current Monthly Cost**: $24.00
- **Potential Monthly Savings**: $24.00
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 624 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-08d3748215b5f8cdb`
- **Region**: us-west-2
- **Current Monthly Cost**: $12.00
- **Potential Monthly Savings**: $12.00
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 528 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 aac-linux-image-062021

- **Resource ID**: `snap-00897c5fa0d44a5c0`
- **Region**: us-west-2
- **Current Monthly Cost**: $12.00
- **Potential Monthly Savings**: $12.00
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1591 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:aac-linux-image-062021

---

#### 🔴 N/A

- **Resource ID**: `snap-028f8822f3d4d08d9`
- **Region**: us-west-2
- **Current Monthly Cost**: $12.00
- **Potential Monthly Savings**: $12.00
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1616 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 aac-with-shared-keys

- **Resource ID**: `snap-06223f2b96797cc6d`
- **Region**: us-west-2
- **Current Monthly Cost**: $12.00
- **Potential Monthly Savings**: $12.00
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1615 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:aac-with-shared-keys

---

#### 🟡 N/A

- **Resource ID**: `snap-0d9d225c169c4593a`
- **Region**: us-west-2
- **Current Monthly Cost**: $12.00
- **Potential Monthly Savings**: $12.00
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1615 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 aac-latest

- **Resource ID**: `snap-0be6c65c68acc4e0c`
- **Region**: us-west-2
- **Current Monthly Cost**: $12.00
- **Potential Monthly Savings**: $12.00
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1615 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:aac-latest

---

#### 🔴 N/A

- **Resource ID**: `snap-059c9d713da3e6b02`
- **Region**: us-west-2
- **Current Monthly Cost**: $12.00
- **Potential Monthly Savings**: $12.00
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 582 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-00d7a52c2f2f53a8a`
- **Region**: us-west-2
- **Current Monthly Cost**: $12.00
- **Potential Monthly Savings**: $12.00
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 528 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-09c31ea27edd380b6`
- **Region**: us-west-2
- **Current Monthly Cost**: $10.56
- **Potential Monthly Savings**: $10.56
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 575 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0426e476b79379d9f`
- **Region**: us-west-2
- **Current Monthly Cost**: $9.60
- **Potential Monthly Savings**: $9.60
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0c4ffd4dc3fa28898`
- **Region**: us-west-2
- **Current Monthly Cost**: $9.60
- **Potential Monthly Savings**: $9.60
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 423 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0bfee6a90d3a88ad4`
- **Region**: us-west-2
- **Current Monthly Cost**: $9.60
- **Potential Monthly Savings**: $9.60
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 423 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-05132721bf8a682af`
- **Region**: us-west-2
- **Current Monthly Cost**: $9.60
- **Potential Monthly Savings**: $9.60
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0c048c1dbd01e1866`
- **Region**: us-west-2
- **Current Monthly Cost**: $9.60
- **Potential Monthly Savings**: $9.60
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 395 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-05153e2070647104e`
- **Region**: us-west-2
- **Current Monthly Cost**: $7.20
- **Potential Monthly Savings**: $7.20
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 528 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0da4f6e74d84997e2`
- **Region**: us-west-2
- **Current Monthly Cost**: $7.20
- **Potential Monthly Savings**: $7.20
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 291 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-088850e09a5115a84`
- **Region**: us-west-2
- **Current Monthly Cost**: $7.20
- **Potential Monthly Savings**: $7.20
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1257 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0cfda5172efe56982`
- **Region**: us-west-2
- **Current Monthly Cost**: $7.20
- **Potential Monthly Savings**: $7.20
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1274 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: APP:JIRA

---

#### 🔴 N/A

- **Resource ID**: `snap-0176b902e300718db`
- **Region**: us-west-2
- **Current Monthly Cost**: $7.20
- **Potential Monthly Savings**: $7.20
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1253 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0bb08b3ab105b5830`
- **Region**: us-west-2
- **Current Monthly Cost**: $7.20
- **Potential Monthly Savings**: $7.20
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1254 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-034e95a319703fa17`
- **Region**: us-west-2
- **Current Monthly Cost**: $7.20
- **Potential Monthly Savings**: $7.20
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 736 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0f0660eb9cf1d2182`
- **Region**: us-west-2
- **Current Monthly Cost**: $7.20
- **Potential Monthly Savings**: $7.20
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 106 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0e01e49652afd7f36`
- **Region**: us-west-2
- **Current Monthly Cost**: $7.20
- **Potential Monthly Savings**: $7.20
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 620 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0fa3319e297d34135`
- **Region**: us-west-2
- **Current Monthly Cost**: $5.28
- **Potential Monthly Savings**: $5.28
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 106 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0630f92420699a41a`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1596 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 Connections-2019-3drives

- **Resource ID**: `snap-0a4aa5b80eb798a71`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1600 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:Connections-2019-3drives

---

#### 🔴 Connections-2019-3drives

- **Resource ID**: `snap-08e87b8d36d88bdec`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1600 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:Connections-2019-3drives

---

#### 🔴 N/A

- **Resource ID**: `snap-07bb6d1c3c67b3044`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1642 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0382d84f3a512319d`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0ea63da8593567e51`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 Connections-2019-3drives

- **Resource ID**: `snap-05dc547a40bb3f9da`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1600 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:Connections-2019-3drives

---

#### 🔴 N/A

- **Resource ID**: `snap-0c8ef0eea02f8ec4c`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0a1426909de5046de`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 Connections-2019-3-drives-v3-bkup

- **Resource ID**: `snap-067fe728f1b9c928a`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1597 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:Connections-2019-3-drives-v3-bkup

---

#### 🔴 Connections-2019-3-drives-v3-bkup

- **Resource ID**: `snap-0e998b80726ee98da`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1597 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:Connections-2019-3-drives-v3-bkup

---

#### 🔴 Connections-2019-3-drives-v3-bkup

- **Resource ID**: `snap-0692eb4955c78e5ae`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1597 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:Connections-2019-3-drives-v3-bkup

---

#### 🔴 Connections-2019-3drives-loaded

- **Resource ID**: `snap-022077d5bb012f69f`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1597 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:Connections-2019-3drives-loaded

---

#### 🔴 Connections-2019-3drives-loaded

- **Resource ID**: `snap-0580a84a46b9ac3c7`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1597 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:Connections-2019-3drives-loaded

---

#### 🔴 connections-2019-3-drives-no-apps

- **Resource ID**: `snap-0660bdc97b0b7de6c`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1597 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:connections-2019-3-drives-no-apps

---

#### 🔴 N/A

- **Resource ID**: `snap-002e026d2582ba73a`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1636 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 Connections-2019-3drives-loaded

- **Resource ID**: `snap-06e8756abceb1752c`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1597 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:Connections-2019-3drives-loaded

---

#### 🔴 connections-2019-3-drives-no-apps

- **Resource ID**: `snap-01d1602b4cc30b18f`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1597 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:connections-2019-3-drives-no-apps

---

#### 🔴 connections-2019-3-drives-no-apps

- **Resource ID**: `snap-04ffa4b5ce3ab0a76`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1597 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:connections-2019-3-drives-no-apps

---

#### 🔴 bb-dev2

- **Resource ID**: `snap-009dc41e6401a32a6`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1600 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:bb-dev2

---

#### 🔴 N/A

- **Resource ID**: `snap-0648f8fbf1e62be17`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 770 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-082f7c26fd344a3d7`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 770 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0c6c598cc84830a9e`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.80
- **Potential Monthly Savings**: $4.80
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 770 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0e8914dfa8a8cdcb6`
- **Region**: us-west-2
- **Current Monthly Cost**: $3.89
- **Potential Monthly Savings**: $3.89
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1034 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-039a65cc82daba681`
- **Region**: us-west-2
- **Current Monthly Cost**: $3.84
- **Potential Monthly Savings**: $3.84
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 326 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-081ebf2b1dec404b6`
- **Region**: us-west-2
- **Current Monthly Cost**: $3.84
- **Potential Monthly Savings**: $3.84
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 327 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-03dd6c2226d68e521`
- **Region**: us-west-2
- **Current Monthly Cost**: $3.84
- **Potential Monthly Savings**: $3.84
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 329 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-04f47cc76ac2bb3d2`
- **Region**: us-west-2
- **Current Monthly Cost**: $3.84
- **Potential Monthly Savings**: $3.84
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-06baf43b1819985b6`
- **Region**: us-west-2
- **Current Monthly Cost**: $3.84
- **Potential Monthly Savings**: $3.84
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1636 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-08d5128e8134c39e4`
- **Region**: us-west-2
- **Current Monthly Cost**: $3.84
- **Potential Monthly Savings**: $3.84
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-08f87044a6ae8b91b`
- **Region**: us-west-2
- **Current Monthly Cost**: $3.84
- **Potential Monthly Savings**: $3.84
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 280 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0d7bca810b7c57be3`
- **Region**: us-west-2
- **Current Monthly Cost**: $3.84
- **Potential Monthly Savings**: $3.84
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 319 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0b9c073773a2c1a8c`
- **Region**: us-west-2
- **Current Monthly Cost**: $3.84
- **Potential Monthly Savings**: $3.84
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 280 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0baa68d68cfdce9b8`
- **Region**: us-west-2
- **Current Monthly Cost**: $3.84
- **Potential Monthly Savings**: $3.84
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 153 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0d78ecd12e4d04c37`
- **Region**: us-west-2
- **Current Monthly Cost**: $3.84
- **Potential Monthly Savings**: $3.84
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 153 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0a64f0fea69d4a240`
- **Region**: us-west-2
- **Current Monthly Cost**: $3.84
- **Potential Monthly Savings**: $3.84
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 181 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-052e423cda7d96f0c`
- **Region**: us-west-2
- **Current Monthly Cost**: $3.84
- **Potential Monthly Savings**: $3.84
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 364 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-04230142e977aa5a1`
- **Region**: us-west-2
- **Current Monthly Cost**: $3.84
- **Potential Monthly Savings**: $3.84
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 375 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-04e56abca87931888`
- **Region**: us-west-2
- **Current Monthly Cost**: $3.36
- **Potential Monthly Savings**: $3.36
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 55 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0443a90706feb2e43`
- **Region**: us-west-2
- **Current Monthly Cost**: $3.36
- **Potential Monthly Savings**: $3.36
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 54 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-06fff89364ca8d3d7`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1020 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-02520e3dd1ddce17f`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1264 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0fd8a5f829738eb90`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 337 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-09b263a6a298d3190`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 362 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0a99e42f06d013107`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 648 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-028deef7e8ed3ca3b`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 649 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-07204f3d998d96126`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 797 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-06fae478167308b6c`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 96 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-05078be11a7f2e085`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 573 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-02c82f27f48e67134`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0b8d4c748f0b3fef4`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1358 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-028facbf72dd6b0a3`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1596 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-01e9d76a4b429f66f`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 855 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0bad7a69d37ee84ba`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 923 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0bd85184dd639861d`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1358 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0b4339707abeb06e9`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 528 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-03820b5da259c187b`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 624 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0c00139666216aacc`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 923 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0163a842bf288e67b`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 291 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-054334b29532c9493`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 395 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-076410dfcd18c3da4`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 853 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 bb-dev2

- **Resource ID**: `snap-05d4acd2f28718f65`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1600 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:bb-dev2

---

#### 🔴 N/A

- **Resource ID**: `snap-05bad8f0c3d885d33`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 643 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0585f829be583e83f`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 423 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0ca817675659c80c6`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 528 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-04cafc1ac9a4b7f4d`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 200 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0c571313195e4e222`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1632 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0f5b86741f305cbd9`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1262 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0b8bc40dc8df4dcc1`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1357 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-07f632e87f3f3d423`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 649 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0a75d3dface25753c`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1055 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0f799ea1c8101dd3b`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 423 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0f7a27a118a09e2d6`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 733 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0626f4d578b2ac75b`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 66 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-056907c6d78d7df54`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 357 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0dcf0bf64e9e9091f`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 361 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0b0052b9703d24ac6`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 649 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0c33ba587011f5892`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 929 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0796bcd9a1cbc8e97`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1019 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-01c9903519e0afe3e`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1184 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-09b40f329ad510641`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0ca70db836364d8eb`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 291 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-03d21024a4977eafb`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 329 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0511b820bb54b8e8d`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 395 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-016cade5c7bf00a54`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 423 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-04b2e5735ecb5d8bd`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 528 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-037ac6b31abfd1633`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 528 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-04099cbea144acfec`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.88
- **Potential Monthly Savings**: $2.88
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 649 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 aac-windows-image-062021

- **Resource ID**: `snap-08715e14243c9f05e`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.40
- **Potential Monthly Savings**: $2.40
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1591 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:aac-windows-image-062021

---

#### 🔴 N/A

- **Resource ID**: `snap-0a16bac0a13ba64aa`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.40
- **Potential Monthly Savings**: $2.40
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-02c83de2f10c061a9`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.40
- **Potential Monthly Savings**: $2.40
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 770 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0a72964ea0409f0b3`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.40
- **Potential Monthly Savings**: $2.40
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 770 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0fcbd8328336167b7`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.40
- **Potential Monthly Savings**: $2.40
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 837 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-01b2769f8f6a6dca3`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.16
- **Potential Monthly Savings**: $2.16
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1146 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-030a1329292b1952e`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.16
- **Potential Monthly Savings**: $2.16
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1147 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-087808f4d73b256db`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.16
- **Potential Monthly Savings**: $2.16
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1148 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0612e5c865593c961`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.11
- **Potential Monthly Savings**: $2.11
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 528 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-06884df4ad00f328a`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.11
- **Potential Monthly Savings**: $2.11
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 291 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0849e16778dc7111b`
- **Region**: us-west-2
- **Current Monthly Cost**: $2.11
- **Potential Monthly Savings**: $2.11
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 423 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-02079a92894b0eee9`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 797 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0e865c78013a674ca`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 929 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0a7603d1d85dc19ab`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 993 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0e1a8d672f8103faa`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1135 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-091b51036d5c45ad2`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1137 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-038de328310fb62a6`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1192 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0d8e2fe40e7c4f609`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0a69669fc31a5ad35`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1257 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-000a3cc02c13b4d9b`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1264 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0ab1de17474b9e822`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1264 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-040610cc3fcb2083a`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1274 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: APP:JIRA

---

#### 🔴 N/A

- **Resource ID**: `snap-0502b705a0feabd04`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1327 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-035bd7fcfb1ad722a`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1364 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-076eb67e807b1dc42`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 423 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0c3634d2d1343001b`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 620 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0c6c53b4421054de9`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 648 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-05b91fee9470b1cb5`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 649 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-06510beeeacbc0020`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 649 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-023899818140ed2ff`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 649 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-07fa204f66898db1f`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 736 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0c6ef3d51a893d764`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 749 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-082b86d57030a518e`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 749 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0f84318ff0130ffca`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 749 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-01affab585162cc89`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 750 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-04e10fc5284f80c48`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 750 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-02d33fca43153865d`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 788 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-07ddd4f72d35e4e42`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 865 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0287297630ee3aff4`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 919 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0cc311be8529bda27`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 946 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-09fba5b6b4055eb54`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 181 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-00c3106e1503ec42d`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 423 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-00e60b5beb71e958b`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 96 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0f047900045cf8fb2`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 106 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-05522f70c5dac2a85`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 106 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0d79d96abd4f2452d`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1135 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-07bd8fea24cc3d71d`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1254 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0a25263667c37c6d9`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1263 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0e742208bdf7f18af`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1267 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-03e9ce6ffcb7a0d84`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1268 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0e7b43c58d1f60ddb`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1281 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0ff8f4af01c217ac8`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 291 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0d065c7b96774a073`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 528 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-088ea26cfd4a293e8`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 837 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-08f22ff196593d1db`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1019 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0de6af788108b6729`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1082 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0f83b823471c8fb4d`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1137 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0ee35a528b7113dd4`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1263 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0f3b7bbe0ef47812f`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1267 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0e01b722f2ed2e858`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1268 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0ca6c8b8a503d9c7c`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1357 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-090193791b9e2bb0f`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1357 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-028b4927479c0c3a2`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 106 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-09d91a07c05eb4516`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 575 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-08a0bf9652e43483f`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 867 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-063f93f83ba4662bf`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 575 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0b871d55bb16b918c`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 620 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-091c32e00a2dfb245`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 649 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-05b682fb5ceb23777`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1141 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-09c154553cf116afc`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1146 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0bd4ed1a95e6d9d81`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1147 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-027e4267b3d342ca8`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1148 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-095271edfacef90f7`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1149 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0517b9ad88c4b1784`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1151 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0bfff55ada4948ddc`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1184 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0974a0a246c86ba3c`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1192 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-017a99597ecb1bc63`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1236 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0edd7035cc7eee3ae`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1236 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0b34fb6853f23c2b3`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1267 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0dd913d519b4428ff`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1279 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-027840244d6f40da0`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1279 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-09aa2f3b244d90d2a`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1327 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-02e301e238db7838a`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1356 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0ec054fdafbf2bb1c`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 649 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0f20d3a05ff6f1437`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 649 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-041e3782eaaa5a050`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 792 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-03fc5cf8859a22d48`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 792 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0d5d0f48f288b6036`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 865 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-055b413a8be772787`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 919 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0f8c265a2c346d3a9`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 395 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-03f6757eadb1d84d6`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 650 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-081c0607022e59c7e`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 793 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-03f4d0ce72b1b72b2`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 54 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0f1d6039b159f64dd`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 200 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-02fa473b081e7b5b0`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1632 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-09f53c2d1e31692f6`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1264 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0b842d77ba946bb73`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1351 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0321c88cae23ba7df`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1351 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0ebb1276a6c0c0a0e`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1356 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-02663e85eb7d5c84d`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1358 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-01755a98069a96cb0`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1364 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0286ec1e52dfdde98`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 649 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-01f074432d6d27c2d`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 649 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0d6950b5dce02e8fa`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 650 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0edab4f433943137f`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 749 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0d66f9421550ec750`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 749 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-09518ca8a391dd2cb`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 749 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0f1d04d8a0225fd99`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 929 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-02bab6ae715b16d85`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1054 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-084c6468de91d881e`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1055 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-038dcc81b8dca9620`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 620 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0c5ea25d1bd512e3e`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 643 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-06e1a29882eb925af`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 649 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-05414096145f212c9`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 651 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-076c41c206b033d49`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 651 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-048cc46918ea266ba`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 750 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-08a9cb0fb65721c0c`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 867 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0323085a3714e989d`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 993 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0bf6e09cd870a2037`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1020 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-006e92f6e17343d24`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1054 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0ae7062bdfab89b4d`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1082 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-004a97c6d1aaa0e13`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 55 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0ee4ce0d64d057224`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 181 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-05035e25274f741b3`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 195 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-07decc6a8a77e535c`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 329 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-057527e16d36525c3`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 361 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0cae5bccbd66373ad`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 372 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0d9d7f4ad935cb875`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 66 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-03eef13bd93f2cc97`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 106 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0187dd2e468447be0`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 337 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-054071a86715ce4a8`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 357 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0ded82b8ff6fae06c`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 371 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0592eeaa1a16739f8`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 793 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-02298dacb181e0cf2`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 802 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0e56bc936316b0584`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 923 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0179de80eb4f16bb1`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1141 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0180f68d9e4fcc528`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1149 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-07c49b8d057611ee6`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1151 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-039c48248b44cb505`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0324b042aea25c6cf`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0180d6fb9627ef13a`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1253 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-034f1676232e24278`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1262 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-095093026d3c75a58`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1267 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0706e40e5483d98b7`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1281 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0ccafa98bedfb23c2`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 371 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-095dd5b5900a6130d`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 573 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0dc819d973d242cb7`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 649 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0641f9d561dbed3ef`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 649 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-09ace056ff8dc1cb8`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 651 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-065472810e164d57c`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 733 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-02d8537d850284472`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 750 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0427960d96ea0d643`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 792 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-060869528c22cd9df`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 799 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-032ba5252beaee057`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 855 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0217dd81329cd575d`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 923 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-086271f1ad2778b8e`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 195 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0d8434614eb91010d`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 362 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-00e1ee103054fa5f9`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 372 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0a74dc4dfba9e72e0`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 649 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0e7914f145cf7ea29`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 651 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0c7232dd3c8628349`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 792 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-07d97c11e85936cc0`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 853 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0d57c40280fac3cde`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 929 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-02f1fcc9c038974cc`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.92
- **Potential Monthly Savings**: $1.92
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 946 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-03addbf74ac72afba`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.68
- **Potential Monthly Savings**: $1.68
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 106 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0970f38d29dc32364`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.68
- **Potential Monthly Savings**: $1.68
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 575 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0f8b58a2ea6a94c4c`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.63
- **Potential Monthly Savings**: $1.63
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 582 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 aac-with-shared-keys

- **Resource ID**: `snap-0fe62091520e9a179`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.44
- **Potential Monthly Savings**: $1.44
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1615 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:aac-with-shared-keys

---

#### 🔴 N/A

- **Resource ID**: `snap-074ed7ef029756a4d`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.44
- **Potential Monthly Savings**: $1.44
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 817 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 dela-final2

- **Resource ID**: `snap-0562d7af86cedc0a9`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.44
- **Potential Monthly Savings**: $1.44
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1498 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:dela-final2

---

#### 🔴 N/A

- **Resource ID**: `snap-0b60991788be17c47`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.44
- **Potential Monthly Savings**: $1.44
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 aac-linux-image-062021

- **Resource ID**: `snap-0c046d607104d7fcb`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.44
- **Potential Monthly Savings**: $1.44
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1591 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:aac-linux-image-062021

---

#### 🔴 aac-latest

- **Resource ID**: `snap-0ede1e15da82bc523`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.44
- **Potential Monthly Savings**: $1.44
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1615 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:aac-latest

---

#### 🔴 N/A

- **Resource ID**: `snap-0d691820d09e6eb97`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.44
- **Potential Monthly Savings**: $1.44
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1616 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0c4d8851e51c38b57`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.44
- **Potential Monthly Savings**: $1.44
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 802 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0af49326701309fe6`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.44
- **Potential Monthly Savings**: $1.44
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 799 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0844351349317a545`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.44
- **Potential Monthly Savings**: $1.44
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1615 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0e9507305054bb887`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.44
- **Potential Monthly Savings**: $1.44
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 788 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0f0c8ef3f79603431`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.44
- **Potential Monthly Savings**: $1.44
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1625 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0f022ab3db02eb641`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.44
- **Potential Monthly Savings**: $1.44
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1597 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-039bf98fedcbe1a65`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.44
- **Potential Monthly Savings**: $1.44
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 582 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-08f8ce9896258f0c4`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.44
- **Potential Monthly Savings**: $1.44
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 816 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 ddbpawl001-image

- **Resource ID**: `snap-0a940c509a2ec3e7c`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.44
- **Potential Monthly Savings**: $1.44
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1531 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:ddbpawl001-image

---

#### 🔴 N/A

- **Resource ID**: `snap-0f320045dc84f3fb9`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.44
- **Potential Monthly Savings**: $1.44
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1595 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-00e8a0cdb9d77298b`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.44
- **Potential Monthly Savings**: $1.44
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-01216c35ea65c0a67`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.44
- **Potential Monthly Savings**: $1.44
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-07f74f6b3252b998a`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.25
- **Potential Monthly Savings**: $1.25
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 620 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-09084b3d49cd7d573`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.25
- **Potential Monthly Savings**: $1.25
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 106 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-03c3021da51ee7795`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.20
- **Potential Monthly Savings**: $1.20
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 620 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0b63d3015da734f2b`
- **Region**: us-west-2
- **Current Monthly Cost**: $1.20
- **Potential Monthly Savings**: $1.20
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 106 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0a2abf622137e91dd`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.96
- **Potential Monthly Savings**: $0.96
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 770 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 dela-final2

- **Resource ID**: `snap-0f21e94f204415536`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.96
- **Potential Monthly Savings**: $0.96
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1498 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:dela-final2

---

#### 🔴 ddbpawl001-image

- **Resource ID**: `snap-0f6fd35cef3a42fc5`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.96
- **Potential Monthly Savings**: $0.96
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1531 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:ddbpawl001-image

---

#### 🔴 N/A

- **Resource ID**: `snap-0b81d9bfd6351822e`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.96
- **Potential Monthly Savings**: $0.96
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0e4c4022ad1f96dfc`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.96
- **Potential Monthly Savings**: $0.96
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0072f9e32cf424e9b`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.82
- **Potential Monthly Savings**: $0.82
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 573 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0fc3b4747f9b49df4`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.82
- **Potential Monthly Savings**: $0.82
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 55 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0b2e051cf5aa3ef30`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.82
- **Potential Monthly Savings**: $0.82
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 291 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-08af8c374bca3e082`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.82
- **Potential Monthly Savings**: $0.82
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 54 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-02fb5fb90cdd41ba1`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.72
- **Potential Monthly Savings**: $0.72
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 423 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-07a910f730ebbbfbb`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.72
- **Potential Monthly Savings**: $0.72
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 423 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0e5525f24cf829e31`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.72
- **Potential Monthly Savings**: $0.72
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-08f1935ab302fc518`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.72
- **Potential Monthly Savings**: $0.72
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 181 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-051ae5e6342b81dfd`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.72
- **Potential Monthly Savings**: $0.72
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 372 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0177eb6ad5ea95290`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.72
- **Potential Monthly Savings**: $0.72
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 649 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0dc62059f901085d9`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.72
- **Potential Monthly Savings**: $0.72
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 649 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0e8c2fc89148084b9`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.72
- **Potential Monthly Savings**: $0.72
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 651 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-01322fb8aa89786c4`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.72
- **Potential Monthly Savings**: $0.72
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 371 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-07f0c7dbfaa8aff8d`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.72
- **Potential Monthly Savings**: $0.72
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 395 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-084596da0da8e05e7`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.72
- **Potential Monthly Savings**: $0.72
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 650 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-08b58aef04fe47d09`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.72
- **Potential Monthly Savings**: $0.72
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 651 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-03fbf19eef86d3ba6`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.72
- **Potential Monthly Savings**: $0.72
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-012800755e7eec66b`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.62
- **Potential Monthly Savings**: $0.62
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1632 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-09a04a2bebd3d86ab`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.62
- **Potential Monthly Savings**: $0.62
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1596 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 bb-dev2

- **Resource ID**: `snap-053ec9d8517492444`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.62
- **Potential Monthly Savings**: $0.62
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1600 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:bb-dev2

---

#### 🔴 N/A

- **Resource ID**: `snap-0800003de1af9241a`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 797 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0aaaedaa5a63d6889`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1184 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0f19780cec7cdb705`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1262 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0e1ccd7f9f017b670`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1264 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0455dc0f693817810`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 337 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0a26340ae0fc05c35`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 923 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-07d5076934f6ecc8c`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 923 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-00761e43650dba80b`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 624 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-09c6b7ffb20b29682`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 649 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-06f48fd40ca52acf0`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 649 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0e5b32d7c77972ecd`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 853 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-021689f5f6fa47208`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 855 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0663bc18d4dce96d5`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1019 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-06ad9147eefa4d5d5`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1055 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0e4ecc41a11c9d40a`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-06c9feb375ed44690`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 649 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-00660fbc4f1ab556e`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 329 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0dab0380dbc32ef7e`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 528 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-012ddbcebcab8a29a`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 66 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0d09d17f4394c2b65`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1636 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0baa4131e3e59c826`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-00f091f97851d4db7`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0e1be786494ddb046`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1358 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0356e092c44c6bd23`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 528 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-04030232a1bb2866b`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 528 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0201bc5557cec45d6`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 648 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-05f1921dfd6f3eb01`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 643 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-00e8e2b81cfb176f5`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 96 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-00affb2ace0c36193`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 200 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0cc383120a3bf1cac`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1020 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-00410218bd749b9ad`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 799 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0a5fc637db7f26862`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 802 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0435083d3a7611891`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 357 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0993ee013d843f3b2`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 361 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-090140c3336c8880c`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 362 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0199bbf1fced66b4a`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 649 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-053045b197e935698`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 733 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-089a6833a3ecf78fd`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 788 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-06689aade0363d260`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.58
- **Potential Monthly Savings**: $0.58
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 929 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0282b89cb06ee4984`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.48
- **Potential Monthly Savings**: $0.48
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1595 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-086504eb3db4df5ce`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.48
- **Potential Monthly Savings**: $0.48
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 aac-with-shared-keys

- **Resource ID**: `snap-0685cd36effb283ea`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.48
- **Potential Monthly Savings**: $0.48
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1615 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:aac-with-shared-keys

---

#### 🔴 N/A

- **Resource ID**: `snap-03fe16fec0ecb8e27`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.48
- **Potential Monthly Savings**: $0.48
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0b07fb05af5789c14`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.48
- **Potential Monthly Savings**: $0.48
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 770 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0bfe68ecae003fb6d`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.48
- **Potential Monthly Savings**: $0.48
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 770 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0c0a28a8620ec107b`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.48
- **Potential Monthly Savings**: $0.48
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1595 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-01401056a038678e5`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.48
- **Potential Monthly Savings**: $0.48
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1595 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0a0c57622a78ba178`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.48
- **Potential Monthly Savings**: $0.48
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1597 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0e896090846fdd5a4`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.48
- **Potential Monthly Savings**: $0.48
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-08107853d37c2779f`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.48
- **Potential Monthly Savings**: $0.48
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-0dce83e34e79807f2`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.48
- **Potential Monthly Savings**: $0.48
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 385 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0032cdb017bf3ef49`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.48
- **Potential Monthly Savings**: $0.48
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1597 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 N/A

- **Resource ID**: `snap-00d1e978916a971e5`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.48
- **Potential Monthly Savings**: $0.48
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 1615 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0ab4c1a103596b95d`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.48
- **Potential Monthly Savings**: $0.48
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-06c023cd3d135cab7`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.48
- **Potential Monthly Savings**: $0.48
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-04571c9127d65d2cd`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.48
- **Potential Monthly Savings**: $0.48
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1597 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0c083774e9b700267`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.48
- **Potential Monthly Savings**: $0.48
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 770 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 aac-linux-image-062021

- **Resource ID**: `snap-000ac242ab30b5f06`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.48
- **Potential Monthly Savings**: $0.48
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1591 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:aac-linux-image-062021

---

#### 🔴 aac-latest

- **Resource ID**: `snap-098611e95088cfa10`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.48
- **Potential Monthly Savings**: $0.48
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1615 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: Name:aac-latest

---

#### 🔴 N/A

- **Resource ID**: `snap-0a9cf51c63d520905`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.48
- **Potential Monthly Savings**: $0.48
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1616 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-08894b23e3eaf5572`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.48
- **Potential Monthly Savings**: $0.48
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 770 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-02a83cb6ee4252c04`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.38
- **Potential Monthly Savings**: $0.38
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🔴 N/A

- **Resource ID**: `snap-0a6dd087c977a7e66`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.38
- **Potential Monthly Savings**: $0.38
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 AWS Elastic Disaster Recovery Base Snapshot

- **Resource ID**: `snap-05f28134eff4aba93`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.05
- **Potential Monthly Savings**: $0.05
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 171 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: AWSElasticDisasterRecoveryManaged:drs.amazonaws.com, Name:AWS Elastic Disaster Recovery Base Snapshot

---

#### 🔴 N/A

- **Resource ID**: `snap-05961c12158ea6188`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.05
- **Potential Monthly Savings**: $0.05
- **Risk Level**: 🔴 High
- **Reason**: Snapshot is 1214 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements

---

#### 🟡 AWS Elastic Disaster Recovery NON-SRIOV Base Snapshot

- **Resource ID**: `snap-0b149bd623be23917`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.05
- **Potential Monthly Savings**: $0.05
- **Risk Level**: 🟡 Medium
- **Reason**: Snapshot is 171 days old, exceeding 35-day retention policy from AWS Backup service policy
- **Recommended Action**: Review and delete if beyond business retention requirements
- **Tags**: AWSElasticDisasterRecoveryManaged:drs.amazonaws.com, Name:AWS Elastic Disaster Recovery NON-SRIOV Base Snapshot

---

### 💰 Network Load Balancer (2 resources)

**Potential Monthly Savings**: $41.48

#### 🟡 cfg-sso-broker-qa-nlb

- **Resource ID**: `cfg-sso-broker-qa-nlb`
- **Region**: us-west-2
- **Current Monthly Cost**: $20.74
- **Potential Monthly Savings**: $20.74
- **Risk Level**: 🟡 Medium
- **Reason**: No healthy targets in target groups
- **Recommended Action**: Delete unused load balancer
- **Tags**: cfg:app-name:sso-broker, cfg:environment:qa

---

#### 🟡 aac-qa-NLB-Win

- **Resource ID**: `aac-qa-NLB-Win`
- **Region**: us-west-2
- **Current Monthly Cost**: $20.74
- **Potential Monthly Savings**: $20.74
- **Risk Level**: 🟡 Medium
- **Reason**: No healthy targets in target groups
- **Recommended Action**: Delete unused load balancer
- **Tags**: application-name:aac, cfg:data-classification:internal, cfg:icfr:false, resource-name:nlb, cfg:app-id:867-5309, cfg:environment:qa, aws-migration-project-id:MPE11706, cfg:business-criticality:medium, map-migrated:d-server-03uehmyde7zrmp, cfg:build-date:11172021, cfg:app-name:aac, cfg:cost-center:1369, cfg:owner-operated:true

---

### 💰 Application Load Balancer (7 resources)

**Potential Monthly Savings**: $145.18

#### 🟡 telecom-dev-alb

- **Resource ID**: `telecom-dev-alb`
- **Region**: us-west-2
- **Current Monthly Cost**: $20.74
- **Potential Monthly Savings**: $20.74
- **Risk Level**: 🟡 Medium
- **Reason**: No healthy targets in target groups
- **Recommended Action**: Delete unused load balancer
- **Tags**: application-name:telecom, map-migrated:d-server-03uxtx3no8ubgy, environment:non-prod, application-portfolio:NA, map-migrated-app:NA, application-owner:akhil.chandra@cetera.com, resource-name:alb, Name:cfg-oregon-shared-infra-non-prod-alb-telecom, aws-migration-project-id:MPE11706, broker-services:NA, business-unit:NA, cost-center:1369

---

#### 🟡 dsnqalb

- **Resource ID**: `dsnqalb`
- **Region**: us-west-2
- **Current Monthly Cost**: $20.74
- **Potential Monthly Savings**: $20.74
- **Risk Level**: 🟡 Medium
- **Reason**: No healthy targets in target groups
- **Recommended Action**: Delete unused load balancer

---

#### 🟡 artifactory-dev

- **Resource ID**: `artifactory-dev`
- **Region**: us-west-2
- **Current Monthly Cost**: $20.74
- **Potential Monthly Savings**: $20.74
- **Risk Level**: 🟡 Medium
- **Reason**: No healthy targets in target groups
- **Recommended Action**: Delete unused load balancer

---

#### 🟡 rabbitmq-qa-alb

- **Resource ID**: `rabbitmq-qa-alb`
- **Region**: us-west-2
- **Current Monthly Cost**: $20.74
- **Potential Monthly Savings**: $20.74
- **Risk Level**: 🟡 Medium
- **Reason**: No healthy targets in target groups
- **Recommended Action**: Delete unused load balancer
- **Tags**: ingress.k8s.aws/resource:LoadBalancer, ingress.k8s.aws/stack:rabbitmq/rabbitmq-qa-ingress, elbv2.k8s.aws/cluster:cfg-adviceworks-qa-cluster-bootstrap-test

---

#### 🟡 Snyk-ALB

- **Resource ID**: `Snyk-ALB`
- **Region**: us-west-2
- **Current Monthly Cost**: $20.74
- **Potential Monthly Savings**: $20.74
- **Risk Level**: 🟡 Medium
- **Reason**: No healthy targets in target groups
- **Recommended Action**: Delete unused load balancer
- **Tags**: Application:Snyk

---

#### 🟡 cfg-sso-broker-qa-alb

- **Resource ID**: `cfg-sso-broker-qa-alb`
- **Region**: us-west-2
- **Current Monthly Cost**: $20.74
- **Potential Monthly Savings**: $20.74
- **Risk Level**: 🟡 Medium
- **Reason**: No healthy targets in target groups
- **Recommended Action**: Delete unused load balancer
- **Tags**: cfg:app-name:sso-broker, cfg:environment:qa

---

#### 🟡 cfg-servicenow-test-alb

- **Resource ID**: `cfg-servicenow-test-alb`
- **Region**: us-west-2
- **Current Monthly Cost**: $20.74
- **Potential Monthly Savings**: $20.74
- **Risk Level**: 🟡 Medium
- **Reason**: No healthy targets in target groups
- **Recommended Action**: Delete unused load balancer

---

### 💰 EBS Volume (2 resources)

**Potential Monthly Savings**: $7.00

#### 🟢 N/A

- **Resource ID**: `vol-0cd548501dfe45a88`
- **Region**: us-west-2
- **Current Monthly Cost**: $4.00
- **Potential Monthly Savings**: $4.00
- **Risk Level**: 🟢 Low
- **Reason**: Volume is unattached and not in use
- **Recommended Action**: Create snapshot and delete volume

---

#### 🟢 N/A

- **Resource ID**: `vol-08a9c0c06650683d1`
- **Region**: us-west-2
- **Current Monthly Cost**: $3.00
- **Potential Monthly Savings**: $3.00
- **Risk Level**: 🟢 Low
- **Reason**: Volume is unattached and not in use
- **Recommended Action**: Create snapshot and delete volume

---

### 💰 Elastic IP (2 resources)

**Potential Monthly Savings**: $7.30

#### 🟢 N/A

- **Resource ID**: `54.185.35.138`
- **Region**: us-west-2
- **Current Monthly Cost**: $3.65
- **Potential Monthly Savings**: $3.65
- **Risk Level**: 🟢 Low
- **Reason**: Elastic IP is not associated with any resource
- **Recommended Action**: Release unused Elastic IP
- **Tags**: aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-directconnect-poc/f2dd2f50-5f8e-11ed-be08-06ca88c9f751, aws:cloudformation:logical-id:NatGateway2EIP, aws:cloudformation:stack-name:cfg-directconnect-poc

---

#### 🟢 N/A

- **Resource ID**: `54.218.176.95`
- **Region**: us-west-2
- **Current Monthly Cost**: $3.65
- **Potential Monthly Savings**: $3.65
- **Risk Level**: 🟢 Low
- **Reason**: Elastic IP is not associated with any resource
- **Recommended Action**: Release unused Elastic IP
- **Tags**: aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-directconnect-poc/f2dd2f50-5f8e-11ed-be08-06ca88c9f751, aws:cloudformation:stack-name:cfg-directconnect-poc, aws:cloudformation:logical-id:NatGateway1EIP

---

### 💰 Lambda Function (27 resources)

**Potential Monthly Savings**: $0.00

#### 🟡 tagging-MyLambdaFunction-Zi9WHGji07i7

- **Resource ID**: `tagging-MyLambdaFunction-Zi9WHGji07i7`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:MyLambdaFunction, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/tagging/09e16cf0-dd51-11eb-bb3d-0a5fe9e3122b, aws:cloudformation:stack-name:tagging

---

#### 🟡 cfg-cfn-macros-ExplodeMacroStack-47B-MacroFunction-PWIe69AswRl9

- **Resource ID**: `cfg-cfn-macros-ExplodeMacroStack-47B-MacroFunction-PWIe69AswRl9`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:MacroFunction, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-cfn-macros-ExplodeMacroStack-47BELQF02GEO/f34f5020-7532-11ee-8ba8-0a94e30dd90d, aws:cloudformation:stack-name:cfg-cfn-macros-ExplodeMacroStack-47BELQF02GEO, lambda:createdBy:SAM

---

#### 🟡 tagging-CreateInputFolderLambdaFunction-flyAGnnfdttY

- **Resource ID**: `tagging-CreateInputFolderLambdaFunction-flyAGnnfdttY`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:CreateInputFolderLambdaFunction, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/tagging/09e16cf0-dd51-11eb-bb3d-0a5fe9e3122b, aws:cloudformation:stack-name:tagging

---

#### 🟡 cwsyn-test-canary-bcda1396-641d-43b6-ac36-134c464796d5

- **Resource ID**: `cwsyn-test-canary-bcda1396-641d-43b6-ac36-134c464796d5`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed

---

#### 🟡 cwsyn-cfg-canary-brklc-wiki-a91277c3-b1b6-4031-8c3c-0e5c6301c6c6

- **Resource ID**: `cwsyn-cfg-canary-brklc-wiki-a91277c3-b1b6-4031-8c3c-0e5c6301c6c6`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed

---

#### 🟡 cwsyn-cfg-canary-wiki-c4fd8816-03d8-4d8a-8d27-cb31b7be6849

- **Resource ID**: `cwsyn-cfg-canary-wiki-c4fd8816-03d8-4d8a-8d27-cb31b7be6849`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed

---

#### 🟡 factory-initialization-stack-StartInstallLambda-we3SjoajOcCL

- **Resource ID**: `factory-initialization-stack-StartInstallLambda-we3SjoajOcCL`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: ServiceCatalogFactory:Actor:Framework, aws:cloudformation:logical-id:StartInstallLambda, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/factory-initialization-stack/c9a743b0-61f8-11ee-9e13-0a482b98b53f, aws:cloudformation:stack-name:factory-initialization-stack

---

#### 🟡 puppet-initialization-stack-StartInstallLambda-0ZEjnRsnEFvC

- **Resource ID**: `puppet-initialization-stack-StartInstallLambda-0ZEjnRsnEFvC`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:StartInstallLambda, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/puppet-initialization-stack/2b150ef0-61fb-11ee-9d3c-06fb26805acf, aws:cloudformation:stack-name:puppet-initialization-stack

---

#### 🟡 replication-macro

- **Resource ID**: `replication-macro`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:rTransformFunction, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-cfn-macros-ReplicationMacroStack-10XWFK6I3K89A/f3453e00-7532-11ee-b63c-06d22554bb49, aws:cloudformation:stack-name:cfg-cfn-macros-ReplicationMacroStack-10XWFK6I3K89A

---

#### 🟡 cfg-aac-5-ami-restarter-lin-qa

- **Resource ID**: `cfg-aac-5-ami-restarter-lin-qa`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:LambdaFunction1, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/aac5/62b0da10-4a4c-11ec-8dd0-021edf13797d, aws:cloudformation:stack-name:aac5

---

#### 🟡 Testrail-function

- **Resource ID**: `Testrail-function`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed

---

#### 🟡 cfg-aac-5-ami-restarter-win-qa

- **Resource ID**: `cfg-aac-5-ami-restarter-win-qa`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:LambdaFunction2, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/aac5/62b0da10-4a4c-11ec-8dd0-021edf13797d, aws:cloudformation:stack-name:aac5

---

#### 🟡 EC2-Instance-Scheduler

- **Resource ID**: `EC2-Instance-Scheduler`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed

---

#### 🟡 Automation-UpdateSsmParam

- **Resource ID**: `Automation-UpdateSsmParam`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed

---

#### 🟡 cfg-aac-6-instance-cweupdater-win-qa

- **Resource ID**: `cfg-aac-6-instance-cweupdater-win-qa`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:LambdaFunction2Win, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/aac6/cbe64b00-4a4c-11ec-8c57-0675fb4b332d, aws:cloudformation:stack-name:aac6

---

#### 🟡 cfg-aac-6-instance-cweupdater-lin-qa

- **Resource ID**: `cfg-aac-6-instance-cweupdater-lin-qa`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:LambdaFunction2, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/aac6/cbe64b00-4a4c-11ec-8c57-0675fb4b332d, aws:cloudformation:stack-name:aac6

---

#### 🟡 cfg-aac-7-instance-tgupdater-lin-qa

- **Resource ID**: `cfg-aac-7-instance-tgupdater-lin-qa`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:LambdaFunction2, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/aac7/3c355c70-4a4d-11ec-8797-0aa76c236d81, aws:cloudformation:stack-name:aac7

---

#### 🟡 cfg-cfn-macros-PyPlateMacroStack-TransformFunction-NjSvVMmWp5ah

- **Resource ID**: `cfg-cfn-macros-PyPlateMacroStack-TransformFunction-NjSvVMmWp5ah`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:TransformFunction, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-cfn-macros-PyPlateMacroStack-1HB36QMRSMISV/f342f410-7532-11ee-a00e-0aefbb48e0c7, aws:cloudformation:stack-name:cfg-cfn-macros-PyPlateMacroStack-1HB36QMRSMISV

---

#### 🟡 aws-controltower-NotificationForwarder

- **Resource ID**: `aws-controltower-NotificationForwarder`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:ForwardSnsNotification, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/StackSet-AWSControlTowerBP-BASELINE-CLOUDWATCH-c47dd926-55f7-4793-8fad-4197f2c2d2ff/c251a540-6d1a-11eb-bd23-0aa04a59775b, aws:cloudformation:stack-name:StackSet-AWSControlTowerBP-BASELINE-CLOUDWATCH-c47dd926-55f7-4793-8fad-4197f2c2d2ff

---

#### 🟡 snow-test-lambda-function

- **Resource ID**: `snow-test-lambda-function`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:LambdaFunction, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-lambda-function-stack/f0cacc50-64c6-11f0-837c-063d6b888981, aws:cloudformation:stack-name:cfg-lambda-function-stack

---

#### 🟡 cfg-aac-7-instance-tgupdater-win-qa

- **Resource ID**: `cfg-aac-7-instance-tgupdater-win-qa`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:LambdaFunction2Win, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/aac7/3c355c70-4a4d-11ec-8797-0aa76c236d81, aws:cloudformation:stack-name:aac7

---

#### 🟡 ecs-test-function-delete

- **Resource ID**: `ecs-test-function-delete`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed

---

#### 🟡 cfg-aac-3-ami-ssm-InstanceID-updater-win-qa

- **Resource ID**: `cfg-aac-3-ami-ssm-InstanceID-updater-win-qa`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:LambdaFunctionSSMInstanceIDUpdater, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/aac3/a2266b70-4816-11ec-83c6-0aef7a7ead71, aws:cloudformation:stack-name:aac3

---

#### 🟡 cfg-aac-2-ami-ssm-InstanceID-updater-lin-qa

- **Resource ID**: `cfg-aac-2-ami-ssm-InstanceID-updater-lin-qa`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:LambdaFunctionSSMInstanceIDUpdater, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/aac2/dbc051d0-4815-11ec-a1d6-021cb123b7ed, aws:cloudformation:stack-name:aac2

---

#### 🟡 johno_test_function

- **Resource ID**: `johno_test_function`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed

---

#### 🟡 cfg-aac-2-ami-ssm-updater-lin-qa

- **Resource ID**: `cfg-aac-2-ami-ssm-updater-lin-qa`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed
- **Tags**: aws:cloudformation:logical-id:LambdaFunctionSSMUpdater, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/aac2/dbc051d0-4815-11ec-a1d6-021cb123b7ed, aws:cloudformation:stack-name:aac2

---

#### 🟡 cfg-tyler-johnson

- **Resource ID**: `cfg-tyler-johnson`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Lambda function has not been invoked in 30 days
- **Recommended Action**: Review and delete if no longer needed

---

### 💰 Network Interface (7 resources)

**Potential Monthly Savings**: $0.00

#### 🟢 DISEAWL001-nic

- **Resource ID**: `eni-0d367fe1a754beebd`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Network interface is not attached to any resource
- **Recommended Action**: Delete if not needed for future use
- **Tags**: Name:DISEAWL001-nic

---

#### 🟢 N/A

- **Resource ID**: `eni-0a97752656a51941f`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Network interface is not attached to any resource
- **Recommended Action**: Delete if not needed for future use

---

#### 🟢 DISEAWL002-nic

- **Resource ID**: `eni-0967750d2b4c6ef8e`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Network interface is not attached to any resource
- **Recommended Action**: Delete if not needed for future use
- **Tags**: Name:DISEAWL002-nic

---

#### 🟢 N/A

- **Resource ID**: `eni-016b8e22bf6dbe5d9`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Network interface is not attached to any resource
- **Recommended Action**: Delete if not needed for future use

---

#### 🟢 N/A

- **Resource ID**: `eni-0eec9b1ede4824a26`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Network interface is not attached to any resource
- **Recommended Action**: Delete if not needed for future use

---

#### 🟢 elasticwitnessENI

- **Resource ID**: `eni-02b66005677515437`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Network interface is not attached to any resource
- **Recommended Action**: Delete if not needed for future use
- **Tags**: Name:elasticwitnessENI

---

#### 🟢 N/A

- **Resource ID**: `eni-0ab6d23e06d156e0f`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Network interface is not attached to any resource
- **Recommended Action**: Delete if not needed for future use

---

### 🔒 Security Group (74 resources)

**Potential Monthly Savings**: $0.00

#### 🟢 cfg-shared-infra-non-prod-rds-jumpbox-ec2-RDSJumpboxSecurityGroup-DEN7XF0W5FO2

- **Resource ID**: `sg-05127a3edebbcd651`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: aws:cloudformation:stack-name:cfg-shared-infra-non-prod-rds-jumpbox-ec2, map-migrated:NA, business-unit:NA, environment:dev, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-shared-infra-non-prod-rds-jumpbox-ec2/bf1e25a0-bec9-11eb-afde-02881debe6b9, application-portfolio:NA, broker-services:NA, map-migrated-app:NA, Name:cfg-oregon-shared-infra-non-prod-rds-jumpbox-sg, cost-center:1369, aws:cloudformation:logical-id:RDSJumpboxSecurityGroup, aws-migration-project-id:MPE11706, application-owner:NA

---

#### 🟢 cfg-shared-infra-non-prod-connections-alb-ALBSecurityGroup-AH9AE3XK2Y4P

- **Resource ID**: `sg-0f57188c667623545`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-shared-infra-non-prod-connections-alb/995602e0-ceb7-11eb-9898-0ab5c8335b93, aws:cloudformation:stack-name:cfg-shared-infra-non-prod-connections-alb, environment:non-prod, map-migrated-app:NA, Name:cfg-oregon-shared-infra-non-prod-alb-sg-connections, aws:cloudformation:logical-id:ALBSecurityGroup, aws-migration-project-id:MPE11706, application-portfolio:corporate-applications, map-migrated:d-server-02f0gef5g24uv2, cost-center:1369, broker-services:NA, application-owner:petricia.wijono@cetera.com, business-unit:IT, application-name:connections

---

#### 🟢 FMManagedSecurityGroupa791f4d2-5920-401e-a54b-2405232473e0-sg-05c3895ce38381a3a-vpc-0ebe25c4ffbf5cb0c

- **Resource ID**: `sg-07006636a019cac69`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMManaged:a791f4d2-5920-401e-a54b-2405232473e0, fms-policy-name:cfg-ipam-app-sg-1

---

#### 🟢 connections-test-ce7169

- **Resource ID**: `sg-053f4d12bfa0eef71`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: CloudEndure creation time:2021-06-30T18:54:20.257037Z, Original id:sg-0a5a512dd768b03a8

---

#### 🟢 cfg-ITDR-endpoints-dev-sg

- **Resource ID**: `sg-068a256646ef2b586`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface

---

#### 🟢 hp-test-mssql-db-bb

- **Resource ID**: `sg-04d67a0fa1a986654`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface

---

#### 🟢 cfg-oregon-shared-infra-non-prod-alb-sg-ecs-ec2-jenkins

- **Resource ID**: `sg-0c04b260202d5540e`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: aws:cloudformation:logical-id:LoadBalancerSecurityGroup, cost-center:1369, broker-services:all, environment:dev, map-migrated:d-server-00hqxntllej62x, application-name:jenkins, application-owner:hitesh.patel@cetera.com, business-unit:IT-infra, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-shared-infra-non-prod-ecs-ec2-jenkins-dev-master/86205480-ceaa-11eb-abd4-0aafaec40dc9, aws:cloudformation:stack-name:cfg-shared-infra-non-prod-ecs-ec2-jenkins-dev-master, map-migrated-app:NA, aws-migration-project-id:MPE11706, Name:cfg-oregon-shared-infra-non-prod-alb-sg-ecs-ec2-jenkins, application-portfolio:0

---

#### 🟢 cfg-security-group-wiki-DBSecurityGroup-10XNZU3Q7AGTI

- **Resource ID**: `sg-087648d4346d8cd1e`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: cost-center:1369, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-security-group-wiki/23bda010-9c62-11eb-8a05-065e4333b4d9, aws:cloudformation:stack-name:cfg-security-group-wiki, Name:cfg-oregon-shared-infra-non-prod-db-sg-wiki, aws:cloudformation:logical-id:DBSecurityGroup, environment:dev, application-name:wiki

---

#### 🟢 cfg-oregon-shared-infra-non-prod-db-sg-ipam

- **Resource ID**: `sg-01d26bfed90ecad16`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: cost-center:1369, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-shared-infra-non-prod-ipam-sg/740792f0-c549-11eb-83bd-06280882db19, application-portfolio:NA, map-migrated-app:NA, broker-services:NA, map-migrated:d-server-03ig6rnv8u2q5a, aws-migration-project-id:MPE11706, environment:non-prod, Name:cfg-oregon-shared-infra-non-prod-db-sg-ipam, aws:cloudformation:stack-name:cfg-shared-infra-non-prod-ipam-sg, aws:cloudformation:logical-id:DBSecurityGroup, business-unit:IT-infra, application-owner:akhil.chandra@cetera.com

---

#### 🟢 FMManagedSecurityGroup9a64ec1e-d0b8-49fa-b707-252ce71315a4-sg-0d276755416d90dee-vpc-0728b75d9cf27199c

- **Resource ID**: `sg-0cfe0a058bca41d48`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMManaged:9a64ec1e-d0b8-49fa-b707-252ce71315a4, FMCleanup:False, Name:cfg-master-fm-core-sg-1-cf, fms-policy-name:cfg-master-fm-core-sg-1

---

#### 🟢 cfg-oregon-shared-infra-non-prod-app-sg-IncidentCommunicationTool

- **Resource ID**: `sg-071b6de0b848a35de`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface

---

#### 🟢 FMManagedSecurityGroup88d23a82-7be7-4195-87a6-3a35eb9a3225-sg-039c6b341866b16b9-vpc-0ad3ec262f3c6be48

- **Resource ID**: `sg-0939035723ecfa192`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMManaged:88d23a82-7be7-4195-87a6-3a35eb9a3225, fms-policy-name:cfg-jenkins-app-sg-1

---

#### 🟢 FMManagedSecurityGroup7bff6fc2-2c17-45ce-8f12-315e023730b4-sg-0d4349608506d5f9d-vpc-0ad3ec262f3c6be48

- **Resource ID**: `sg-026e93d4b22391c40`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMManaged:7bff6fc2-2c17-45ce-8f12-315e023730b4, fms-policy-name:cfg-telecomdb-app-sg-1

---

#### 🟢 hp-bb-test-DBSecurityGroup-1KKFFEFBJL4YY

- **Resource ID**: `sg-055dbfa8c169555d1`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: aws:cloudformation:logical-id:DBSecurityGroup, environment:dev, application-name:BitBucket, aws:cloudformation:stack-name:hp-bb-test, cost-center:1369, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/hp-bb-test/cd2d1be0-c934-11eb-989c-0a5b109659bd, Name:HP-cfg-oregon-shared-infra-non-prod-db-sg-bitbucket

---

#### 🟢 cfg-oregon-shared-infra-non-prod-app-sg-ipam

- **Resource ID**: `sg-09ec202639327d5fc`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: aws-migration-project-id:MPE11706, environment:non-prod, business-unit:IT-infra, application-owner:akhil.chandra@cetera.com, aws:cloudformation:stack-name:cfg-shared-infra-non-prod-ipam-sg, broker-services:NA, Name:cfg-oregon-shared-infra-non-prod-app-sg-ipam, cost-center:1369, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-shared-infra-non-prod-ipam-sg/740792f0-c549-11eb-83bd-06280882db19, application-portfolio:NA, map-migrated-app:NA, map-migrated:d-server-03ig6rnv8u2q5a, aws:cloudformation:logical-id:AppSecurityGroup

---

#### 🟢 cfg-oregon-shared-infra-non-prod-app-sg-telecom

- **Resource ID**: `sg-01133ade209acf095`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: aws-migration-project-id:MPE11706, aws:cloudformation:stack-name:cfg-shared-infra-non-prod-telecom-sg, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-shared-infra-non-prod-telecom-sg/bb632d00-c82b-11eb-8ae4-024686c260c3, business-unit:NA, cost-center:1369, Name:cfg-oregon-shared-infra-non-prod-app-sg-telecom, aws:cloudformation:logical-id:AppSecurityGroup, broker-services:NA, map-migrated-app:NA, application-portfolio:NA, application-owner:akhil.chandra@cetera.com, environment:non-prod

---

#### 🟢 cfg-oregon-shared-infra-non-prod-db-sg-ict

- **Resource ID**: `sg-064a4db2097930e0f`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: environment:non-prod, cost-center:1369, aws-migration-project-id:MPE11706, Name:cfg-oregon-shared-infra-non-prod-db-sg-ict, business-unit:NA, aws:cloudformation:logical-id:DBSecurityGroup, map-migrated:d-server-02ynd43isphmmt, map-migrated-app:NA, aws:cloudformation:stack-name:cfg-shared-infra-nonprod-incidentcommunicationtool-sg, broker-services:NA, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-shared-infra-nonprod-incidentcommunicationtool-sg/77a41bd0-be10-11eb-b18e-0ac403330061, application-portfolio:NA

---

#### 🟢 FMManagedSecurityGroupf1628bf2-c26a-4457-8db0-17649a5f0fbe-sg-0a1b2e79ad4320ea6-vpc-0728b75d9cf27199c

- **Resource ID**: `sg-0a66e73f6a69b4960`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMManaged:f1628bf2-c26a-4457-8db0-17649a5f0fbe, fms-policy-name:cfg-aac-app-sg-1

---

#### 🟢 FMManagedSecurityGroupd00f62bf-d866-4a50-a4bb-8cb0234648a6-sg-06c069eb06fe398fa-vpc-0728b75d9cf27199c

- **Resource ID**: `sg-08b50f7b21f8b4a76`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: fms-policy-name:cfg-master-fm-linux-patch-sg, FMManaged:d00f62bf-d866-4a50-a4bb-8cb0234648a6, Name:cfg-master-fm-linux-patch-sg

---

#### 🟢 FMManagedSecurityGroup31b8d680-d4fa-43ee-a3e6-6a4aa0c6be27-sg-021f2a4a160c2f653-vpc-0ebe25c4ffbf5cb0c

- **Resource ID**: `sg-036ce40da161e461f`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: fms-policy-name:cfg-connections-app-sg-1, FMManaged:31b8d680-d4fa-43ee-a3e6-6a4aa0c6be27

---

#### 🟢 FMManagedSecurityGroupd00f62bf-d866-4a50-a4bb-8cb0234648a6-sg-06c069eb06fe398fa-vpc-0ebe25c4ffbf5cb0c

- **Resource ID**: `sg-0aa5667641f2ca622`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMManaged:d00f62bf-d866-4a50-a4bb-8cb0234648a6, Name:cfg-master-fm-linux-patch-sg, fms-policy-name:cfg-master-fm-linux-patch-sg

---

#### 🟢 cfg-infra-non-prod-fsx-goanywhereftp-qa-sg

- **Resource ID**: `sg-0394c54bff0971213`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface

---

#### 🟢 FMManagedSecurityGroup31b8d680-d4fa-43ee-a3e6-6a4aa0c6be27-sg-021f2a4a160c2f653-vpc-0728b75d9cf27199c

- **Resource ID**: `sg-03393404c1460b9d5`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: fms-policy-name:cfg-connections-app-sg-1, FMManaged:31b8d680-d4fa-43ee-a3e6-6a4aa0c6be27

---

#### 🟢 FMManagedSecurityGroupf1628bf2-c26a-4457-8db0-17649a5f0fbe-sg-0a1b2e79ad4320ea6-vpc-0ebe25c4ffbf5cb0c

- **Resource ID**: `sg-0b758b84dde81a453`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: fms-policy-name:cfg-aac-app-sg-1, FMManaged:f1628bf2-c26a-4457-8db0-17649a5f0fbe

---

#### 🟢 FMManagedSecurityGroup88d23a82-7be7-4195-87a6-3a35eb9a3225-sg-039c6b341866b16b9-vpc-0ebe25c4ffbf5cb0c

- **Resource ID**: `sg-0964173e7d69ea9ce`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMManaged:88d23a82-7be7-4195-87a6-3a35eb9a3225, fms-policy-name:cfg-jenkins-app-sg-1

---

#### 🟢 FMManagedSecurityGroup31b8d680-d4fa-43ee-a3e6-6a4aa0c6be27-sg-021f2a4a160c2f653-vpc-0ad3ec262f3c6be48

- **Resource ID**: `sg-0f55319f06d65acbe`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: fms-policy-name:cfg-connections-app-sg-1, FMManaged:31b8d680-d4fa-43ee-a3e6-6a4aa0c6be27

---

#### 🟢 FMManagedSecurityGroup6ec86ced-d428-4199-aa23-66e96418af24-sg-0542fe7c293b8f8cb-vpc-0ebe25c4ffbf5cb0c

- **Resource ID**: `sg-0df782add52fdf1c3`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMManaged:6ec86ced-d428-4199-aa23-66e96418af24, fms-policy-name:cfg-ict-app-sg-1

---

#### 🟢 cfg-shared-infra-non-prod-bitbucket-sg-DBSecurityGroup-M3QBZPPJUHHY

- **Resource ID**: `sg-087c5b6fd1db90968`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: Name:cfg-oregon-shared-infra-non-prod-db-sg-bitbucket, aws:cloudformation:stack-name:cfg-shared-infra-non-prod-bitbucket-sg, cost-center:1369, application-owner:hitesh.patel@cetera.com, environment:dev, map-migrated:d-server-01hakorzuz9ohq, application-name:BitBucket, aws:cloudformation:logical-id:DBSecurityGroup, aws-migration-project-id:MPE11706, business-unit:IT-infra, broker-services:NA, map-migrated-app:NA, application-portfolio:NA, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-shared-infra-non-prod-bitbucket-sg/9e806ef0-ad78-11eb-8eb0-06b6e9e70973

---

#### 🟢 FMManagedSecurityGroup561a68ba-e932-4e9e-a2ba-411df8b7550a-sg-06007a79694567947-vpc-0ebe25c4ffbf5cb0c

- **Resource ID**: `sg-02c81b3a4618e0849`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMManaged:561a68ba-e932-4e9e-a2ba-411df8b7550a, fms-policy-name:cfg-jmeter-app-sg-1

---

#### 🟢 FMManagedSecurityGroup7bff6fc2-2c17-45ce-8f12-315e023730b4-sg-0d4349608506d5f9d-vpc-0ebe25c4ffbf5cb0c

- **Resource ID**: `sg-07c53ffcc9dd198eb`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: fms-policy-name:cfg-telecomdb-app-sg-1, FMManaged:7bff6fc2-2c17-45ce-8f12-315e023730b4

---

#### 🔴 FMManagedSecurityGroupa29d7412-fea9-4a46-b436-2c48e12f7f32-sg-0ebc2528e6697920d-vpc-0ebe25c4ffbf5cb0c

- **Resource ID**: `sg-0839e6cb60e7c83a0`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Security group is not attached to any resource and has security concerns: Port 443 open to internet
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMCleanup:False, Name:cfg-master-fm-core-sg-2-cf, fms-policy-name:cfg-master-fm-core-sg-2, FMManaged:a29d7412-fea9-4a46-b436-2c48e12f7f32

---

#### 🔴 FMManagedSecurityGroupa29d7412-fea9-4a46-b436-2c48e12f7f32-sg-0ebc2528e6697920d-vpc-0728b75d9cf27199c

- **Resource ID**: `sg-064d292cbee5cdc18`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Security group is not attached to any resource and has security concerns: Port 443 open to internet
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMCleanup:False, Name:cfg-master-fm-core-sg-2-cf, FMManaged:a29d7412-fea9-4a46-b436-2c48e12f7f32, fms-policy-name:cfg-master-fm-core-sg-2

---

#### 🟢 cfg-oregon-shared-infra-non-prod-db-sg-telecom

- **Resource ID**: `sg-0679198d3f3ff868e`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: application-portfolio:NA, aws:cloudformation:logical-id:DBSecurityGroup, broker-services:NA, map-migrated-app:NA, cost-center:1369, application-owner:akhil.chandra@cetera.com, environment:non-prod, Name:cfg-oregon-shared-infra-non-prod-db-sg-telecom, aws-migration-project-id:MPE11706, aws:cloudformation:stack-name:cfg-shared-infra-non-prod-telecom-sg, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-shared-infra-non-prod-telecom-sg/bb632d00-c82b-11eb-8ae4-024686c260c3, business-unit:NA

---

#### 🟢 cfg-oregon-shared-infra-non-prod-app-sg-ecs-ec2-jenkins

- **Resource ID**: `sg-0079c9ac8c17a125c`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: aws-migration-project-id:MPE11706, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-shared-infra-non-prod-ecs-ec2-jenkins-dev-master/86205480-ceaa-11eb-abd4-0aafaec40dc9, Name:cfg-oregon-shared-infra-non-prod-app-sg-ecs-ec2-jenkins, aws:cloudformation:logical-id:JenkinsSecurityGroup, application-portfolio:0, broker-services:all, business-unit:IT-infra, aws:cloudformation:stack-name:cfg-shared-infra-non-prod-ecs-ec2-jenkins-dev-master, cost-center:1369, map-migrated-app:NA, application-name:jenkins, application-owner:hitesh.patel@cetera.com, map-migrated:d-server-00hqxntllej62x, environment:dev

---

#### 🟢 cfg-security-group-wiki-EFSSecurityGroup-3NBJ5299IB5E

- **Resource ID**: `sg-0d9ecfec1f5a92a10`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: cost-center:1369, aws:cloudformation:logical-id:EFSSecurityGroup, aws:cloudformation:stack-name:cfg-security-group-wiki, Name:cfg-oregon-shared-infra-non-prod-efs-sg-wiki, environment:dev, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-security-group-wiki/23bda010-9c62-11eb-8a05-065e4333b4d9, application-name:wiki

---

#### 🟢 cfg-oregon-shared-infra-non-prod-alb-sg-ipam

- **Resource ID**: `sg-0dc13ccf905a68925`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: aws-migration-project-id:MPE11706, business-unit:IT-infra, application-owner:akhil.chandra@cetera.com, aws:cloudformation:stack-name:cfg-shared-infra-non-prod-ipam-sg, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-shared-infra-non-prod-ipam-sg/740792f0-c549-11eb-83bd-06280882db19, aws:cloudformation:logical-id:ALBSecurityGroup, broker-services:NA, cost-center:1369, map-migrated-app:NA, Name:cfg-oregon-shared-infra-non-prod-alb-sg-ipam, map-migrated:d-server-03ig6rnv8u2q5a, environment:non-prod, application-portfolio:NA

---

#### 🟢 FMManagedSecurityGroup6ec86ced-d428-4199-aa23-66e96418af24-sg-0542fe7c293b8f8cb-vpc-0728b75d9cf27199c

- **Resource ID**: `sg-055c4de8e4cf932cb`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMManaged:6ec86ced-d428-4199-aa23-66e96418af24, fms-policy-name:cfg-ict-app-sg-1

---

#### 🟢 FMManagedSecurityGroup561a68ba-e932-4e9e-a2ba-411df8b7550a-sg-06007a79694567947-vpc-0ad3ec262f3c6be48

- **Resource ID**: `sg-07c361da6a45ce403`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: fms-policy-name:cfg-jmeter-app-sg-1, FMManaged:561a68ba-e932-4e9e-a2ba-411df8b7550a

---

#### 🟢 FMManagedSecurityGroup561a68ba-e932-4e9e-a2ba-411df8b7550a-sg-06007a79694567947-vpc-0728b75d9cf27199c

- **Resource ID**: `sg-04917ecbbec09d482`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMManaged:561a68ba-e932-4e9e-a2ba-411df8b7550a, fms-policy-name:cfg-jmeter-app-sg-1

---

#### 🟢 FMManagedSecurityGrouped9f6638-daa3-4e7e-936f-df4cd31d7384-sg-090b16d02d96558cc-vpc-0ad3ec262f3c6be48

- **Resource ID**: `sg-068f91a3246ed06cd`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMManaged:ed9f6638-daa3-4e7e-936f-df4cd31d7384, fms-policy-name:cfg-elasticwitness-app-sg-1

---

#### 🟢 FMManagedSecurityGroupa791f4d2-5920-401e-a54b-2405232473e0-sg-05c3895ce38381a3a-vpc-0ad3ec262f3c6be48

- **Resource ID**: `sg-0e34ac9d1e1164e37`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: fms-policy-name:cfg-ipam-app-sg-1, FMManaged:a791f4d2-5920-401e-a54b-2405232473e0

---

#### 🟢 FMManagedSecurityGroup37233bed-88ea-4202-8eae-d2e7ee3e9943-sg-0c13fa4a66a00d6d2-vpc-0ebe25c4ffbf5cb0c

- **Resource ID**: `sg-02a755eaf9529abcc`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMManaged:37233bed-88ea-4202-8eae-d2e7ee3e9943, fms-policy-name:cfg-bitbucket-app-sg-1

---

#### 🔴 FMManagedSecurityGroupa29d7412-fea9-4a46-b436-2c48e12f7f32-sg-0fd079c2d838645d1-vpc-0ebe25c4ffbf5cb0c

- **Resource ID**: `sg-0e0c0653a833d7a43`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Security group is not attached to any resource and has security concerns: Port 443 open to internet
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMManaged:a29d7412-fea9-4a46-b436-2c48e12f7f32, fms-policy-name:cfg-master-fm-core-sg-2

---

#### 🟢 FMManagedSecurityGrouped9f6638-daa3-4e7e-936f-df4cd31d7384-sg-090b16d02d96558cc-vpc-0ebe25c4ffbf5cb0c

- **Resource ID**: `sg-0fa4973f887b254a8`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMManaged:ed9f6638-daa3-4e7e-936f-df4cd31d7384, fms-policy-name:cfg-elasticwitness-app-sg-1

---

#### 🟢 FMManagedSecurityGroup37233bed-88ea-4202-8eae-d2e7ee3e9943-sg-0c13fa4a66a00d6d2-vpc-0728b75d9cf27199c

- **Resource ID**: `sg-029123d71ff23badb`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: fms-policy-name:cfg-bitbucket-app-sg-1, FMManaged:37233bed-88ea-4202-8eae-d2e7ee3e9943

---

#### 🟢 aac-test-ELB

- **Resource ID**: `sg-0ee0c002bb6979b68`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: Name:test-aac-lb

---

#### 🟢 cfg-oregon-shared-infra-non-prod-fargate-app-sg-jenkins

- **Resource ID**: `sg-0280433bb607d931c`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: cost-center:1369, map-migrated-app:NA, application-portfolio:0, broker-services:all, business-unit:IT-infra, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-shared-infra-non-prod-jenkins-dev-master-latest/2d732860-c9d9-11eb-acf5-0af4e95ea6f3, aws-migration-project-id:MPE11706, Name:cfg-oregon-shared-infra-non-prod-app-sg-jenkins, aws:cloudformation:logical-id:JenkinsSecurityGroup, aws:cloudformation:stack-name:cfg-shared-infra-non-prod-jenkins-dev-master-latest, application-name:jenkins, application-owner:hitesh.patel@cetera.com, environment:dev, map-migrated:d-server-00hqxntllej62x

---

#### 🟢 FMManagedSecurityGroup3852998f-4243-4d80-aa62-42f297df5f73-sg-0791b3afe34b4efac-vpc-0ebe25c4ffbf5cb0c

- **Resource ID**: `sg-045e69fdfb0f1582f`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: fms-policy-name:cfg-witness-app-sg-1, FMManaged:3852998f-4243-4d80-aa62-42f297df5f73

---

#### 🔴 FMManagedSecurityGroupa0e-ce8ac7

- **Resource ID**: `sg-0c0aa297cd5740400`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Security group is not attached to any resource and has security concerns: Port 161 open to internet; Port 161 open to internet; Port 443 open to internet; Port -1 open to internet
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: CloudEndure creation time:2021-06-30T18:54:20.511085Z, Original id:sg-08e2f4c35cb435d95, FMManaged:a0e2a036-bb6b-4705-a0c2-65701cf61a05, fms-policy-name:cfg-fm-policy-oregon-managed-common-security-groups

---

#### 🟢 FMManagedSecurityGroupa791f4d2-5920-401e-a54b-2405232473e0-sg-05c3895ce38381a3a-vpc-0728b75d9cf27199c

- **Resource ID**: `sg-0b7eba5ff40291fcc`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: fms-policy-name:cfg-ipam-app-sg-1, FMManaged:a791f4d2-5920-401e-a54b-2405232473e0

---

#### 🟢 FMManagedSecurityGroup7bff6fc2-2c17-45ce-8f12-315e023730b4-sg-0d4349608506d5f9d-vpc-0728b75d9cf27199c

- **Resource ID**: `sg-04cb236ab4e5122e8`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: fms-policy-name:cfg-telecomdb-app-sg-1, FMManaged:7bff6fc2-2c17-45ce-8f12-315e023730b4

---

#### 🟢 cfg-eks-rabbitmq-nonprod-cluster-ControlPlaneSecurityGroup-R4WO6X5LYRLL

- **Resource ID**: `sg-09eea15450b62a170`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: aws:cloudformation:logical-id:ControlPlaneSecurityGroup, Name:cfg-eks-rabbitmq-nonprod-cluster/ControlPlaneSecurityGroup, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-eks-rabbitmq-nonprod-cluster/ace1a0d0-0741-11ed-af3d-0288c454778d, aws:cloudformation:stack-name:cfg-eks-rabbitmq-nonprod-cluster

---

#### 🟢 FMManagedSecurityGroupf1628bf2-c26a-4457-8db0-17649a5f0fbe-sg-0a1b2e79ad4320ea6-vpc-0ad3ec262f3c6be48

- **Resource ID**: `sg-075122de61d86e7de`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: fms-policy-name:cfg-aac-app-sg-1, FMManaged:f1628bf2-c26a-4457-8db0-17649a5f0fbe

---

#### 🟢 AAC-test-windows

- **Resource ID**: `sg-048dc642f45b4fa65`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: Name:test-aac-windows

---

#### 🔴 FMManagedSecurityGroupa29d7412-fea9-4a46-b436-2c48e12f7f32-sg-06375c953f383f653-vpc-0ebe25c4ffbf5cb0c

- **Resource ID**: `sg-0f718ea733f56d87c`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Security group is not attached to any resource and has security concerns: Port 443 open to internet
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMManaged:a29d7412-fea9-4a46-b436-2c48e12f7f32, fms-policy-name:cfg-master-fm-core-sg-2, FMCleanup:false, Name:cfg-master-fm-core-sg-2-cf

---

#### 🟢 cfg-cribl-stream-nlb-dev-sg

- **Resource ID**: `sg-070f33fe14a8145b1`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: cfg:app-name:cribl, cfg:app-portfolio:information-security

---

#### 🟢 FMManagedSecurityGroup9a64ec1e-d0b8-49fa-b707-252ce71315a4-sg-0b59e82a3bf35f9c1-vpc-0ebe25c4ffbf5cb0c

- **Resource ID**: `sg-0bda2007b580d38fa`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMCleanup:false, Name:cfg-master-fm-core-sg-1-cf, fms-policy-name:cfg-master-fm-core-sg-1, FMManaged:9a64ec1e-d0b8-49fa-b707-252ce71315a4

---

#### 🟢 FMManagedSecurityGroup6ec86ced-d428-4199-aa23-66e96418af24-sg-0542fe7c293b8f8cb-vpc-0ad3ec262f3c6be48

- **Resource ID**: `sg-0cc606a4c4aff38b6`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMManaged:6ec86ced-d428-4199-aa23-66e96418af24, fms-policy-name:cfg-ict-app-sg-1

---

#### 🟢 FMManagedSecurityGroup37233bed-88ea-4202-8eae-d2e7ee3e9943-sg-0c13fa4a66a00d6d2-vpc-0ad3ec262f3c6be48

- **Resource ID**: `sg-0c16ba2504f209b2e`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMManaged:37233bed-88ea-4202-8eae-d2e7ee3e9943, fms-policy-name:cfg-bitbucket-app-sg-1

---

#### 🟢 cfg-ITDR-trap-dev-sg

- **Resource ID**: `sg-05e2f95cd2ade3c78`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface

---

#### 🟢 FMManagedSecurityGroup9a64ec1e-d0b8-49fa-b707-252ce71315a4-sg-0d276755416d90dee-vpc-0ebe25c4ffbf5cb0c

- **Resource ID**: `sg-000a775f5f0f81bb3`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMCleanup:False, FMManaged:9a64ec1e-d0b8-49fa-b707-252ce71315a4, Name:cfg-master-fm-core-sg-1-cf, fms-policy-name:cfg-master-fm-core-sg-1

---

#### 🟢 FMManagedSecurityGroup6ad4d581-dfaa-4ac2-a8ad-175bf9053a69-sg-0c2ef9b691c2e730a-vpc-0ebe25c4ffbf5cb0c

- **Resource ID**: `sg-0a1f42fcac2a2e23b`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMManaged:6ad4d581-dfaa-4ac2-a8ad-175bf9053a69, Name:Master-App-Wiki-Sg-1, fms-policy-name:cfg-wiki-app-sg-1

---

#### 🟢 FMManagedSecurityGrouped9f6638-daa3-4e7e-936f-df4cd31d7384-sg-090b16d02d96558cc-vpc-0728b75d9cf27199c

- **Resource ID**: `sg-049d86307ea2e4d81`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: fms-policy-name:cfg-elasticwitness-app-sg-1, FMManaged:ed9f6638-daa3-4e7e-936f-df4cd31d7384

---

#### 🟢 FMManagedSecurityGroup6ad4d581-dfaa-4ac2-a8ad-175bf9053a69-sg-0c2ef9b691c2e730a-vpc-0728b75d9cf27199c

- **Resource ID**: `sg-081327c21ab55a9d2`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: Name:Master-App-Wiki-Sg-1, fms-policy-name:cfg-wiki-app-sg-1, FMManaged:6ad4d581-dfaa-4ac2-a8ad-175bf9053a69

---

#### 🟢 hp-bb-test-AppSecurityGroup-1P5DAR57BUZ9Z

- **Resource ID**: `sg-095faab79d435f8c6`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/hp-bb-test/cd2d1be0-c934-11eb-989c-0a5b109659bd, application-name:BitBucket, aws:cloudformation:stack-name:hp-bb-test, cost-center:1369, Name:cfg-oregon-shared-infra-non-prod-app-sg-bitbucket, environment:dev, aws:cloudformation:logical-id:AppSecurityGroup

---

#### 🟢 FMManagedSecurityGroup3852998f-4243-4d80-aa62-42f297df5f73-sg-0791b3afe34b4efac-vpc-0728b75d9cf27199c

- **Resource ID**: `sg-0f8f514b88cb81276`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMManaged:3852998f-4243-4d80-aa62-42f297df5f73, fms-policy-name:cfg-witness-app-sg-1

---

#### 🟢 k8s-traffic-cfgcribleksdev-5992ce6e73

- **Resource ID**: `sg-0b2a418d19f696edd`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: elbv2.k8s.aws/resource:backend-sg, elbv2.k8s.aws/cluster:cfg-cribl-eks-dev

---

#### 🟢 cfg-shared-infra-non-prod-testrail-sg-AppSecurityGroup-Y7KQAWN12ATK

- **Resource ID**: `sg-00c5f639d93f12f34`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: cost-center:1369, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-shared-infra-non-prod-testrail-sg/24575180-9d32-11eb-9599-02e90b418d6b, aws:cloudformation:stack-name:cfg-shared-infra-non-prod-testrail-sg, Name:cfg-oregon-shared-infra-non-prod-app-sg-testrail, application-name:testrail, environment:dev, aws:cloudformation:logical-id:AppSecurityGroup

---

#### 🟢 FMManagedSecurityGroup88d23a82-7be7-4195-87a6-3a35eb9a3225-sg-039c6b341866b16b9-vpc-0728b75d9cf27199c

- **Resource ID**: `sg-0642179a32bace3aa`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMManaged:88d23a82-7be7-4195-87a6-3a35eb9a3225, fms-policy-name:cfg-jenkins-app-sg-1

---

#### 🟢 FMManagedSecurityGroup9a64ec1e-d0b8-49fa-b707-252ce71315a4-sg-07a94533d14fef221-vpc-0ebe25c4ffbf5cb0c

- **Resource ID**: `sg-04a508ac64fb8d68b`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMManaged:9a64ec1e-d0b8-49fa-b707-252ce71315a4, fms-policy-name:cfg-master-fm-core-sg-1

---

#### 🟢 App-Security-Group-test-AAC-igor

- **Resource ID**: `sg-0d95ef6c360b88fb4`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: Name:test-aac-rhel

---

#### 🟢 FMManagedSecurityGroup6ad4d581-dfaa-4ac2-a8ad-175bf9053a69-sg-0c2ef9b691c2e730a-vpc-0ad3ec262f3c6be48

- **Resource ID**: `sg-0d2168ebe56293528`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: FMManaged:6ad4d581-dfaa-4ac2-a8ad-175bf9053a69, Name:Master-App-Wiki-Sg-1, fms-policy-name:cfg-wiki-app-sg-1

---

#### 🟢 cfg-ITDR-connector-dev-sg

- **Resource ID**: `sg-067eaeb2ec1aa0a9a`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface

---

#### 🟢 cfg-shared-infra-non-prod-bitbucket-sg-AppSecurityGroup-S22AEBV9T62I

- **Resource ID**: `sg-08a1c3cc6550421b7`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: Security group is not attached to any resource
- **Recommended Action**: Delete unused security group to reduce attack surface
- **Tags**: aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-shared-infra-non-prod-bitbucket-sg/9e806ef0-ad78-11eb-8eb0-06b6e9e70973, aws:cloudformation:stack-name:cfg-shared-infra-non-prod-bitbucket-sg, environment:dev, application-owner:hitesh.patel@cetera.com, map-migrated:d-server-01hakorzuz9ohq, Name:cfg-oregon-shared-infra-non-prod-app-sg-bitbucket, business-unit:IT-infra, application-name:BitBucket, aws-migration-project-id:MPE11706, application-portfolio:NA, map-migrated-app:NA, broker-services:NA, aws:cloudformation:logical-id:AppSecurityGroup, cost-center:1369

---

### 🔒 IAM Role (55 resources)

**Potential Monthly Savings**: $0.00

#### 🔴 2022CFGTestv1-Service-Catalog-Managed-Role

- **Resource ID**: `2022CFGTestv1-Service-Catalog-Managed-Role`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 760 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🔴 aac-lin-Lambda-Restart-Role

- **Resource ID**: `aac-lin-Lambda-Restart-Role`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 109 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🔴 aac-lin-Lambda-Role

- **Resource ID**: `aac-lin-Lambda-Role`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 109 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🟡 aac-lin-Lambda-TargetAssign-Role

- **Resource ID**: `aac-lin-Lambda-TargetAssign-Role`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🔴 aac-lin-Lambda-Watchdog-Role

- **Resource ID**: `aac-lin-Lambda-Watchdog-Role`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 1051 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🟡 aac-win-Lambda-Restart-Role

- **Resource ID**: `aac-win-Lambda-Restart-Role`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 aac-win-Lambda-TGUpdater-Role

- **Resource ID**: `aac-win-Lambda-TGUpdater-Role`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 aac-win-Lambda-Watchdog-Role

- **Resource ID**: `aac-win-Lambda-Watchdog-Role`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 AmazonEKSLoadBalancerControllerRole

- **Resource ID**: `AmazonEKSLoadBalancerControllerRole`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 AmazonEKSLoadBalancerControllerRole-2

- **Resource ID**: `AmazonEKSLoadBalancerControllerRole-2`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 AmazonEKS_EBS_CSI_DriverRole

- **Resource ID**: `AmazonEKS_EBS_CSI_DriverRole`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 AmazonEKS_EBS_CSI_DriverRole_2

- **Resource ID**: `AmazonEKS_EBS_CSI_DriverRole_2`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 AmazonEKS_EBS_CSI_DriverRole_3

- **Resource ID**: `AmazonEKS_EBS_CSI_DriverRole_3`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🔴 AMIupdate-RHEL9-LambdaExecutionRole-WyNX1L4T7yw9

- **Resource ID**: `AMIupdate-RHEL9-LambdaExecutionRole-WyNX1L4T7yw9`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 146 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🔴 AMI_July_2025_Patch-Service-Catalog-Managed-Role

- **Resource ID**: `AMI_July_2025_Patch-Service-Catalog-Managed-Role`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 97 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🟡 Automatic-AMIupdate-ASG-Jira-LambdaExecutionRole-AxVRvOd8VO9Q

- **Resource ID**: `Automatic-AMIupdate-ASG-Jira-LambdaExecutionRole-AxVRvOd8VO9Q`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 Automatic-AMIupdate-Jira-ASG-LambdaExecutionRole-lgE7JHea96Nx

- **Resource ID**: `Automatic-AMIupdate-Jira-ASG-LambdaExecutionRole-lgE7JHea96Nx`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 Automatic-AMIupdate-jira-ASG1-LambdaExecutionRole-UjyQUU196znp

- **Resource ID**: `Automatic-AMIupdate-jira-ASG1-LambdaExecutionRole-UjyQUU196znp`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🔴 Automatic-AMIupdate-Jira-ASG2-LambdaExecutionRole-8RICNrdGUCFt

- **Resource ID**: `Automatic-AMIupdate-Jira-ASG2-LambdaExecutionRole-8RICNrdGUCFt`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 148 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🔴 AutomationServiceRole

- **Resource ID**: `AutomationServiceRole`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 186 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🔴 Autoupdate-AMI-LambdaExecutionRole-USKjlSX2701K

- **Resource ID**: `Autoupdate-AMI-LambdaExecutionRole-USKjlSX2701K`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 134 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🟡 AWS-QuickSetup-HostMgmtRole-ap-northeast-1-vy2hr

- **Resource ID**: `AWS-QuickSetup-HostMgmtRole-ap-northeast-1-vy2hr`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk
- **Tags**: QuickSetupVersion:1.1, QuickSetupType:Host Management, QuickSetupID:vy2hr

---

#### 🟡 AWS-QuickSetup-HostMgmtRole-ap-northeast-2-vy2hr

- **Resource ID**: `AWS-QuickSetup-HostMgmtRole-ap-northeast-2-vy2hr`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk
- **Tags**: QuickSetupVersion:1.1, QuickSetupType:Host Management, QuickSetupID:vy2hr

---

#### 🟡 AWS-QuickSetup-HostMgmtRole-ap-south-1-vy2hr

- **Resource ID**: `AWS-QuickSetup-HostMgmtRole-ap-south-1-vy2hr`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk
- **Tags**: QuickSetupVersion:1.1, QuickSetupType:Host Management, QuickSetupID:vy2hr

---

#### 🟡 AWS-QuickSetup-HostMgmtRole-ap-southeast-1-vy2hr

- **Resource ID**: `AWS-QuickSetup-HostMgmtRole-ap-southeast-1-vy2hr`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk
- **Tags**: QuickSetupVersion:1.1, QuickSetupType:Host Management, QuickSetupID:vy2hr

---

#### 🟡 AWS-QuickSetup-HostMgmtRole-ap-southeast-2-vy2hr

- **Resource ID**: `AWS-QuickSetup-HostMgmtRole-ap-southeast-2-vy2hr`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk
- **Tags**: QuickSetupVersion:1.1, QuickSetupType:Host Management, QuickSetupID:vy2hr

---

#### 🟡 AWS-QuickSetup-HostMgmtRole-ca-central-1-vy2hr

- **Resource ID**: `AWS-QuickSetup-HostMgmtRole-ca-central-1-vy2hr`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk
- **Tags**: QuickSetupVersion:1.1, QuickSetupType:Host Management, QuickSetupID:vy2hr

---

#### 🟡 AWS-QuickSetup-HostMgmtRole-eu-central-1-vy2hr

- **Resource ID**: `AWS-QuickSetup-HostMgmtRole-eu-central-1-vy2hr`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk
- **Tags**: QuickSetupVersion:1.1, QuickSetupType:Host Management, QuickSetupID:vy2hr

---

#### 🟡 AWS-QuickSetup-HostMgmtRole-eu-west-1-vy2hr

- **Resource ID**: `AWS-QuickSetup-HostMgmtRole-eu-west-1-vy2hr`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk
- **Tags**: QuickSetupVersion:1.1, QuickSetupType:Host Management, QuickSetupID:vy2hr

---

#### 🟡 AWS-QuickSetup-HostMgmtRole-eu-west-2-vy2hr

- **Resource ID**: `AWS-QuickSetup-HostMgmtRole-eu-west-2-vy2hr`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk
- **Tags**: QuickSetupVersion:1.1, QuickSetupType:Host Management, QuickSetupID:vy2hr

---

#### 🟡 AWS-QuickSetup-HostMgmtRole-eu-west-3-vy2hr

- **Resource ID**: `AWS-QuickSetup-HostMgmtRole-eu-west-3-vy2hr`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk
- **Tags**: QuickSetupVersion:1.1, QuickSetupType:Host Management, QuickSetupID:vy2hr

---

#### 🟡 AWS-QuickSetup-HostMgmtRole-sa-east-1-vy2hr

- **Resource ID**: `AWS-QuickSetup-HostMgmtRole-sa-east-1-vy2hr`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk
- **Tags**: QuickSetupVersion:1.1, QuickSetupType:Host Management, QuickSetupID:vy2hr

---

#### 🟡 AWS-QuickSetup-HostMgmtRole-us-east-1-vy2hr

- **Resource ID**: `AWS-QuickSetup-HostMgmtRole-us-east-1-vy2hr`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk
- **Tags**: QuickSetupVersion:1.1, QuickSetupType:Host Management, QuickSetupID:vy2hr

---

#### 🟡 AWS-QuickSetup-HostMgmtRole-us-east-2-vy2hr

- **Resource ID**: `AWS-QuickSetup-HostMgmtRole-us-east-2-vy2hr`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk
- **Tags**: QuickSetupVersion:1.1, QuickSetupType:Host Management, QuickSetupID:vy2hr

---

#### 🟡 AWS-QuickSetup-HostMgmtRole-us-west-1-vy2hr

- **Resource ID**: `AWS-QuickSetup-HostMgmtRole-us-west-1-vy2hr`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk
- **Tags**: QuickSetupVersion:1.1, QuickSetupType:Host Management, QuickSetupID:vy2hr

---

#### 🟡 AWS-QuickSetup-StackSet-Local-AdministrationRole

- **Resource ID**: `AWS-QuickSetup-StackSet-Local-AdministrationRole`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 AWS-QuickSetup-StackSet-Local-ExecutionRole

- **Resource ID**: `AWS-QuickSetup-StackSet-Local-ExecutionRole`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 AWS-SystemsManager-AutomationExecutionRole

- **Resource ID**: `AWS-SystemsManager-AutomationExecutionRole`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 AWSControlTowerExecution

- **Resource ID**: `AWSControlTowerExecution`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has not been used for 64 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🟡 AWSReservedSSO_AWSAdministratorAccess_e6b3eb794c79d4ce

- **Resource ID**: `AWSReservedSSO_AWSAdministratorAccess_e6b3eb794c79d4ce`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 AWSReservedSSO_AWSOrganizationsFullAccess_71e7d17958cd9ce7

- **Resource ID**: `AWSReservedSSO_AWSOrganizationsFullAccess_71e7d17958cd9ce7`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 AWSReservedSSO_AWSPowerUserAccess_592596855bbccba0

- **Resource ID**: `AWSReservedSSO_AWSPowerUserAccess_592596855bbccba0`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 AWSReservedSSO_AWSReadOnlyAccess_114889088ab10ff2

- **Resource ID**: `AWSReservedSSO_AWSReadOnlyAccess_114889088ab10ff2`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 AWSReservedSSO_CFG-auditor-ro-role_662fbe2f33996f8c

- **Resource ID**: `AWSReservedSSO_CFG-auditor-ro-role_662fbe2f33996f8c`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🔴 AWSReservedSSO_CFG-Cloud-Developer-PowerUser_6ceff28e6a569906

- **Resource ID**: `AWSReservedSSO_CFG-Cloud-Developer-PowerUser_6ceff28e6a569906`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 135 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🟡 AWSReservedSSO_CFG-Cloud-Engineer_895aa59b6d1463fc

- **Resource ID**: `AWSReservedSSO_CFG-Cloud-Engineer_895aa59b6d1463fc`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 AWSReservedSSO_CFG-Cloud-Security-Engineer_34a83550ed41f42e

- **Resource ID**: `AWSReservedSSO_CFG-Cloud-Security-Engineer_34a83550ed41f42e`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 AWSReservedSSO_CFG-Cloud-Security-Read-Only_0dc9d566b8173318

- **Resource ID**: `AWSReservedSSO_CFG-Cloud-Security-Read-Only_0dc9d566b8173318`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🔴 AWSReservedSSO_CFG-NOC-L1-Team-Member_a8a256bf2d63366a

- **Resource ID**: `AWSReservedSSO_CFG-NOC-L1-Team-Member_a8a256bf2d63366a`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 125 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🔴 AWSReservedSSO_CFG-NOC-L3_629c0ff76753e34b

- **Resource ID**: `AWSReservedSSO_CFG-NOC-L3_629c0ff76753e34b`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 160 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🟡 AWSReservedSSO_CFG-Read-Only-User_a572e38412933018

- **Resource ID**: `AWSReservedSSO_CFG-Read-Only-User_a572e38412933018`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 AWSReservedSSO_CFG-Security-Auditor_7d389aa80748714f

- **Resource ID**: `AWSReservedSSO_CFG-Security-Auditor_7d389aa80748714f`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 AWSReservedSSO_CFG-Security-RO_920828176b94c3b2

- **Resource ID**: `AWSReservedSSO_CFG-Security-RO_920828176b94c3b2`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has never been used
- **Recommended Action**: Delete unused role to reduce security risk

---

#### 🟡 AWSReservedSSO_CFG-SOC-Engineer_1113d952bd145b25

- **Resource ID**: `AWSReservedSSO_CFG-SOC-Engineer_1113d952bd145b25`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟡 Medium
- **Reason**: Role has not been used for 77 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

#### 🔴 AWSReservedSSO_CFG-SOC-Team-Member_7b5f4ac91dcce7f3

- **Resource ID**: `AWSReservedSSO_CFG-SOC-Team-Member_7b5f4ac91dcce7f3`
- **Region**: global
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Role has not been used for 524 days
- **Recommended Action**: Review and delete if no longer needed (security risk)

---

### 🔒 ACM Certificate (16 resources)

**Potential Monthly Savings**: $0.00

#### 🔴 aac-test.ceteracorp.com

- **Resource ID**: `2de90012-2806-41da-81d8-9f0bf059c51e`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Certificate has expired
- **Recommended Action**: Delete expired certificate
- **Tags**: Name:test-AAC

---

#### 🔴 telecomdb-dev.one.ad

- **Resource ID**: `05d9f76c-8369-42b0-8c29-7a786fafabd4`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Certificate has expired
- **Recommended Action**: Delete expired certificate
- **Tags**: application-name:telecomdb-amazonlinux-az2, map-migrated:d-server-03uxtx3no8ubgy, environment:dev, Name:cfg-telecomdb-dev-certificate, aws-migration-project-id:MPE11706, cost-center:1369

---

#### 🔴 internal-conn-dev-alb-1268242200.us-west-2.elb.amazonaws.com

- **Resource ID**: `0f45dba3-0aa9-4bfb-9481-f43b1a44da28`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Certificate has expired
- **Recommended Action**: Delete expired certificate
- **Tags**: application-name:connections, map-migrated:d-server-02f0gef5g24uv2, environment:development, Name:cfg-shared-infra-non-prod-conn-alb-temp-ssl, aws-migration-project-id:MPE11706

---

#### 🔴 ipam-dev.one.ad

- **Resource ID**: `807dc230-742c-4f63-b7ea-4f68e5027d49`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Certificate has expired
- **Recommended Action**: Delete expired certificate
- **Tags**: application-name:ipam-lamp-az2, map-migrated:d-server-03ig6rnv8u2q5a, environment:dev, Name:cfg-IPAM-prod-certificate, aws-migration-project-id:MPE11706, cost-center:1369

---

#### 🔴 theconnection-awsdev.cfgcorporate.com

- **Resource ID**: `07b48b28-21d2-4574-9fa1-1a611d179cb9`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Certificate has expired
- **Recommended Action**: Delete expired certificate
- **Tags**: application-name:connections, map-migrated:d-server-02f0gef5g24uv2, environment:development, Name:cfg-shared-infra-non-prod-conn-awsdev-ssl, aws-migration-project-id:MPE11706

---

#### 🔴 theconnection-dev.cfgcorporate.com

- **Resource ID**: `08e4142d-a7cb-4828-97e0-c1ae6b847bcd`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Certificate has expired
- **Recommended Action**: Delete expired certificate
- **Tags**: application-name:connections, map-migrated:d-server-02f0gef5g24uv2, environment:development, Name:cfg-shared-infra-non-prod-conn-ssl, aws-migration-project-id:MPE11706

---

#### 🔴 ipam-dev.one.ad

- **Resource ID**: `a467cb79-ed4d-46b6-af48-35d74783c8c3`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Certificate has expired
- **Recommended Action**: Delete expired certificate
- **Tags**: Name:cfg-IPAM-dev-certificate

---

#### 🔴 Theconnection-0-awsdev.cfgcorporate.com

- **Resource ID**: `5a791255-4ab1-406a-a2e7-14240dd1b961`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Certificate has expired
- **Recommended Action**: Delete expired certificate
- **Tags**: application-name:connections, map-migrated:d-server-02f0gef5g24uv2, environment:development, Name:cfg-shared-infra-non-prod-connections-dev-temp-0-ssl, aws-migration-project-id:MPE11706

---

#### 🔴 bkofce-pinweb.dev.one.cfg

- **Resource ID**: `c4aa427e-c413-4df1-af7d-00efb9910ddb`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Certificate has expired
- **Recommended Action**: Delete expired certificate
- **Tags**: application-name:smartworks, environment:dev, Name:cfg-shared-infra-non-prod-sw-bko-alb-ssl

---

#### 🔴 WUG.one.ad

- **Resource ID**: `4b7038e6-def4-4a70-96e5-31aaa60fc5cf`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Certificate has expired
- **Recommended Action**: Delete expired certificate
- **Tags**: cfg-wug-non-prod:1

---

#### 🔴 repoffice.qa.one.cfg

- **Resource ID**: `cb865227-0ef3-47fb-9ad6-366d042d1938`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Certificate has expired
- **Recommended Action**: Delete expired certificate

---

#### 🔴 sso.qa.cetera.com

- **Resource ID**: `905995d6-6ea7-4490-855e-694af4c6c81d`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Certificate has expired
- **Recommended Action**: Delete expired certificate

---

#### 🔴 qa.api.cetera.com

- **Resource ID**: `d9b621c0-8405-488b-a704-fd86d92d3622`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Certificate has expired
- **Recommended Action**: Delete expired certificate

---

#### 🔴 api.qa.one.cfg

- **Resource ID**: `675f2503-0704-467b-a23a-abcfab9a53b2`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Certificate has expired
- **Recommended Action**: Delete expired certificate

---

#### 🔴 sso.qa.cetera.com

- **Resource ID**: `c2393d04-d1fb-4492-bea7-c5d4757a01cb`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Certificate has expired
- **Recommended Action**: Delete expired certificate

---

#### 🔴 cm.qa.one.cfg

- **Resource ID**: `920c07a0-73f5-41d3-95ec-d26c002162fb`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🔴 High
- **Reason**: Certificate has expired
- **Recommended Action**: Delete expired certificate

---

### 💰 S3 Bucket (15 resources)

**Potential Monthly Savings**: $0.00

#### 🟢 aws-logs-317980596581-us-west-2

- **Resource ID**: `aws-logs-317980596581-us-west-2`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: S3 bucket is empty and unused
- **Recommended Action**: Delete empty bucket to reduce management overhead

---

#### 🟢 cdk-hnb659fds-assets-317980596581-us-west-2

- **Resource ID**: `cdk-hnb659fds-assets-317980596581-us-west-2`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: S3 bucket is empty and unused
- **Recommended Action**: Delete empty bucket to reduce management overhead
- **Tags**: aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/CDKToolkit/278a7430-3811-11f0-a0fc-06a402c05bd1, aws:cloudformation:stack-name:CDKToolkit, aws:cloudformation:logical-id:StagingBucket

---

#### 🟢 cfg-oregon-s3-bucket-databackup-ict-postgres

- **Resource ID**: `cfg-oregon-s3-bucket-databackup-ict-postgres`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: S3 bucket is empty and unused
- **Recommended Action**: Delete empty bucket to reduce management overhead
- **Tags**: application-name:ict, aws:cloudformation:stack-name:cfg-shared-infra-non-prod-ict-rds, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-shared-infra-non-prod-ict-rds/7c2dd540-df23-11eb-b15d-061d76e747b1, map-migrated-app:NA, application-owner:hitesh.aggarwal@cetera.com, resource-name:cfg-oregon-s3-bucket-databackup-ict-postgres, aws-migration-project-id:MPE11706, broker-services:NA, cost-center:1369, map-migrated:d-server-02ynd43isphmmt, environment:dev, application-portfolio:NA, aws:cloudformation:logical-id:DataBackupS3Bucket, business-unit:NA

---

#### 🟢 cfg-oregon-s3-bucket-databackup-testrails

- **Resource ID**: `cfg-oregon-s3-bucket-databackup-testrails`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: S3 bucket is empty and unused
- **Recommended Action**: Delete empty bucket to reduce management overhead
- **Tags**: application-name:testrail, aws:cloudformation:stack-name:cfg-shared-infra-non-prod-testrail-s3, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-shared-infra-non-prod-testrail-s3/8e799140-9d23-11eb-b35c-023aea6cd5b7, map-migrated-app:NA, application-owner:arteom.caterinciuc@cetera.com, resource-name:cfg-oregon-s3-bucket-databackup-testrails, aws-migration-project-id:MPE11706, broker-services:NA, cost-center:1369, map-migrated:d-server-00i769p7ikwac4, environment:dev, application-portfolio:NA, aws:cloudformation:logical-id:DataBackupS3Bucket, business-unit:SDLC

---

#### 🟢 cfg-oregon-s3-bucket-databackup-wiki

- **Resource ID**: `cfg-oregon-s3-bucket-databackup-wiki`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: S3 bucket is empty and unused
- **Recommended Action**: Delete empty bucket to reduce management overhead
- **Tags**: application-name:wiki, aws:cloudformation:stack-name:cfg-s3-wiki, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-s3-wiki/b31e26e0-9c70-11eb-ba63-065c587fbcb5, map-migrated-app:NA, application-owner:igor.scripco@cetera.com, resource-name:cfg-oregon-s3-bucket-databackup-wiki, aws-migration-project-id:MPE11706, broker-services:all, cost-center:1369, map-migrated:d-server-01y3qzv7l1ssy6, environment:dev, application-portfolio:0, aws:cloudformation:logical-id:DataBackupS3Bucket, business-unit:collaboration

---

#### 🟢 cfg-oregon-s3-bucket-databackup-wiki-mssql

- **Resource ID**: `cfg-oregon-s3-bucket-databackup-wiki-mssql`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: S3 bucket is empty and unused
- **Recommended Action**: Delete empty bucket to reduce management overhead
- **Tags**: application-name:wiki, aws:cloudformation:stack-name:cfg-shared-infra-non-prod-wiki-s3-mssql, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-shared-infra-non-prod-wiki-s3-mssql/57c5c1c0-a983-11eb-a0df-02bec35fcb4f, map-migrated-app:NA, application-owner:igor.scripco@cetera.com, resource-name:cfg-oregon-s3-bucket-databackup-wiki-mssql, aws-migration-project-id:MPE11706, broker-services:all, cost-center:1369, map-migrated:d-server-01y3qzv7l1ssy6, environment:dev, application-portfolio:0, aws:cloudformation:logical-id:DataBackupS3Bucket, business-unit:collaboration

---

#### 🟢 cfg-oregon-shared-infra-non-prod-bitbucket-databackup-hp

- **Resource ID**: `cfg-oregon-shared-infra-non-prod-bitbucket-databackup-hp`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: S3 bucket is empty and unused
- **Recommended Action**: Delete empty bucket to reduce management overhead
- **Tags**: application-name:bitbucket, aws:cloudformation:stack-name:hp-bb-test-postgres, environment:dev, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/hp-bb-test-postgres/93cdc630-cae5-11eb-a90a-025543d413f7, aws:cloudformation:logical-id:DataBackupS3Bucket, resource-name:cfg-oregon-shared-infra-non-prod-bitbucket-databackup-hp, aws-migration-project-id:MPE11706, cost-center:1369

---

#### 🟢 cfg-oregon-shared-infra-non-prod-bitbucket-s3-bucket-databackup

- **Resource ID**: `cfg-oregon-shared-infra-non-prod-bitbucket-s3-bucket-databackup`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: S3 bucket is empty and unused
- **Recommended Action**: Delete empty bucket to reduce management overhead
- **Tags**: application-name:bitbucket, aws:cloudformation:stack-name:cfg-shared-infra-non-prod-bitbucket-rds-s3, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/cfg-shared-infra-non-prod-bitbucket-rds-s3/58857810-ad90-11eb-a91c-0abf561e91bb, map-migrated-app:NA, application-owner:hitesh.patel@cetera.com, resource-name:cfg-oregon-shared-infra-non-prod-bitbucket-s3-bucket-databackup, aws-migration-project-id:MPE11706, broker-services:NA, cost-center:1369, map-migrated:d-server-01hakorzuz9ohq, environment:dev, application-portfolio:NA, aws:cloudformation:logical-id:DataBackupS3Bucket, business-unit:IT-infra

---

#### 🟢 cfg-snow-test-2

- **Resource ID**: `cfg-snow-test-2`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: S3 bucket is empty and unused
- **Recommended Action**: Delete empty bucket to reduce management overhead

---

#### 🟢 elasticbeanstalk-us-west-2-317980596581

- **Resource ID**: `elasticbeanstalk-us-west-2-317980596581`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: S3 bucket is empty and unused
- **Recommended Action**: Delete empty bucket to reduce management overhead

---

#### 🟢 hp-cfg-oregon-non-prod-bitbucket-s3-bucket-databackup

- **Resource ID**: `hp-cfg-oregon-non-prod-bitbucket-s3-bucket-databackup`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: S3 bucket is empty and unused
- **Recommended Action**: Delete empty bucket to reduce management overhead

---

#### 🟢 imputvalueceteratylerjohnson

- **Resource ID**: `imputvalueceteratylerjohnson`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: S3 bucket is empty and unused
- **Recommended Action**: Delete empty bucket to reduce management overhead
- **Tags**: aws:cloudformation:stack-name:ServiceNowTest1, aws:cloudformation:logical-id:S3Bucket, cfg:cost-allocation:portfolio:infrastructure-and-operations, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/ServiceNowTest1/fc1913d0-626b-11f0-81eb-06c47d247907

---

#### 🟢 sc-puppet-caching-bucket-317980596581-us-west-2

- **Resource ID**: `sc-puppet-caching-bucket-317980596581-us-west-2`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: S3 bucket is empty and unused
- **Recommended Action**: Delete empty bucket to reduce management overhead
- **Tags**: aws:cloudformation:stack-name:servicecatalog-puppet, aws:cloudformation:logical-id:CachingBucket, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/servicecatalog-puppet/9e0d9580-61fb-11ee-b747-06f35d8718a1, ServiceCatalogPuppet:Actor:Framework

---

#### 🟢 sc-puppet-spoke-deploy-317980596581

- **Resource ID**: `sc-puppet-spoke-deploy-317980596581`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: S3 bucket is empty and unused
- **Recommended Action**: Delete empty bucket to reduce management overhead
- **Tags**: aws:cloudformation:stack-name:servicecatalog-puppet, aws:cloudformation:logical-id:SpokeDeployBucket, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/servicecatalog-puppet/9e0d9580-61fb-11ee-b747-06f35d8718a1, ServiceCatalogPuppet:Actor:Framework

---

#### 🟢 servicecatalog-factory-factorytemplatevalidatebuc-v44znjwavvdp

- **Resource ID**: `servicecatalog-factory-factorytemplatevalidatebuc-v44znjwavvdp`
- **Region**: us-west-2
- **Current Monthly Cost**: $0.00
- **Potential Monthly Savings**: $0.00
- **Risk Level**: 🟢 Low
- **Reason**: S3 bucket is empty and unused
- **Recommended Action**: Delete empty bucket to reduce management overhead
- **Tags**: aws:cloudformation:stack-name:servicecatalog-factory, aws:cloudformation:logical-id:FactoryTemplateValidateBucket, aws:cloudformation:stack-id:arn:aws:cloudformation:us-west-2:317980596581:stack/servicecatalog-factory/1fe730a0-61f9-11ee-9549-02285eb76925, ServiceCatalogFactory:Actor:Framework

---

## TARGET: Prioritized Action Plan

### 🔴 High Priority (Immediate Action)
**Resources**: 353 | **Monthly Savings**: $944.55 (53.4%)

- 🔴 RDS Instance: `cfg-connections-non-prod-db-se` ($130.04/month)
- 🔴 EBS Snapshot: `snap-0555d9defae3714b4` ($24.00/month)
- 🔴 EBS Snapshot: `snap-08d3748215b5f8cdb` ($12.00/month)
- 🔴 EBS Snapshot: `snap-00897c5fa0d44a5c0` ($12.00/month)
- 🔴 EBS Snapshot: `snap-028f8822f3d4d08d9` ($12.00/month)
- ... and 348 more resources



### 🟡 Medium Priority (Review Required)
**Resources**: 154 | **Monthly Savings**: $342.85 (19.4%)

- 🟡 Network Load Balancer: `cfg-sso-broker-qa-nlb` ($20.74/month)
- 🟡 Network Load Balancer: `aac-qa-NLB-Win` ($20.74/month)
- 🟡 Application Load Balancer: `telecom-dev-alb` ($20.74/month)
- 🟡 Application Load Balancer: `dsnqalb` ($20.74/month)
- 🟡 Application Load Balancer: `artifactory-dev` ($20.74/month)
- ... and 149 more resources



### 🟢 Low Priority (Safe to Remove)
**Resources**: 104 | **Monthly Savings**: $482.00 (27.2%)

- 🟢 EC2 Instance: `i-0f9d5c6dc1bce961d` ($131.50/month)
- 🟢 EC2 Instance: `i-0a6325c43d530ee34` ($74.52/month)
- 🟢 EC2 Instance: `i-0dd6e6768b3e564fe` ($74.52/month)
- 🟢 EC2 Instance: `i-0db47c7b00638e196` ($67.80/month)
- 🟢 EC2 Instance: `i-0a98654a86e0bddcb` ($54.94/month)
- ... and 99 more resources



## ⚠️ Risk Assessment

- **🔴 High Risk**: Manual review required, potential service disruption or security impact
- **🟡 Medium Risk**: Verify with application teams before action
- **🟢 Low Risk**: Generally safe to remove with minimal impact

## 🔐 Security Recommendations

### Immediate Security Actions:

1. **Review 74 unused security groups** - These pose security risks and should be deleted
2. **Audit 55 dormant IAM roles** - Follow principle of least privilege
3. **Clean up 16 expired certificates** - Prevent service disruptions

### Security Best Practices:

- Implement automated resource tagging for better governance
- Set up CloudTrail for resource usage monitoring
- Enable Config rules for compliance monitoring
- Schedule regular security and cost reviews



## 📋 Implementation Checklist

### Before Taking Action:
- [ ] Review all High Risk items with security team
- [ ] Create backups/snapshots where applicable
- [ ] Notify application teams of planned changes
- [ ] Schedule maintenance windows for critical resources

### Implementation Order:
1. **Start with Low Risk items** to gain confidence
2. **Address Security Groups** to reduce attack surface
3. **Clean up IAM roles** to improve security posture
4. **Remove expired certificates** to prevent outages
5. **Delete unused storage** to reduce costs
6. **Monitor services** after each batch of changes

## 📈 Expected Benefits

- **Cost Reduction**: $1,769.41/month ($21,232.92/year)
- **Security Improvement**: Reduced attack surface and compliance posture
- **Operational Excellence**: Simplified resource management
- **Risk Mitigation**: Eliminated orphaned resources and expired certificates

---
*This report was generated by the Enhanced AWS Cost Optimization & Security Analyzer*
