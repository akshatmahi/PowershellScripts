#!/usr/bin/env python3
"""
AWS Cost Optimization Analyzer
A comprehensive tool to identify orphaned and underutilized AWS resources
and generate cost optimization recommendations.
"""

import boto3
import json
import datetime
import csv
import time
import random
import os
from typing import Dict, List, Tuple, Any
from dataclasses import dataclass
from collections import defaultdict
import argparse
import sys
from botocore.exceptions import ClientError, EndpointConnectionError, BotoCoreError
from aws_profile_manager import AWSProfileManager, ProfileInfo
from pricing_manager import pricing_manager

@dataclass
class ResourceAnalysis:
    resource_type: str
    resource_id: str
    resource_name: str
    region: str
    monthly_cost: float
    potential_savings: float
    reason: str
    recommended_action: str
    risk_level: str
    tags: Dict[str, str]
    profile_name: str = 'default'
    account_id: str = 'unknown'

class AWSCostOptimizer:
    def __init__(self, regions: List[str] = None, lookback_days: int = 30,
                 account_id: str = None, critical_tag: str = None,
                 profiles: List[str] = None, config_file: str = 'config/config.json'):
        self.regions = regions or ['us-east-1', 'us-west-2', 'eu-west-1']
        self.lookback_days = lookback_days
        self.account_id = account_id
        self.critical_tag = critical_tag
        self.profiles = profiles or ['default']
        self.findings: List[ResourceAnalysis] = []
        self.cost_data = {}
        self.profile_manager = AWSProfileManager()
        self.current_profile = None
        self.current_account_id = None
        # Connection pooling for AWS clients
        self._client_cache = {}
        self._session_cache = {}
        # Policy caching for performance
        self._dlm_policies_cache = {}
        self._backup_policies_cache = {}
        # Load configuration
        self.config = self._load_config(config_file)
        self.min_utilization_threshold = self.config.get('cost_thresholds', {}).get('minimum_utilization_threshold', 30.0)
        self.max_utilization_threshold = self.config.get('cost_thresholds', {}).get('maximum_utilization_threshold', 70.0)
    
    def _load_config(self, config_file: str) -> dict:
        """Load configuration from JSON file"""
        try:
            # If path is relative, make it relative to project root
            if not os.path.isabs(config_file):
                script_dir = os.path.dirname(os.path.abspath(__file__))
                project_root = os.path.dirname(script_dir)  # Go up one level from src/
                config_file = os.path.join(project_root, config_file)
            with open(config_file, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            print(f"Configuration file {config_file} not found. Using defaults.")
            return {}
        except json.JSONDecodeError as e:
            print(f"Error parsing configuration file: {e}")
            return {}
        
    def get_aws_session(self, region: str = 'us-east-1', profile: str = None):
        """Create AWS session for the specified region and profile with caching"""
        profile_name = profile or self.current_profile or 'default'
        cache_key = f"{profile_name}:{region}"
        
        if cache_key not in self._session_cache:
            self._session_cache[cache_key] = self.profile_manager.create_session(profile_name, region)
        
        return self._session_cache[cache_key]
    
    def get_cached_client(self, service: str, region: str = 'us-east-1', profile: str = None):
        """Get cached AWS service client for improved performance"""
        profile_name = profile or self.current_profile or 'default'
        cache_key = f"{profile_name}:{region}:{service}"
        
        if cache_key not in self._client_cache:
            session = self.get_aws_session(region, profile)
            self._client_cache[cache_key] = session.client(service)
        
        return self._client_cache[cache_key]
    
    def _retry_aws_api_call(self, func, *args, max_retries: int = 3, **kwargs):
        """Retry AWS API calls with exponential backoff for transient errors"""
        last_exception = None
        
        for attempt in range(max_retries + 1):
            try:
                return func(*args, **kwargs)
            except (ClientError, EndpointConnectionError, BotoCoreError) as e:
                last_exception = e
                
                # Check if error is retryable
                if hasattr(e, 'response') and e.response:
                    error_code = e.response.get('Error', {}).get('Code')
                    # Don't retry access denied or permission errors
                    if error_code in ['AccessDenied', 'UnauthorizedOperation', 'Forbidden']:
                        raise e
                
                # Last attempt - raise the exception
                if attempt == max_retries:
                    break
                    
                # Calculate backoff delay with jitter
                delay = (2 ** attempt) + random.uniform(0, 1)
                print(f"    API call failed (attempt {attempt + 1}/{max_retries + 1}), retrying in {delay:.1f}s: {str(e)}")
                time.sleep(delay)
        
        # If we get here, all retries failed
        raise last_exception
    
    def _categorize_aws_error(self, error: Exception, region: str, service: str) -> str:
        """Categorize AWS errors for better debugging and user feedback"""
        if isinstance(error, ClientError):
            error_code = error.response.get('Error', {}).get('Code', 'Unknown')
            error_msg = error.response.get('Error', {}).get('Message', str(error))
            
            # Permission/Access errors
            if error_code in ['AccessDenied', 'UnauthorizedOperation', 'Forbidden']:
                return f"PERMISSION ERROR in {service}:{region} - {error_code}: Check IAM permissions"
            
            # Resource not found
            elif error_code in ['InvalidInstanceID.NotFound', 'InvalidVolumeID.NotFound', 'NoSuchBucket']:
                return f"RESOURCE_NOT_FOUND in {service}:{region} - {error_code}: Resource may have been deleted"
            
            # Rate limiting
            elif error_code in ['Throttling', 'ThrottlingException', 'RequestLimitExceeded']:
                return f"RATE_LIMIT in {service}:{region} - {error_code}: AWS API throttling"
            
            # Service unavailable
            elif error_code in ['ServiceUnavailable', 'InternalFailure']:
                return f"AWS_SERVICE_ERROR in {service}:{region} - {error_code}: Temporary AWS service issue"
            
            # Parameter validation errors  
            elif error_code in ['InvalidParameterValue', 'InvalidParameterCombination', 'ValidationException']:
                return f"PARAMETER_ERROR in {service}:{region} - {error_code}: {error_msg}"
            
            else:
                return f"AWS_CLIENT_ERROR in {service}:{region} - {error_code}: {error_msg}"
        
        elif isinstance(error, EndpointConnectionError):
            return f"CONNECTION_ERROR in {service}:{region} - Cannot connect to AWS endpoint"
        
        elif isinstance(error, BotoCoreError):
            return f"BOTO_ERROR in {service}:{region} - {type(error).__name__}: {str(error)}"
        
        else:
            return f"UNKNOWN_ERROR in {service}:{region} - {type(error).__name__}: {str(error)}"
    
    def set_current_profile(self, profile_name: str):
        """Set the current profile context for analysis"""
        self.current_profile = profile_name
        try:
            session = self.get_aws_session('us-east-1', profile_name)
            sts = session.client('sts')
            identity = sts.get_caller_identity()
            self.current_account_id = identity.get('Account')
            print(f"Using profile: {profile_name} (Account: {self.current_account_id})")
        except Exception as e:
            print(f"WARNING: Could not get account ID for profile {profile_name}: {e}")
            self.current_account_id = 'unknown'
    
    def create_finding(self, resource_type: str, resource_id: str, resource_name: str,
                      region: str, monthly_cost: float, potential_savings: float,
                      reason: str, recommended_action: str, risk_level: str,
                      tags: Dict[str, str]) -> ResourceAnalysis:
        """Helper method to create ResourceAnalysis with profile context"""
        return ResourceAnalysis(
            resource_type=resource_type,
            resource_id=resource_id,
            resource_name=resource_name,
            region=region,
            monthly_cost=monthly_cost,
            potential_savings=potential_savings,
            reason=reason,
            recommended_action=recommended_action,
            risk_level=risk_level,
            tags=tags,
            profile_name=self.current_profile or 'default',
            account_id=self.current_account_id or 'unknown'
        )
    
    def is_resource_critical(self, tags: Dict[str, str]) -> bool:
        """Check if resource has critical tag"""
        if not self.critical_tag:
            return False
        return self.critical_tag in tags.values() or self.critical_tag in tags.keys()
    
    def is_aws_backup_managed(self, snapshot: dict) -> bool:
        """Check if snapshot is managed by AWS Backup service (auto-lifecycle)"""
        # Method 1: Check tags (most reliable)
        tags = {tag['Key']: tag['Value'] for tag in snapshot.get('Tags', [])}
        if any(key.startswith('aws:backup') for key in tags.keys()):
            return True
        
        # Method 2: Check description patterns
        description = snapshot.get('Description', '').lower()
        aws_backup_patterns = [
            'aws backup',
            'created by aws backup',
            'aws-backup-',
            'backup service'
        ]
        
        if any(pattern in description for pattern in aws_backup_patterns):
            return True
            
        # Method 3: Check if created by AWS Backup job
        if 'backup-job' in description or 'backup_job' in description:
            return True
            
        return False
    
    def get_resource_cost(self, resource_type: str, resource_id: str, region: str) -> float:
        """
        Get monthly cost for a resource using CSV-based pricing data.
        
        Args:
            resource_type: Type of resource ('ec2', 'rds', etc.)
            resource_id: Resource identifier (instance type for EC2/RDS)
            region: AWS region (kept for compatibility)
        
        Returns:
            Monthly cost in USD
        """
        # Use the new pricing manager for EC2 and RDS
        if resource_type in ['ec2', 'rds']:
            return pricing_manager.get_resource_cost(resource_type, resource_id, region)
        
        # Fallback for other resource types
        other_costs = {
            'ebs_volume': 0.10,  # per GB per month (average)
            'eip': 3.65,  # Updated pricing for unattached EIP
            'elastic_ip': 3.65,  # Alternative name for EIP
            'elb': 22.68,  # Classic Load Balancer
            'alb': 20.74,  # Application Load Balancer  
            'nlb': 20.74,  # Network Load Balancer
            'load_balancer': 20.74,  # Generic load balancer
            'classic_load_balancer': 22.68,  # Classic ELB
            'nat_gateway': 32.85,  # NAT Gateway per month
            'eni': 0.00,   # ENIs are free
            'security_group': 0.00,  # Security groups are free
            's3_bucket': 0.00,  # Base S3 buckets are free
            'lambda_function': 0.00,  # Lambda base is free
            'kms_key': 1.00,  # Customer managed KMS key per month
            'certificate': 0.00,  # ACM certificates are free
            'ebs_snapshot': 0.048,  # EBS snapshot per GB per month
            'iam_role': 0.00,  # IAM roles are free
            'vpc': 0.00,  # VPCs are free
            'igw': 0.00,  # Internet Gateways are free
            'route_table': 0.00  # Route tables are free
        }
        
        return other_costs.get(resource_type, 10.0)  # Default estimate
    
    def analyze_unattached_ebs_volumes(self):
        """Find unattached EBS volumes"""
        for region in self.regions:
            try:
                ec2 = self.get_cached_client('ec2', region)
                
                try:
                    volumes = self._retry_aws_api_call(
                        ec2.describe_volumes,
                        Filters=[{'Name': 'status', 'Values': ['available']}]
                    )
                except Exception as e:
                    error_msg = self._categorize_aws_error(e, region, 'ec2')
                    print(f"    WARNING: Could not list EBS volumes - {error_msg}")
                    continue
                
                for volume in volumes['Volumes']:
                    if self.is_resource_critical(
                        {tag['Key']: tag['Value'] for tag in volume.get('Tags', [])}
                    ):
                        continue
                    
                    volume_size = volume['Size']
                    volume_type = volume['VolumeType']
                    monthly_cost = volume_size * self.get_resource_cost('ebs_volume', volume_type, region)
                    
                    finding = self.create_finding(
                        resource_type='EBS Volume',
                        resource_id=volume['VolumeId'],
                        resource_name=self._get_name_tag(volume.get('Tags', [])),
                        region=region,
                        monthly_cost=monthly_cost,
                        potential_savings=monthly_cost,
                        reason='Volume is unattached and not in use',
                        recommended_action='Create snapshot and delete volume',
                        risk_level='Low',
                        tags={tag['Key']: tag['Value'] for tag in volume.get('Tags', [])}
                    )
                    self.findings.append(finding)
            except Exception as e:
                print(f"Error analyzing EBS volumes in {region}: {e}")
    
    def analyze_idle_elastic_ips(self):
        """Find idle Elastic IP addresses"""
        for region in self.regions:
            try:
                ec2 = self.get_cached_client('ec2', region)
                
                try:
                    eips = ec2.describe_addresses()
                except Exception as e:
                    print(f"    WARNING: Could not list Elastic IPs in {region}: {e}")
                    continue
                
                for eip in eips['Addresses']:
                    if 'AssociationId' not in eip:  # Unassociated EIP
                        if self.is_resource_critical(
                            {tag['Key']: tag['Value'] for tag in eip.get('Tags', [])}
                        ):
                            continue
                        
                        monthly_cost = self.get_resource_cost('eip', '', region)
                        
                        self.findings.append(self.create_finding(
                            resource_type='Elastic IP',
                            resource_id=eip['PublicIp'],
                            resource_name=self._get_name_tag(eip.get('Tags', [])),
                            region=region,
                            monthly_cost=monthly_cost,
                            potential_savings=monthly_cost,
                            reason='Elastic IP is not associated with any resource',
                            recommended_action='Release unused Elastic IP',
                            risk_level='Low',
                            tags={tag['Key']: tag['Value'] for tag in eip.get('Tags', [])}
                        ))
            except Exception as e:
                print(f"Error analyzing Elastic IPs in {region}: {e}")
    
    def analyze_unused_ec2_instances(self):
        """Find stopped or underutilized EC2 instances with comprehensive CPU and RAM analysis"""
        for region in self.regions:
            try:
                ec2 = self.get_cached_client('ec2', region)
                cloudwatch = self.get_cached_client('cloudwatch', region)
                
                instances = ec2.describe_instances(
                    Filters=[{'Name': 'instance-state-name', 'Values': ['stopped', 'running']}]
                )
                
                for reservation in instances['Reservations']:
                    for instance in reservation['Instances']:
                        if self.is_resource_critical(
                            {tag['Key']: tag['Value'] for tag in instance.get('Tags', [])}
                        ):
                            continue
                        
                        instance_id = instance['InstanceId']
                        instance_type = instance['InstanceType']
                        monthly_cost = self.get_resource_cost('ec2', instance_type, region)
                        
                        if instance['State']['Name'] == 'stopped':
                            # Enhanced analysis for stopped instances
                            stopped_analysis = self._analyze_stopped_instance(
                                cloudwatch, instance_id, instance_type, self.lookback_days
                            )
                            reason = stopped_analysis['reason']
                            action = stopped_analysis['action']
                            risk = stopped_analysis['risk']
                            savings = stopped_analysis['savings']
                        else:
                            # Comprehensive utilization analysis for running instances
                            utilization_analysis = self._analyze_instance_utilization(
                                cloudwatch, instance_id, self.lookback_days
                            )
                            
                            if not utilization_analysis['has_data']:
                                print(f"    WARNING: Could not get metrics for instance {instance_id}: insufficient data")
                                continue
                            
                            # Use configurable thresholds - only recommend optimization for < 30% utilization
                            min_threshold = self.min_utilization_threshold
                            max_threshold = self.max_utilization_threshold
                            
                            avg_cpu = utilization_analysis['avg_cpu']
                            max_cpu = utilization_analysis['max_cpu']
                            avg_memory = utilization_analysis['avg_memory']
                            max_memory = utilization_analysis['max_memory']
                            
                            # Determine optimization recommendation
                            optimization = self._determine_ec2_optimization(
                                avg_cpu, max_cpu, avg_memory, max_memory,
                                min_threshold, max_threshold,
                                instance_type, monthly_cost
                            )
                            
                            if not optimization:
                                continue  # Skip well-utilized instances
                            
                            reason = optimization['reason']
                            action = optimization['action']
                            risk = optimization['risk']
                            savings = optimization['savings']
                        
                        finding = self.create_finding(
                            resource_type='EC2 Instance',
                            resource_id=instance_id,
                            resource_name=self._get_name_tag(instance.get('Tags', [])),
                            region=region,
                            monthly_cost=monthly_cost,
                            potential_savings=savings,
                            reason=reason,
                            recommended_action=action,
                            risk_level=risk,
                            tags={tag['Key']: tag['Value'] for tag in instance.get('Tags', [])}
                        )
                        self.findings.append(finding)
                        
            except Exception as e:
                print(f"Error analyzing EC2 instances in {region}: {e}")
    
    def _analyze_stopped_instance(self, cloudwatch, instance_id: str, instance_type: str, lookback_days: int) -> dict:
        """Analyze stopped instances to distinguish between temporarily stopped vs truly unused"""
        end_time = datetime.datetime.now(datetime.timezone.utc)
        start_time = end_time - datetime.timedelta(days=lookback_days)
        
        try:
            # Get CPU metrics to understand historical usage patterns
            period = self._calculate_optimal_cloudwatch_period(lookback_days)
            cpu_metrics = cloudwatch.get_metric_statistics(
                Namespace='AWS/EC2',
                MetricName='CPUUtilization',
                Dimensions=[{'Name': 'InstanceId', 'Value': instance_id}],
                StartTime=start_time,
                EndTime=end_time,
                Period=period,
                Statistics=['Average', 'Maximum']
            )
            
            # Check if instance had any activity in the lookback period
            has_recent_activity = len(cpu_metrics['Datapoints']) > 0
            
            if has_recent_activity:
                # Calculate when instance was likely last active
                latest_datapoint = max(cpu_metrics['Datapoints'], key=lambda x: x['Timestamp'])
                days_since_activity = (end_time - latest_datapoint['Timestamp']).days
                
                # Analyze usage pattern to determine if it's a scheduled/weekend stop
                cpu_values = [dp['Average'] for dp in cpu_metrics['Datapoints']]
                avg_cpu = sum(cpu_values) / len(cpu_values) if cpu_values else 0
                
                # Weekend/scheduled stop detection
                if days_since_activity <= 3:  # Stopped within last 3 days
                    return {
                        'reason': f'Instance stopped recently ({days_since_activity} days ago) - may be temporarily stopped for weekends/maintenance',
                        'action': 'Monitor usage pattern - consider scheduling or rightsizing if consistently underused',
                        'risk': 'Low',
                        'savings': 0.0  # No immediate savings recommendation for recent stops
                    }
                elif days_since_activity <= 7 and avg_cpu > 5.0:  # Had decent usage before stopping
                    return {
                        'reason': f'Instance stopped {days_since_activity} days ago but had active usage (avg CPU {avg_cpu:.1f}%) - likely scheduled downtime',
                        'action': 'Review if instance is needed - consider automated start/stop scheduling',
                        'risk': 'Medium',
                        'savings': self.get_resource_cost('ec2', instance_type, 'us-east-1') * 0.3  # 30% savings through scheduling
                    }
                else:  # Long-term stopped with low historical usage
                    return {
                        'reason': f'Instance stopped {days_since_activity} days ago with minimal historical usage (avg CPU {avg_cpu:.1f}%)',
                        'action': 'Strong candidate for termination - create AMI backup if needed',
                        'risk': 'Low',
                        'savings': self.get_resource_cost('ec2', instance_type, 'us-east-1')
                    }
            else:
                # No recent activity data - likely long-term stopped
                return {
                    'reason': f'Instance has been stopped with no CloudWatch activity data for {lookback_days}+ days',
                    'action': 'High priority for termination - appears to be unused long-term',
                    'risk': 'Low',
                    'savings': self.get_resource_cost('ec2', instance_type, 'us-east-1')
                }
                
        except Exception as e:
            # Fallback to simple stopped instance analysis
            return {
                'reason': f'Instance is stopped (unable to analyze usage history: {str(e)[:50]})',
                'action': 'Review if instance is still needed',
                'risk': 'Medium',
                'savings': self.get_resource_cost('ec2', instance_type, 'us-east-1')
            }
    
    def _analyze_instance_utilization(self, cloudwatch, instance_id: str, lookback_days: int) -> dict:
        """Analyze both CPU and memory utilization for an EC2 instance"""
        end_time = datetime.datetime.now(datetime.timezone.utc)
        start_time = end_time - datetime.timedelta(days=lookback_days)
        
        result = {
            'has_data': False,
            'avg_cpu': 0.0,
            'max_cpu': 0.0,
            'avg_memory': 0.0,
            'max_memory': 0.0
        }
        
        try:
            # Calculate optimal period to stay within CloudWatch datapoint limits
            period = self._calculate_optimal_cloudwatch_period(lookback_days)
            period_hours = period // 3600
            
            # Get CPU utilization metrics
            cpu_metrics = cloudwatch.get_metric_statistics(
                Namespace='AWS/EC2',
                MetricName='CPUUtilization',
                Dimensions=[{'Name': 'InstanceId', 'Value': instance_id}],
                StartTime=start_time,
                EndTime=end_time,
                Period=period,  # Dynamic period based on lookback days
                Statistics=['Average', 'Maximum']
            )
            
            # Get memory utilization metrics (requires CloudWatch agent)
            memory_metrics = []
            try:
                memory_metrics = cloudwatch.get_metric_statistics(
                    Namespace='CWAgent',
                    MetricName='mem_used_percent',
                    Dimensions=[{'Name': 'InstanceId', 'Value': instance_id}],
                    StartTime=start_time,
                    EndTime=end_time,
                    Period=period,  # Use same dynamic period
                    Statistics=['Average', 'Maximum']
                )
            except Exception:
                # Also try AWS/ApplicationELB namespace for memory metrics
                try:
                    memory_metrics = cloudwatch.get_metric_statistics(
                        Namespace='System/Linux',
                        MetricName='MemoryUtilization',
                        Dimensions=[{'Name': 'InstanceId', 'Value': instance_id}],
                        StartTime=start_time,
                        EndTime=end_time,
                        Period=period,  # Use same dynamic period
                        Statistics=['Average', 'Maximum']
                    )
                except Exception:
                    pass  # Memory metrics may not be available
            
            # Process CPU metrics
            if cpu_metrics['Datapoints']:
                result['avg_cpu'] = sum(dp['Average'] for dp in cpu_metrics['Datapoints']) / len(cpu_metrics['Datapoints'])
                result['max_cpu'] = max(dp['Maximum'] for dp in cpu_metrics['Datapoints'])
                result['has_data'] = True
            
            # Process memory metrics if available
            if memory_metrics and memory_metrics.get('Datapoints'):
                result['avg_memory'] = sum(dp['Average'] for dp in memory_metrics['Datapoints']) / len(memory_metrics['Datapoints'])
                result['max_memory'] = max(dp['Maximum'] for dp in memory_metrics['Datapoints'])
            else:
                # If no memory metrics, assume moderate usage to avoid false positives
                result['avg_memory'] = 50.0
                result['max_memory'] = 70.0
                
        except Exception as e:
            print(f"    WARNING: Could not get utilization metrics for instance {instance_id}: {e}")
        
        return result
    
    def _determine_ec2_optimization(self, avg_cpu: float, max_cpu: float, avg_memory: float, 
                                  max_memory: float, min_threshold: float, max_threshold: float,
                                  instance_type: str, monthly_cost: float) -> dict:
        """Determine EC2 optimization recommendation based on minimum utilization threshold"""
        
        # Skip recommendations if either CPU or Memory is above maximum threshold
        if max_cpu >= max_threshold or max_memory >= max_threshold:
            return None
        
        # Only recommend optimization for instances with both CPU and Memory < 30% (minimum threshold)
        if avg_cpu < min_threshold and avg_memory < min_threshold:
            return {
                'reason': f'Minimum utilization detected: CPU {avg_cpu:.1f}% avg (max {max_cpu:.1f}%), Memory {avg_memory:.1f}% avg (max {max_memory:.1f}%) - both below {min_threshold}% threshold',
                'action': 'Strong candidate for termination or aggressive downsizing - create AMI backup if needed',
                'risk': 'Low',
                'savings': monthly_cost * 0.90  # 90% savings through termination/aggressive rightsizing
            }
        
        # No optimization needed - above minimum threshold or exceeds maximum threshold
        return None
    
    def _suggest_smaller_instance_type(self, current_type: str, avg_cpu: float, avg_memory: float) -> str:
        """Suggest a smaller instance type based on utilization patterns"""
        
        # Instance type families and their typical progression
        type_families = {
            't3': ['t3.nano', 't3.micro', 't3.small', 't3.medium', 't3.large', 't3.xlarge', 't3.2xlarge'],
            't2': ['t2.nano', 't2.micro', 't2.small', 't2.medium', 't2.large', 't2.xlarge', 't2.2xlarge'],
            'm5': ['m5.large', 'm5.xlarge', 'm5.2xlarge', 'm5.4xlarge', 'm5.8xlarge', 'm5.12xlarge', 'm5.16xlarge', 'm5.24xlarge'],
            'm6i': ['m6i.large', 'm6i.xlarge', 'm6i.2xlarge', 'm6i.4xlarge', 'm6i.8xlarge', 'm6i.12xlarge', 'm6i.16xlarge', 'm6i.24xlarge'],
            'c5': ['c5.large', 'c5.xlarge', 'c5.2xlarge', 'c5.4xlarge', 'c5.9xlarge', 'c5.12xlarge', 'c5.18xlarge', 'c5.24xlarge'],
            'r5': ['r5.large', 'r5.xlarge', 'r5.2xlarge', 'r5.4xlarge', 'r5.8xlarge', 'r5.12xlarge', 'r5.16xlarge', 'r5.24xlarge']
        }
        
        # Extract family and find current position
        family = current_type.split('.')[0]
        if family in type_families:
            family_list = type_families[family]
            if current_type in family_list:
                current_index = family_list.index(current_type)
                # Suggest going down 1-2 sizes based on utilization
                if avg_cpu < 10 and avg_memory < 20:
                    target_index = max(0, current_index - 2)  # Aggressive downsizing
                else:
                    target_index = max(0, current_index - 1)  # Conservative downsizing
                return family_list[target_index]
        
        # Fallback suggestions
        if 'xlarge' in current_type:
            return current_type.replace('xlarge', 'large')
        elif 'large' in current_type:
            return current_type.replace('large', 'medium')
        elif 'medium' in current_type:
            return current_type.replace('medium', 'small')
        
        return f"{family}.small"  # Default fallback
    
    def _calculate_downsizing_savings(self, current_type: str, target_type: str) -> float:
        """Calculate expected savings percentage from downsizing"""
        
        # Rough savings mapping based on common downsizing scenarios
        savings_map = {
            ('xlarge', 'large'): 0.50,
            ('large', 'medium'): 0.50, 
            ('medium', 'small'): 0.50,
            ('small', 'micro'): 0.50,
            ('2xlarge', 'xlarge'): 0.50,
            ('4xlarge', '2xlarge'): 0.50,
            ('8xlarge', '4xlarge'): 0.50,
        }
        
        current_size = current_type.split('.')[-1] if '.' in current_type else current_type
        target_size = target_type.split('.')[-1] if '.' in target_type else target_type
        
        return savings_map.get((current_size, target_size), 0.40)  # Default 40% savings
    
    def _calculate_optimal_cloudwatch_period(self, lookback_days: int) -> int:
        """Calculate optimal CloudWatch period to stay within 1440 datapoint limit"""
        
        # AWS CloudWatch limits: Maximum 1440 datapoints per GetMetricStatistics call
        max_datapoints = 1400  # Safety margin under 1440 limit
        total_seconds = lookback_days * 24 * 3600  # Convert to total seconds
        
        # Calculate minimum period needed to stay under datapoint limit
        # period = total_seconds / max_datapoints
        min_period = total_seconds / max_datapoints
        
        # Round up to next valid CloudWatch period (60, 300, 3600, 10800, 21600, 43200, 86400)
        if min_period <= 3600:  # <= 1 hour
            period = 3600  # 1 hour periods (optimal granularity)
        elif min_period <= 10800:  # <= 3 hours  
            period = 10800  # 3 hour periods (good balance)
        elif min_period <= 21600:  # <= 6 hours
            period = 21600  # 6 hour periods
        elif min_period <= 43200:  # <= 12 hours
            period = 43200  # 12 hour periods
        else:
            period = 86400  # 24 hour periods (daily aggregation)
            
        # Verify we don't exceed datapoint limit
        expected_datapoints = total_seconds // period
        if expected_datapoints > max_datapoints:
            # Fallback: calculate minimum period needed
            period = total_seconds // max_datapoints
            # Round up to nearest hour
            period = ((period + 3599) // 3600) * 3600
            
        return period
    
    def _detect_retention_policy(self, snapshot: dict, region: str) -> tuple:
        """
        Intelligently detect appropriate retention policy for EBS snapshot
        Returns: (retention_days, policy_source, confidence_level)
        """
        snapshot_id = snapshot['SnapshotId']
        volume_id = snapshot.get('VolumeId', '')
        snapshot_tags = {tag['Key']: tag['Value'] for tag in snapshot.get('Tags', [])}
        
        # Priority 1: Check for explicit retention tags on snapshot
        retention_from_tags = self._get_retention_from_tags(snapshot_tags)
        if retention_from_tags:
            return retention_from_tags, 'snapshot_tags', 'high'
        
        # Priority 2: Check Data Lifecycle Manager (DLM) policies
        dlm_retention = self._get_dlm_retention_policy(volume_id, region)
        if dlm_retention:
            return dlm_retention, 'dlm_policy', 'high'
            
        # Priority 3: Check AWS Backup service policies
        backup_retention = self._get_aws_backup_retention(volume_id, region)
        if backup_retention:
            return backup_retention, 'aws_backup', 'high'
            
        # Priority 4: If we have volume ID, check volume tags
        if volume_id:
            try:
                ec2 = self.get_cached_client('ec2', region)
                volume_resp = ec2.describe_volumes(VolumeIds=[volume_id])
                if volume_resp['Volumes']:
                    volume_tags = {tag['Key']: tag['Value'] for tag in volume_resp['Volumes'][0].get('Tags', [])}
                    volume_retention = self._get_retention_from_tags(volume_tags)
                    if volume_retention:
                        return volume_retention, 'volume_tags', 'medium'
            except Exception:
                pass
                
        # Priority 5: Infer from application/environment tags
        inferred_retention = self._infer_retention_from_context(snapshot_tags)
        if inferred_retention:
            return inferred_retention, 'context_inference', 'medium'
            
        # Priority 6: Check snapshot age and description patterns
        age_based_retention = self._get_age_based_retention(snapshot)
        if age_based_retention:
            return age_based_retention, 'age_pattern', 'low'
            
        # Fallback: Default 90 days with warning
        return 90, 'default_fallback', 'low'
    
    def _get_retention_from_tags(self, tags: dict) -> int:
        """Extract retention days from resource tags"""
        retention_tag_keys = [
            'RetentionDays', 'retention-days', 'backup-retention-days',
            'BackupRetention', 'backup-retention', 'LifecycleRetention',
            'retention', 'Retention', 'backup_retention_days'
        ]
        
        for key in retention_tag_keys:
            if key in tags:
                try:
                    retention_value = tags[key].lower()
                    # Handle different formats
                    if 'day' in retention_value:
                        return int(''.join(filter(str.isdigit, retention_value)))
                    elif 'month' in retention_value:
                        months = int(''.join(filter(str.isdigit, retention_value)))
                        return months * 30
                    elif 'year' in retention_value:
                        years = int(''.join(filter(str.isdigit, retention_value)))
                        return years * 365
                    else:
                        return int(retention_value)
                except (ValueError, AttributeError):
                    continue
        return None
    
    def _get_dlm_retention_policy(self, volume_id: str, region: str) -> int:
        """Check Data Lifecycle Manager policies for retention settings"""
        try:
            dlm = self.get_cached_client('dlm', region)
            
            # Get all lifecycle policies
            policies = dlm.get_lifecycle_policies()
            
            for policy_summary in policies['Policies']:
                try:
                    policy_detail = dlm.get_lifecycle_policy(PolicyId=policy_summary['PolicyId'])
                    policy = policy_detail['Policy']
                    
                    # Check if this policy applies to our volume
                    if self._policy_applies_to_volume(policy, volume_id, region):
                        # Extract retention from policy
                        retention_days = self._extract_dlm_retention(policy)
                        if retention_days:
                            return retention_days
                            
                except Exception:
                    continue
                    
        except Exception:
            pass
        return None
    
    def _policy_applies_to_volume(self, policy: dict, volume_id: str, region: str) -> bool:
        """Check if a DLM policy applies to the given volume"""
        try:
            if not volume_id:
                return False
                
            policy_details = policy.get('PolicyDetails', {})
            target_tags = policy_details.get('TargetTags', [])
            
            if not target_tags:
                return False
                
            # Get volume tags
            ec2 = session.client('ec2')
            volumes = ec2.describe_volumes(VolumeIds=[volume_id])
            
            if not volumes['Volumes']:
                return False
                
            volume_tags = {tag['Key']: tag['Value'] for tag in volumes['Volumes'][0].get('Tags', [])}
            
            # Check if any target tags match volume tags
            for target_tag in target_tags:
                tag_key = target_tag.get('Key')
                tag_value = target_tag.get('Value')
                
                if tag_key in volume_tags and volume_tags[tag_key] == tag_value:
                    return True
                    
        except Exception:
            pass
        return False
    
    def _extract_dlm_retention(self, policy: dict) -> int:
        """Extract retention days from DLM policy"""
        try:
            policy_details = policy.get('PolicyDetails', {})
            schedules = policy_details.get('Schedules', [])
            
            for schedule in schedules:
                retain_rule = schedule.get('RetainRule', {})
                
                # Check for count-based retention (convert to approximate days)
                if 'Count' in retain_rule:
                    count = retain_rule['Count']
                    frequency = schedule.get('CreateRule', {}).get('Interval', 1)
                    interval_unit = schedule.get('CreateRule', {}).get('IntervalUnit', 'HOURS')
                    
                    if interval_unit == 'HOURS':
                        return (count * frequency) // 24  # Convert to days
                    elif interval_unit == 'DAYS':
                        return count * frequency
                        
                # Check for age-based retention
                elif 'Interval' in retain_rule:
                    interval = retain_rule['Interval']
                    interval_unit = retain_rule.get('IntervalUnit', 'DAYS')
                    
                    if interval_unit == 'DAYS':
                        return interval
                    elif interval_unit == 'WEEKS':
                        return interval * 7
                    elif interval_unit == 'MONTHS':
                        return interval * 30
                    elif interval_unit == 'YEARS':
                        return interval * 365
                        
        except Exception:
            pass
        return None
    
    def _get_aws_backup_retention(self, volume_id: str, region: str) -> int:
        """Check AWS Backup service for retention policies"""
        try:
            backup = self.get_cached_client('backup', region)
            
            # List backup plans
            backup_plans = backup.list_backup_plans()
            
            for plan_summary in backup_plans['BackupPlansList']:
                try:
                    plan_detail = backup.get_backup_plan(BackupPlanId=plan_summary['BackupPlanId'])
                    plan = plan_detail['BackupPlan']
                    
                    # Check backup rules for retention
                    for rule in plan.get('Rules', []):
                        lifecycle = rule.get('Lifecycle', {})
                        if 'DeleteAfterDays' in lifecycle:
                            return lifecycle['DeleteAfterDays']
                            
                except Exception:
                    continue
                    
        except Exception:
            pass
        return None
    
    def _infer_retention_from_context(self, tags: dict) -> int:
        """Infer appropriate retention based on environment, application, and compliance tags"""
        
        # Priority 1: Check compliance tags first (highest priority)
        compliance = tags.get('Compliance', '').lower()
        if 'sox' in compliance or 'sarbanes' in compliance:
            return 2555  # 7 years for SOX compliance
        elif 'hipaa' in compliance:
            return 2190  # 6 years for HIPAA compliance
        elif 'pci' in compliance:
            return 1095  # 3 years for PCI compliance
        
        # Priority 2: Application-based retention (compliance-driven)
        app_type = tags.get('Application', '').lower()
        workload = tags.get('Workload', '').lower()
        
        financial_apps = ['finance', 'billing', 'payment', 'accounting', 'trading', 'financial']
        healthcare_apps = ['health', 'medical', 'patient', 'healthcare']
        compliance_apps = ['audit', 'compliance', 'legal', 'regulatory']
            
        # Check application types
        for app in financial_apps:
            if app in app_type or app in workload:
                return 2555  # 7 years for financial data (SOX compliance)
                
        for app in healthcare_apps:
            if app in app_type or app in workload:
                return 2190  # 6 years for healthcare (HIPAA)
                
        for app in compliance_apps:
            if app in app_type or app in workload:
                return 1825  # 5 years for compliance data
        
        # Priority 3: Environment-based retention (lower priority than compliance)
        environment = tags.get('Environment', '').lower()
        env_retention_map = {
            'production': 1095,    # 3 years for production
            'prod': 1095,
            'staging': 365,        # 1 year for staging  
            'stage': 365,
            'development': 90,     # 3 months for development
            'dev': 90,
            'test': 30,           # 1 month for test
            'testing': 30,
            'sandbox': 30,        # 1 month for sandbox
        }
        
        if environment in env_retention_map:
            return env_retention_map[environment]
        
        # Database retention (typically longer)
        if any(db_type in app_type.lower() for db_type in ['database', 'db', 'mysql', 'postgres', 'oracle']):
            return 1095  # 3 years for databases
            
        # Web application retention
        if any(web_type in app_type.lower() for web_type in ['web', 'api', 'frontend', 'backend']):
            return 365   # 1 year for web applications
            
        return None
    
    def _get_age_based_retention(self, snapshot: dict) -> int:
        """Determine retention based on snapshot age and description patterns"""
        description = snapshot.get('Description', '').lower()
        
        # Check for backup automation patterns
        if 'backup' in description:
            if any(term in description for term in ['daily', 'nightly']):
                return 30    # Daily backups: 1 month
            elif any(term in description for term in ['weekly']):
                return 90    # Weekly backups: 3 months  
            elif any(term in description for term in ['monthly']):
                return 365   # Monthly backups: 1 year
                
        # AMI creation snapshots (typically longer retention)
        if 'createimage' in description or 'ami' in description:
            return 365  # 1 year for AMI snapshots
            
        return None
    
    def analyze_abandoned_rds_instances(self):
        """Find unused RDS instances"""
        for region in self.regions:
            try:
                session = self.get_aws_session(region)
                rds = self.get_cached_client('rds', region)
                cloudwatch = self.get_cached_client('cloudwatch', region)
                
                instances = rds.describe_db_instances()
                
                for instance in instances['DBInstances']:
                    if instance['DBInstanceStatus'] != 'available':
                        continue
                    
                    try:
                        tags_response = rds.list_tags_for_resource(
                            ResourceName=instance['DBInstanceArn']
                        )
                        tags = {tag['Key']: tag['Value'] for tag in tags_response['TagList']}
                    except Exception as e:
                        print(f"    WARNING: Could not get tags for RDS instance {instance['DBInstanceIdentifier']}: {e}")
                        tags = {}
                    
                    if self.is_resource_critical(tags):
                        continue
                    
                    instance_class = instance['DBInstanceClass']
                    monthly_cost = self.get_resource_cost('rds', instance_class, region)
                    
                    # Check database connections
                    try:
                        # Calculate optimal period for RDS metrics
                        period = self._calculate_optimal_cloudwatch_period(self.lookback_days)
                        
                        connection_metrics = cloudwatch.get_metric_statistics(
                            Namespace='AWS/RDS',
                            MetricName='DatabaseConnections',
                            Dimensions=[{'Name': 'DBInstanceIdentifier', 'Value': instance['DBInstanceIdentifier']}],
                            StartTime=datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=self.lookback_days),
                            EndTime=datetime.datetime.now(datetime.timezone.utc),
                            Period=period,  # Use dynamic period
                            Statistics=['Average']
                        )
                        
                        if connection_metrics['Datapoints']:
                            avg_connections = sum(dp['Average'] for dp in connection_metrics['Datapoints']) / len(connection_metrics['Datapoints'])
                            if avg_connections < 1:
                                self.findings.append(self.create_finding(
                                    resource_type='RDS Instance',
                                    resource_id=instance['DBInstanceIdentifier'],
                                    resource_name=instance.get('DBName', 'N/A'),
                                    region=region,
                                    monthly_cost=monthly_cost,
                                    potential_savings=monthly_cost,
                                    reason=f'No database connections over {self.lookback_days} days',
                                    recommended_action='Create final snapshot and terminate',
                                    risk_level='High',
                                    tags=tags
                                ))
                    except Exception as e:
                        print(f"    WARNING: Could not get connection metrics for RDS instance {instance['DBInstanceIdentifier']}: {e}")
            except Exception as e:
                print(f"Error analyzing RDS instances in {region}: {e}")
    
    def analyze_unused_load_balancers(self):
        """Find load balancers with no healthy targets"""
        for region in self.regions:
            try:
                session = self.get_aws_session(region)
                elb = self.get_cached_client('elb', region)  # Classic Load Balancer
                elbv2 = self.get_cached_client('elbv2', region)  # ALB/NLB
                
                # Classic Load Balancers
                try:
                    classic_lbs = elb.describe_load_balancers()
                except Exception as e:
                    print(f"    WARNING: Could not list Classic Load Balancers in {region}: {e}")
                    classic_lbs = {'LoadBalancerDescriptions': []}
                
                for lb in classic_lbs['LoadBalancerDescriptions']:
                    try:
                        # Get tags for this load balancer
                        tags = {}
                        try:
                            tags_response = elb.describe_tags(LoadBalancerNames=[lb['LoadBalancerName']])
                            if tags_response['TagDescriptions']:
                                tags = {tag['Key']: tag['Value'] for tag in tags_response['TagDescriptions'][0]['Tags']}
                        except Exception as e:
                            print(f"    WARNING: Could not get tags for CLB {lb['LoadBalancerName']}: {e}")
                            tags = {}
                        
                        if self.is_resource_critical(tags):
                            continue
                        
                        # Check instance health
                        try:
                            health = elb.describe_instance_health(LoadBalancerName=lb['LoadBalancerName'])
                            healthy_instances = [h for h in health['InstanceStates'] if h['State'] == 'InService']
                        except Exception as e:
                            print(f"    WARNING: Could not check health for CLB {lb['LoadBalancerName']}: {e}")
                            continue  # Skip this load balancer if we can't check its health
                        
                        if not healthy_instances:
                            monthly_cost = self.get_resource_cost('elb', '', region)
                            self.findings.append(self.create_finding(
                                resource_type='Classic Load Balancer',
                                resource_id=lb['LoadBalancerName'],
                                resource_name=lb['LoadBalancerName'],
                                region=region,
                                monthly_cost=monthly_cost,
                                potential_savings=monthly_cost,
                                reason='No healthy instances registered',
                                recommended_action='Delete unused load balancer',
                                risk_level='Low',
                                tags=tags
                            ))
                    except Exception as e:
                        print(f"    WARNING: Error processing Classic Load Balancer {lb.get('LoadBalancerName', 'unknown')}: {e}")
                        continue
                
                # Application/Network Load Balancers  
                try:
                    modern_lbs = elbv2.describe_load_balancers()
                except Exception as e:
                    print(f"    WARNING: Could not list ALB/NLB Load Balancers in {region}: {e}")
                    modern_lbs = {'LoadBalancers': []}
                
                for lb in modern_lbs['LoadBalancers']:
                    try:
                        # Get tags for this load balancer (THIS WAS THE FAILING LINE)
                        tags = {}
                        try:
                            tags_response = elbv2.describe_tags(ResourceArns=[lb['LoadBalancerArn']])
                            if tags_response['TagDescriptions']:
                                tags = {tag['Key']: tag['Value'] for tag in tags_response['TagDescriptions'][0]['Tags']}
                        except Exception as e:
                            print(f"    WARNING: Could not get tags for {lb['Type']} {lb['LoadBalancerName']}: {e}")
                            tags = {}
                        
                        if self.is_resource_critical(tags):
                            continue
                        
                        # Check target groups
                        has_healthy_targets = False
                        try:
                            target_groups = elbv2.describe_target_groups(LoadBalancerArn=lb['LoadBalancerArn'])
                            
                            for tg in target_groups['TargetGroups']:
                                try:
                                    health = elbv2.describe_target_health(TargetGroupArn=tg['TargetGroupArn'])
                                    if any(t['TargetHealth']['State'] == 'healthy' for t in health['TargetHealthDescriptions']):
                                        has_healthy_targets = True
                                        break
                                except Exception as e:
                                    print(f"    WARNING: Could not check target health for target group {tg['TargetGroupName']}: {e}")
                                    # Continue checking other target groups
                                    continue
                        except Exception as e:
                            print(f"    WARNING: Could not get target groups for {lb['Type']} {lb['LoadBalancerName']}: {e}")
                            continue  # Skip this load balancer if we can't check target groups
                        
                        if not has_healthy_targets:
                            lb_type = 'alb' if lb['Type'] == 'application' else 'nlb'
                            monthly_cost = self.get_resource_cost(lb_type, '', region)
                            self.findings.append(self.create_finding(
                                resource_type=f"{lb['Type'].title()} Load Balancer",
                                resource_id=lb['LoadBalancerName'],
                                resource_name=lb['LoadBalancerName'],
                                region=region,
                                monthly_cost=monthly_cost,
                                potential_savings=monthly_cost,
                                reason='No healthy targets in target groups',
                                recommended_action='Delete unused load balancer',
                                risk_level='Medium',
                                tags=tags
                            ))
                    except Exception as e:
                        print(f"    WARNING: Error processing {lb.get('Type', 'unknown')} Load Balancer {lb.get('LoadBalancerName', 'unknown')}: {e}")
                        continue
            except Exception as e:
                print(f"Error analyzing Load Balancers in {region}: {e}")
    
    def analyze_unused_nat_gateways(self):
        """Find NAT Gateways with low traffic"""
        for region in self.regions:
            try:
                ec2 = self.get_cached_client('ec2', region)
                cloudwatch = self.get_cached_client('cloudwatch', region)
                
                nat_gateways = ec2.describe_nat_gateways(
                    Filters=[{'Name': 'state', 'Values': ['available']}]
                )
                
                for nat in nat_gateways['NatGateways']:
                    tags = {tag['Key']: tag['Value'] for tag in nat.get('Tags', [])}
                    if self.is_resource_critical(tags):
                        continue
                    
                    try:
                        # Check bytes processed - use daily periods for NAT Gateway (bandwidth metric)
                        # NAT Gateway metrics are better analyzed daily rather than hourly
                        daily_period = 86400  # Keep daily for bandwidth analysis
                        
                        bytes_metrics = cloudwatch.get_metric_statistics(
                            Namespace='AWS/NATGateway',
                            MetricName='BytesOutToDestination',
                            Dimensions=[{'Name': 'NatGatewayId', 'Value': nat['NatGatewayId']}],
                            StartTime=datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=self.lookback_days),
                            EndTime=datetime.datetime.now(datetime.timezone.utc),
                            Period=daily_period,  # Daily analysis for data transfer
                            Statistics=['Sum']
                        )
                        
                        if bytes_metrics['Datapoints']:
                            total_bytes = sum(dp['Sum'] for dp in bytes_metrics['Datapoints'])
                            # If less than 1GB total over the period
                            if total_bytes < 1024**3:
                                monthly_cost = self.get_resource_cost('nat_gateway', '', region)
                                self.findings.append(self.create_finding(
                                    resource_type='NAT Gateway',
                                    resource_id=nat['NatGatewayId'],
                                    resource_name=self._get_name_tag(nat.get('Tags', [])),
                                    region=region,
                                    monthly_cost=monthly_cost,
                                    potential_savings=monthly_cost,
                                    reason=f'Very low data transfer ({total_bytes/(1024**2):.1f}MB over {self.lookback_days} days)',
                                    recommended_action='Consider using NAT Instance or remove if unused',
                                    risk_level='Medium',
                                    tags=tags
                                ))
                    except Exception as e:
                        print(f"    WARNING: Could not get data transfer metrics for NAT Gateway {nat['NatGatewayId']}: {e}")
            except Exception as e:
                print(f"Error analyzing NAT Gateways in {region}: {e}")
    
    def analyze_zombie_enis(self):
        """Find unattached Elastic Network Interfaces"""
        for region in self.regions:
            try:
                ec2 = self.get_cached_client('ec2', region)
                
                enis = ec2.describe_network_interfaces(
                    Filters=[{'Name': 'status', 'Values': ['available']}]
                )
                
                for eni in enis['NetworkInterfaces']:
                    if not eni.get('Attachment'):  # Not attached to any resource
                        tags = {tag['Key']: tag['Value'] for tag in eni.get('TagSet', [])}
                        if self.is_resource_critical(tags):
                            continue
                        
                        # ENIs are typically free but can indicate orphaned resources
                        self.findings.append(self.create_finding(
                            resource_type='Network Interface',
                            resource_id=eni['NetworkInterfaceId'],
                            resource_name=self._get_name_tag(eni.get('TagSet', [])),
                            region=region,
                            monthly_cost=0.0,
                            potential_savings=0.0,
                            reason='Network interface is not attached to any resource',
                            recommended_action='Delete if not needed for future use',
                            risk_level='Low',
                            tags=tags
                        ))
            except Exception as e:
                print(f"Error analyzing ENIs in {region}: {e}")
    
    def analyze_unused_security_groups(self):
        """Find security groups not attached to any resources"""
        for region in self.regions:
            try:
                ec2 = self.get_cached_client('ec2', region)
                
                # Get all security groups
                try:
                    security_groups = ec2.describe_security_groups()
                except Exception as e:
                    print(f"    WARNING: Could not list security groups in {region}: {e}")
                    continue
                
                # Get all resources that might use security groups
                try:
                    instances = ec2.describe_instances()
                except Exception as e:
                    print(f"    WARNING: Could not list EC2 instances for security group analysis in {region}: {e}")
                    instances = {'Reservations': []}
                
                load_balancers = []
                try:
                    elb = self.get_cached_client('elb', region)
                    elbv2 = self.get_cached_client('elbv2', region)
                    try:
                        classic_lbs = elb.describe_load_balancers()
                        load_balancers.extend(classic_lbs['LoadBalancerDescriptions'])
                    except Exception as e:
                        print(f"    WARNING: Could not list Classic Load Balancers for security group analysis: {e}")
                    try:
                        modern_lbs = elbv2.describe_load_balancers()
                        load_balancers.extend(modern_lbs['LoadBalancers'])
                    except Exception as e:
                        print(f"    WARNING: Could not list ALB/NLB for security group analysis: {e}")
                except Exception as e:
                    print(f"    WARNING: Could not access load balancer services for security group analysis: {e}")
                
                # Collect all used security group IDs
                used_sg_ids = set()
                
                # From EC2 instances
                for reservation in instances['Reservations']:
                    for instance in reservation['Instances']:
                        for sg in instance.get('SecurityGroups', []):
                            used_sg_ids.add(sg['GroupId'])
                
                # From Load Balancers
                for lb in load_balancers:
                    if 'SecurityGroups' in lb:
                        used_sg_ids.update(lb['SecurityGroups'])
                
                # From Network Interfaces
                try:
                    enis = ec2.describe_network_interfaces()
                    for eni in enis['NetworkInterfaces']:
                        for sg in eni.get('Groups', []):
                            used_sg_ids.add(sg['GroupId'])
                except Exception as e:
                    print(f"    WARNING: Could not list ENIs for security group analysis in {region}: {e}")
                
                # Find unused security groups
                for sg in security_groups['SecurityGroups']:
                    # Skip default security groups
                    if sg['GroupName'] == 'default':
                        continue
                    
                    if sg['GroupId'] not in used_sg_ids:
                        tags = {tag['Key']: tag['Value'] for tag in sg.get('Tags', [])}
                        if self.is_resource_critical(tags):
                            continue
                        
                        # Check if it has permissive rules (security risk)
                        risk_level = 'Low'
                        security_concerns = []
                        
                        for rule in sg.get('IpPermissions', []):
                            for ip_range in rule.get('IpRanges', []):
                                if ip_range.get('CidrIp') == '0.0.0.0/0':
                                    security_concerns.append(f"Port {rule.get('FromPort', 'all')} open to internet")
                                    risk_level = 'High'
                        
                        reason = 'Security group is not attached to any resource'
                        if security_concerns:
                            reason += f" and has security concerns: {'; '.join(security_concerns)}"
                        
                        self.findings.append(self.create_finding(
                            resource_type='Security Group',
                            resource_id=sg['GroupId'],
                            resource_name=sg['GroupName'],
                            region=region,
                            monthly_cost=0.0,
                            potential_savings=0.0,  # No cost but security benefit
                            reason=reason,
                            recommended_action='Delete unused security group to reduce attack surface',
                            risk_level=risk_level,
                            tags=tags
                        ))
            except Exception as e:
                print(f"Error analyzing Security Groups in {region}: {e}")
    
    def analyze_unused_iam_roles(self):
        """Find IAM roles with no recent activity (Global service)"""
        try:
            # IAM is global, only check once - use profile session
            session = self.get_aws_session('us-east-1')  # IAM is global but needs a region
            iam = self.get_cached_client('iam', 'us-east-1')  # IAM is global
            
            roles = iam.list_roles()
            
            for role in roles['Roles']:
                # Skip AWS service roles
                if role['RoleName'].startswith('aws-') or 'service-role' in role['Path']:
                    continue
                
                try:
                    # Get role tags
                    tags_response = iam.list_role_tags(RoleName=role['RoleName'])
                    tags = {tag['Key']: tag['Value'] for tag in tags_response['Tags']}
                    
                    if self.is_resource_critical(tags):
                        continue
                    
                    # Check when role was last used
                    role_details = iam.get_role(RoleName=role['RoleName'])
                    last_used = role_details['Role'].get('RoleLastUsed', {})
                    
                    if 'LastUsedDate' in last_used:
                        # Fix timezone handling - ensure both are timezone-aware
                        last_used_date = last_used['LastUsedDate']
                        if last_used_date.tzinfo is None:
                            last_used_date = last_used_date.replace(tzinfo=datetime.timezone.utc)
                        
                        days_since_use = (datetime.datetime.now(datetime.timezone.utc) - last_used_date).days
                        if days_since_use > self.lookback_days:
                            risk_level = 'High' if days_since_use > 90 else 'Medium'
                            finding = self.create_finding(
                                resource_type='IAM Role',
                                resource_id=role['RoleName'],
                                resource_name=role['RoleName'],
                                region='global',
                                monthly_cost=0.0,
                                potential_savings=0.0,  # No cost but security benefit
                                reason=f'Role has not been used for {days_since_use} days',
                                recommended_action='Review and delete if no longer needed (security risk)',
                                risk_level=risk_level,
                                tags=tags
                            )
                            self.findings.append(finding)
                    else:
                        # Role has never been used
                        finding = self.create_finding(
                            resource_type='IAM Role',
                            resource_id=role['RoleName'],
                            resource_name=role['RoleName'],
                            region='global',
                            monthly_cost=0.0,
                            potential_savings=0.0,
                            reason='Role has never been used',
                            recommended_action='Delete unused role to reduce security risk',
                            risk_level='Medium',
                            tags=tags
                        )
                        self.findings.append(finding)
                except Exception as e:
                    # Skip roles we can't access
                    continue
        except Exception as e:
            print(f"Error analyzing IAM roles: {e}")
    
    def analyze_expired_certificates(self):
        """Find expired or soon-to-expire ACM certificates"""
        for region in self.regions:
            try:
                session = self.get_aws_session(region)
                acm = self.get_cached_client('acm', region)
                
                certificates = acm.list_certificates(
                    CertificateStatuses=['EXPIRED', 'VALIDATION_TIMED_OUT', 'FAILED']
                )
                
                for cert in certificates['CertificateSummaryList']:
                    cert_details = acm.describe_certificate(CertificateArn=cert['CertificateArn'])
                    certificate = cert_details['Certificate']
                    
                    # Get tags
                    try:
                        tags_response = acm.list_tags_for_certificate(CertificateArn=cert['CertificateArn'])
                        tags = {tag['Key']: tag['Value'] for tag in tags_response['Tags']}
                    except:
                        tags = {}
                    
                    if self.is_resource_critical(tags):
                        continue
                    
                    status = certificate['Status']
                    domain_name = certificate['DomainName']
                    
                    if status == 'EXPIRED':
                        reason = 'Certificate has expired'
                        risk_level = 'High'
                        action = 'Delete expired certificate'
                    else:
                        reason = f'Certificate validation failed (status: {status})'
                        risk_level = 'Medium'
                        action = 'Review and delete failed certificate'
                    
                    self.findings.append(self.create_finding(
                        resource_type='ACM Certificate',
                        resource_id=cert['CertificateArn'].split('/')[-1],
                        resource_name=domain_name,
                        region=region,
                        monthly_cost=0.0,
                        potential_savings=0.0,
                        reason=reason,
                        recommended_action=action,
                        risk_level=risk_level,
                        tags=tags
                    ))
            except Exception as e:
                print(f"Error analyzing ACM certificates in {region}: {e}")
    
    def analyze_unused_kms_keys(self):
        """Find unused KMS keys"""
        for region in self.regions:
            try:
                session = self.get_aws_session(region)
                kms = self.get_cached_client('kms', region)
                
                keys = kms.list_keys()
                
                for key in keys['Keys']:
                    try:
                        key_details = kms.describe_key(KeyId=key['KeyId'])
                        key_metadata = key_details['KeyMetadata']
                        
                        # Skip AWS managed keys
                        if key_metadata['KeyManager'] == 'AWS':
                            continue
                        
                        # Get tags
                        try:
                            tags_response = kms.list_resource_tags(KeyId=key['KeyId'])
                            tags = {tag['TagKey']: tag['TagValue'] for tag in tags_response['Tags']}
                        except:
                            tags = {}
                        
                        if self.is_resource_critical(tags):
                            continue
                        
                        # Check key usage (simplified - in reality you'd check CloudTrail)
                        key_state = key_metadata['KeyState']
                        
                        if key_state in ['PendingDeletion', 'Disabled']:
                            monthly_cost = self.get_resource_cost('kms_key', '', region)
                            
                            reason = f'KMS key is in {key_state} state'
                            if key_state == 'PendingDeletion':
                                action = 'Key scheduled for deletion - monitor for any usage alerts'
                                risk_level = 'Low'
                            else:
                                action = 'Review disabled key and delete if not needed'
                                risk_level = 'Medium'
                            
                            self.findings.append(self.create_finding(
                                resource_type='KMS Key',
                                resource_id=key['KeyId'],
                                resource_name=key_metadata.get('Description', 'N/A'),
                                region=region,
                                monthly_cost=monthly_cost,
                                potential_savings=monthly_cost,
                                reason=reason,
                                recommended_action=action,
                                risk_level=risk_level,
                                tags=tags
                            ))
                    except Exception:
                        # Skip keys we can't access
                        continue
            except Exception as e:
                print(f"Error analyzing KMS keys in {region}: {e}")
    
    def analyze_unused_s3_buckets(self):
        """Find S3 buckets with no recent access (S3 is global but buckets are regional)"""
        try:
            # S3 is global but requires a session - use profile credentials
            session = self.get_aws_session('us-east-1')  # S3 API endpoint
            s3 = self.get_cached_client('s3', 'us-east-1')  # S3 is global
            cloudwatch = self.get_cached_client('cloudwatch', 'us-east-1')  # S3 metrics in us-east-1
            
            buckets = s3.list_buckets()
            
            for bucket in buckets['Buckets']:
                try:
                    # Get bucket location
                    location = s3.get_bucket_location(Bucket=bucket['Name'])
                    region = location['LocationConstraint'] or 'us-east-1'
                    
                    # Skip if not in our target regions
                    if region not in self.regions and 'us-east-1' not in self.regions:
                        continue
                    
                    # Get bucket tags
                    try:
                        tags_response = s3.get_bucket_tagging(Bucket=bucket['Name'])
                        tags = {tag['Key']: tag['Value'] for tag in tags_response['TagSet']}
                    except:
                        tags = {}
                    
                    if self.is_resource_critical(tags):
                        continue
                    
                    # Check if bucket is empty
                    try:
                        objects = s3.list_objects_v2(Bucket=bucket['Name'], MaxKeys=1)
                        if objects.get('KeyCount', 0) == 0:
                            self.findings.append(self.create_finding(
                                resource_type='S3 Bucket',
                                resource_id=bucket['Name'],
                                resource_name=bucket['Name'],
                                region=region,
                                monthly_cost=0.0,
                                potential_savings=0.0,  # Empty buckets don't cost much
                                reason='S3 bucket is empty and unused',
                                recommended_action='Delete empty bucket to reduce management overhead',
                                risk_level='Low',
                                tags=tags
                            ))
                            continue
                    except:
                        pass
                    
                    # Check S3 access metrics (requires CloudTrail or access logs)
                    try:
                        # Check bucket size - S3 metrics are reported daily, so use daily periods
                        try:
                            daily_period = 86400  # S3 metrics are reported daily
                            
                            size_metrics = cloudwatch.get_metric_statistics(
                                Namespace='AWS/S3',
                                MetricName='BucketSizeBytes',
                                Dimensions=[
                                    {'Name': 'BucketName', 'Value': bucket['Name']},
                                    {'Name': 'StorageType', 'Value': 'StandardStorage'}
                                ],
                                StartTime=datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=self.lookback_days),
                                EndTime=datetime.datetime.now(datetime.timezone.utc),
                                Period=daily_period,  # S3 metrics are naturally daily
                                Statistics=['Average']
                            )
                        except Exception as e:
                            print(f"    WARNING: Could not get size metrics for S3 bucket {bucket['Name']}: {e}")
                            continue
                        
                        # Check number of objects
                        try:
                            count_metrics = cloudwatch.get_metric_statistics(
                                Namespace='AWS/S3',
                                MetricName='NumberOfObjects',
                                Dimensions=[
                                    {'Name': 'BucketName', 'Value': bucket['Name']},
                                    {'Name': 'StorageType', 'Value': 'AllStorageTypes'}
                                ],
                                StartTime=datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=self.lookback_days),
                                EndTime=datetime.datetime.now(datetime.timezone.utc),
                                Period=daily_period,  # Use same daily period
                                Statistics=['Average']
                            )
                        except Exception as e:
                            print(f"    WARNING: Could not get object count metrics for S3 bucket {bucket['Name']}: {e}")
                            continue
                        
                        if size_metrics['Datapoints'] and count_metrics['Datapoints']:
                            avg_size = sum(dp['Average'] for dp in size_metrics['Datapoints']) / len(size_metrics['Datapoints'])
                            avg_objects = sum(dp['Average'] for dp in count_metrics['Datapoints']) / len(count_metrics['Datapoints'])
                            
                            # If very small (less than 1MB) and few objects
                            if avg_size < 1024*1024 and avg_objects < 10:
                                monthly_cost = 0.02  # Estimate small cost
                                finding = self.create_finding(
                                    resource_type='S3 Bucket',
                                    resource_id=bucket['Name'],
                                    resource_name=bucket['Name'],
                                    region=region,
                                    monthly_cost=monthly_cost,
                                    potential_savings=monthly_cost,
                                    reason=f'S3 bucket has minimal data ({avg_size/(1024*1024):.2f}MB, {avg_objects:.0f} objects)',
                                    recommended_action='Review bucket contents and consider deletion if not needed',
                                    risk_level='Medium',
                                    tags=tags
                                )
                                self.findings.append(finding)
                    except:
                        pass
                except Exception:
                    continue
        except Exception as e:
            print(f"Error analyzing S3 buckets: {e}")
    
    def analyze_old_ebs_snapshots(self):
        """Find old EBS snapshots beyond intelligent retention policy detection"""
        for region in self.regions:
            try:
                ec2 = self.get_cached_client('ec2', region)
                
                # Get all snapshots owned by this account
                snapshots = ec2.describe_snapshots(OwnerIds=['self'])
                
                total_snapshots = len(snapshots['Snapshots'])
                print(f"  Analyzing {total_snapshots} EBS snapshots with intelligent retention detection...")
                
                aws_backup_skipped = 0
                critical_skipped = 0
                analyzed_count = 0
                
                for snapshot in snapshots['Snapshots']:
                    # Fix timezone handling - ensure both are timezone-aware
                    snapshot_date = snapshot['StartTime']
                    if snapshot_date.tzinfo is None:
                        snapshot_date = snapshot_date.replace(tzinfo=datetime.timezone.utc)
                    
                    # Get tags
                    tags = {tag['Key']: tag['Value'] for tag in snapshot.get('Tags', [])}
                    
                    if self.is_resource_critical(tags):
                        critical_skipped += 1
                        continue
                    
                    # Skip AWS Backup managed snapshots (auto-lifecycle management)
                    if self.is_aws_backup_managed(snapshot):
                        aws_backup_skipped += 1
                        continue
                    
                    # Count snapshots actually analyzed
                    analyzed_count += 1
                    
                    # Intelligent retention policy detection
                    retention_days, policy_source, confidence = self._detect_retention_policy(snapshot, region)
                    cutoff_date = datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=retention_days)
                    
                    # Calculate snapshot age
                    now_utc = datetime.datetime.now(datetime.timezone.utc)
                    age_days = (now_utc - snapshot_date).days
                    
                    # Only flag snapshots that exceed their specific retention policy
                    if snapshot_date < cutoff_date:
                        # Check if this is an automated snapshot (more risky to delete)
                        description = snapshot.get('Description', '')
                        is_automated = 'Created by CreateImage' in description or 'backup' in description.lower()
                        
                        snapshot_size_gb = int(snapshot.get('VolumeSize', 0))
                        monthly_cost = snapshot_size_gb * self.get_resource_cost('ebs_snapshot', '', region)
                        
                        # Adjust risk level based on policy confidence and automation
                        if confidence == 'high' and not is_automated:
                            risk_level = 'Medium'
                        elif confidence == 'high' and is_automated:
                            risk_level = 'High'  
                        elif confidence == 'medium':
                            risk_level = 'Medium'
                        else:  # low confidence or default fallback
                            risk_level = 'Low'
                        
                        # Create more informative reason based on detected policy
                        if policy_source == 'default_fallback':
                            reason = f'Snapshot is {age_days} days old, exceeding default {retention_days}-day retention (no specific policy found)'
                            recommended_action = 'Review retention requirements and add appropriate tags or policies'
                        else:
                            policy_description = {
                                'snapshot_tags': 'snapshot retention tags',
                                'volume_tags': 'volume retention tags',
                                'dlm_policy': 'Data Lifecycle Manager policy',
                                'aws_backup': 'AWS Backup service policy',
                                'context_inference': f'inferred from {tags.get("Environment", "context")} environment',
                                'age_pattern': 'backup pattern analysis'
                            }
                            
                            reason = f'Snapshot is {age_days} days old, exceeding {retention_days}-day retention policy from {policy_description.get(policy_source, policy_source)}'
                            recommended_action = 'Review and delete if beyond business retention requirements'
                        
                        finding = self.create_finding(
                            resource_type='EBS Snapshot',
                            resource_id=snapshot['SnapshotId'],
                            resource_name=self._get_name_tag(snapshot.get('Tags', [])),
                            region=region,
                            monthly_cost=monthly_cost,
                            potential_savings=monthly_cost,
                            reason=reason,
                            recommended_action=recommended_action,
                            risk_level=risk_level,
                            tags=tags
                        )
                        self.findings.append(finding)
                
                # Print analysis summary
                if aws_backup_skipped > 0 or critical_skipped > 0:
                    print(f"    Skipped: {aws_backup_skipped} AWS Backup managed, {critical_skipped} critical resources")
                    print(f"    Analyzed: {analyzed_count} snapshots for retention policy violations")
                    
            except Exception as e:
                print(f"Error analyzing EBS snapshots in {region}: {e}")
    
    def analyze_unused_lambda_functions(self):
        """Find Lambda functions with no recent invocations"""
        for region in self.regions:
            try:
                session = self.get_aws_session(region)
                lambda_client = self.get_cached_client('lambda', region)
                cloudwatch = self.get_cached_client('cloudwatch', region)
                
                functions = lambda_client.list_functions()
                
                for function in functions['Functions']:
                    function_name = function['FunctionName']
                    
                    # Get function tags
                    try:
                        tags_response = lambda_client.list_tags(Resource=function['FunctionArn'])
                        tags = tags_response['Tags']
                    except:
                        tags = {}
                    
                    if self.is_resource_critical(tags):
                        continue
                    
                    # Check invocation metrics - Lambda metrics are better analyzed daily
                    try:
                        daily_period = 86400  # Daily analysis for Lambda invocations
                        
                        invocation_metrics = cloudwatch.get_metric_statistics(
                            Namespace='AWS/Lambda',
                            MetricName='Invocations',
                            Dimensions=[{'Name': 'FunctionName', 'Value': function_name}],
                            StartTime=datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=self.lookback_days),
                            EndTime=datetime.datetime.now(datetime.timezone.utc),
                            Period=daily_period,  # Daily periods for invocation counts
                            Statistics=['Sum']
                        )
                        
                        total_invocations = sum(dp['Sum'] for dp in invocation_metrics['Datapoints'])
                        
                        if total_invocations == 0:
                            # Estimate cost (simplified)
                            runtime = function.get('Runtime', 'python3.9')
                            memory_mb = function.get('MemorySize', 128)
                            
                            # Very rough cost estimate for unused function (mainly storage)
                            code_size_mb = function.get('CodeSize', 0) / (1024 * 1024)
                            monthly_cost = code_size_mb * 0.0000000309 * 30 * 24 * 60 * 60  # Storage cost
                            
                            self.findings.append(self.create_finding(
                                resource_type='Lambda Function',
                                resource_id=function_name,
                                resource_name=function_name,
                                region=region,
                                monthly_cost=monthly_cost,
                                potential_savings=monthly_cost,
                                reason=f'Lambda function has not been invoked in {self.lookback_days} days',
                                recommended_action='Review and delete if no longer needed',
                                risk_level='Medium',
                                tags=tags
                            ))
                    except Exception as e:
                        print(f"    WARNING: Could not get invocation metrics for Lambda function {function_name}: {e}")
            except Exception as e:
                print(f"Error analyzing Lambda functions in {region}: {e}")
    
    def analyze_unused_vpc_resources(self):
        """Find unused VPC resources like unused VPCs, Internet Gateways, Route Tables"""
        for region in self.regions:
            try:
                ec2 = self.get_cached_client('ec2', region)
                
                # Analyze unused VPCs
                vpcs = ec2.describe_vpcs()
                for vpc in vpcs['Vpcs']:
                    # Skip default VPCs
                    if vpc.get('IsDefault', False):
                        continue
                    
                    vpc_id = vpc['VpcId']
                    
                    # Check if VPC has any resources
                    instances = ec2.describe_instances(Filters=[{'Name': 'vpc-id', 'Values': [vpc_id]}])
                    has_instances = any(reservation['Instances'] for reservation in instances['Reservations'])
                    
                    if not has_instances:
                        # Check for other resources (RDS, ELB, etc.)
                        subnets = ec2.describe_subnets(Filters=[{'Name': 'vpc-id', 'Values': [vpc_id]}])
                        
                        # If VPC only has default subnets and no instances
                        non_default_subnets = [s for s in subnets['Subnets'] if not s.get('DefaultForAz', False)]
                        
                        if not non_default_subnets:
                            tags = {tag['Key']: tag['Value'] for tag in vpc.get('Tags', [])}
                            
                            if self.is_resource_critical(tags):
                                continue
                            
                            self.findings.append(self.create_finding(
                                resource_type='VPC',
                                resource_id=vpc_id,
                                resource_name=self._get_name_tag(vpc.get('Tags', [])),
                                region=region,
                                monthly_cost=0.0,
                                potential_savings=0.0,
                                reason='VPC has no instances or custom subnets',
                                recommended_action='Delete empty VPC to reduce management complexity',
                                risk_level='Medium',
                                tags=tags
                            ))
                
                # Analyze unattached Internet Gateways
                igws = ec2.describe_internet_gateways(
                    Filters=[{'Name': 'attachment.state', 'Values': ['available']}]
                )
                
                for igw in igws['InternetGateways']:
                    if not igw.get('Attachments'):
                        tags = {tag['Key']: tag['Value'] for tag in igw.get('Tags', [])}
                        
                        if self.is_resource_critical(tags):
                            continue
                        
                        self.findings.append(self.create_finding(
                            resource_type='Internet Gateway',
                            resource_id=igw['InternetGatewayId'],
                            resource_name=self._get_name_tag(igw.get('Tags', [])),
                            region=region,
                            monthly_cost=0.0,
                            potential_savings=0.0,
                            reason='Internet Gateway is not attached to any VPC',
                            recommended_action='Delete unattached Internet Gateway',
                            risk_level='Low',
                            tags=tags
                        ))
                
                # Analyze unused Route Tables
                route_tables = ec2.describe_route_tables()
                
                for rt in route_tables['RouteTables']:
                    # Skip main route tables
                    is_main = any(assoc.get('Main', False) for assoc in rt.get('Associations', []))
                    
                    if not is_main and not rt.get('Associations'):
                        tags = {tag['Key']: tag['Value'] for tag in rt.get('Tags', [])}
                        
                        if self.is_resource_critical(tags):
                            continue
                        
                        self.findings.append(self.create_finding(
                            resource_type='Route Table',
                            resource_id=rt['RouteTableId'],
                            resource_name=self._get_name_tag(rt.get('Tags', [])),
                            region=region,
                            monthly_cost=0.0,
                            potential_savings=0.0,
                            reason='Route table is not associated with any subnets',
                            recommended_action='Delete unused route table',
                            risk_level='Low',
                            tags=tags
                        ))
            except Exception as e:
                print(f"Error analyzing VPC resources in {region}: {e}")
    
    def _get_name_tag(self, tags: List[Dict]) -> str:
        """Extract Name tag from resource tags"""
        for tag in tags:
            if tag.get('Key') == 'Name':
                return tag.get('Value', 'N/A')
        return 'N/A'
    
    def run_analysis_for_profile(self, profile_name: str):
        """Run analysis for a specific profile"""
        self.set_current_profile(profile_name)
        
        analysis_methods = [
            ("Unattached EBS Volumes", self.analyze_unattached_ebs_volumes),
            ("Idle Elastic IPs", self.analyze_idle_elastic_ips),
            ("Unused EC2 Instances", self.analyze_unused_ec2_instances),
            ("Abandoned RDS Instances", self.analyze_abandoned_rds_instances),
            ("Unused Load Balancers", self.analyze_unused_load_balancers),
            ("Unused NAT Gateways", self.analyze_unused_nat_gateways),
            ("Zombie ENIs", self.analyze_zombie_enis),
            ("Unused Security Groups", self.analyze_unused_security_groups),
            ("Unused IAM Roles", self.analyze_unused_iam_roles),
            ("Expired ACM Certificates", self.analyze_expired_certificates),
            ("Unused KMS Keys", self.analyze_unused_kms_keys),
            ("Unused S3 Buckets", self.analyze_unused_s3_buckets),
            ("Old EBS Snapshots", self.analyze_old_ebs_snapshots),
            ("Unused Lambda Functions", self.analyze_unused_lambda_functions),
            ("Unused VPC Resources", self.analyze_unused_vpc_resources)
        ]
        
        profile_findings_start = len(self.findings)
        
        for name, method in analysis_methods:
            print(f"  🔍 Analyzing {name}...")
            try:
                method()
            except Exception as e:
                print(f"    ⚠️  Error in {name}: {e}")
        
        profile_findings_count = len(self.findings) - profile_findings_start
        print(f"  [OK] Found {profile_findings_count} opportunities in profile {profile_name}")
        
        return profile_findings_count
    
    def run_analysis(self):
        """Run complete cost optimization analysis across all profiles"""
        print("🚀 Starting AWS Cost Optimization & Security Analysis...")
        print(f"🌍 Regions: {', '.join(self.regions)}")
        print(f"📅 Lookback period: {self.lookback_days} days")
        
        total_findings = 0
        
        for profile_name in self.profiles:
            print(f"\n📋 Analyzing profile: {profile_name}")
            try:
                findings_count = self.run_analysis_for_profile(profile_name)
                total_findings += findings_count
            except Exception as e:
                print(f"  ERROR: Failed to analyze profile {profile_name}: {e}")
                continue
        
        print(f"\n🎉 Analysis complete! Found {total_findings} total optimization opportunities across {len(self.profiles)} profiles.")
        return self.findings
    
    def generate_report(self, output_file: str = None) -> str:
        """Generate comprehensive markdown report with security focus"""
        if not self.findings:
            return "# AWS Cost Optimization & Security Report\n\nNo optimization opportunities found."
        
        # Sort findings by potential savings
        sorted_findings = sorted(self.findings, key=lambda x: x.potential_savings, reverse=True)
        
        # Calculate totals
        total_monthly_savings = sum(f.potential_savings for f in sorted_findings)
        total_annual_savings = total_monthly_savings * 12
        
        # Group by resource type, security vs cost focus, and by profile/account
        by_type = defaultdict(list)
        by_profile = defaultdict(list)
        security_focused = []
        cost_focused = []
        
        security_resource_types = ['Security Group', 'IAM Role', 'ACM Certificate', 'KMS Key']
        
        for finding in sorted_findings:
            by_type[finding.resource_type].append(finding)
            by_profile[finding.profile_name].append(finding)
            if finding.resource_type in security_resource_types or 'security' in finding.reason.lower():
                security_focused.append(finding)
            else:
                cost_focused.append(finding)
        
        # Calculate security vs cost metrics
        security_count = len(security_focused)
        cost_count = len(cost_focused)
        high_risk_count = len([f for f in sorted_findings if f.risk_level == 'High'])
        unique_profiles = len(set(f.profile_name for f in sorted_findings))
        unique_accounts = len(set(f.account_id for f in sorted_findings if f.account_id != 'unknown'))
        
        report = f"""# AWS Cost Optimization & Security Cleanup Report

Generated on: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## SUMMARY: Executive Summary

- **Total Resources Analyzed**: {len(sorted_findings)}
- **🔒 Security-Focused Items**: {security_count}
- **💰 Cost-Focused Items**: {cost_count}
- **⚠️ High Risk Items**: {high_risk_count}
- **Estimated Monthly Savings**: ${total_monthly_savings:,.2f}
- **Estimated Annual Savings**: ${total_annual_savings:,.2f}
- **Regions Analyzed**: {', '.join(self.regions)}
- **👥 Profiles Analyzed**: {unique_profiles}
- **🏢 AWS Accounts**: {unique_accounts}

{self._get_cost_breakdown_summary(by_type)}

## 👥 Multi-Account Analysis

{self._get_profile_summary(by_profile, sorted_findings)}

## 🔐 Security Analysis Summary

{self._get_security_summary(security_focused, sorted_findings)}

## 💰 Cost Optimization Opportunities

"""
        
        for resource_type, findings in by_type.items():
            type_savings = sum(f.potential_savings for f in findings)
            security_indicator = "🔒" if resource_type in security_resource_types else "💰"
            
            report += f"### {security_indicator} {resource_type} ({len(findings)} resources)\n\n"
            report += f"**Potential Monthly Savings**: ${type_savings:,.2f}\n\n"
            
            for finding in findings:
                risk_emoji = {"High": "🔴", "Medium": "🟡", "Low": "🟢"}.get(finding.risk_level, "⚪")
                
                report += f"#### {risk_emoji} {finding.resource_name or finding.resource_id}\n\n"
                report += f"- **Resource ID**: `{finding.resource_id}`\n"
                report += f"- **Region**: {finding.region}\n"
                report += f"- **Current Monthly Cost**: ${finding.monthly_cost:,.2f}\n"
                report += f"- **Potential Monthly Savings**: ${finding.potential_savings:,.2f}\n"
                report += f"- **Risk Level**: {risk_emoji} {finding.risk_level}\n"
                report += f"- **Reason**: {finding.reason}\n"
                report += f"- **Recommended Action**: {finding.recommended_action}\n"
                
                if finding.tags:
                    report += f"- **Tags**: {', '.join([f'{k}:{v}' for k, v in finding.tags.items()])}\n"
                report += "\n---\n\n"
        
        report += f"""## TARGET: Prioritized Action Plan

### 🔴 High Priority (Immediate Action)
{self._get_priority_section(sorted_findings, 'High', total_monthly_savings)}

### 🟡 Medium Priority (Review Required)
{self._get_priority_section(sorted_findings, 'Medium', total_monthly_savings)}

### 🟢 Low Priority (Safe to Remove)
{self._get_priority_section(sorted_findings, 'Low', total_monthly_savings)}

## ⚠️ Risk Assessment

- **🔴 High Risk**: Manual review required, potential service disruption or security impact
- **🟡 Medium Risk**: Verify with application teams before action
- **🟢 Low Risk**: Generally safe to remove with minimal impact

## 🔐 Security Recommendations

{self._get_security_recommendations(security_focused)}

## 📋 Implementation Checklist

### Before Taking Action:
- [ ] Review all High Risk items with security team
- [ ] Create backups/snapshots where applicable
- [ ] Notify application teams of planned changes
- [ ] Schedule maintenance windows for critical resources

### Implementation Order:
1. **Start with Low Risk items** to gain confidence
2. **Address Security Groups** to reduce attack surface
3. **Clean up IAM roles** to improve security posture
4. **Remove expired certificates** to prevent outages
5. **Delete unused storage** to reduce costs
6. **Monitor services** after each batch of changes

## 📈 Expected Benefits

- **Cost Reduction**: ${total_monthly_savings:,.2f}/month (${total_annual_savings:,.2f}/year)
- **Security Improvement**: Reduced attack surface and compliance posture
- **Operational Excellence**: Simplified resource management
- **Risk Mitigation**: Eliminated orphaned resources and expired certificates

---
*This report was generated by the Enhanced AWS Cost Optimization & Security Analyzer*
"""
        
        if output_file:
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(report)
            print(f"Report saved to {output_file}")
        
        return report
    
    def generate_csv_report(self, output_file: str) -> str:
        """Generate CSV report for cost optimization findings"""
        if not self.findings:
            # Create empty CSV with headers only
            with open(output_file, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(['Resource Type', 'Resource ID', 'Resource Name', 'Region', 'Account ID', 
                               'Profile Name', 'Monthly Cost ($)', 'Potential Savings ($)', 'Risk Level', 
                               'Reason', 'Recommended Action', 'Tags'])
            return output_file
        
        # Sort findings by potential savings
        sorted_findings = sorted(self.findings, key=lambda x: x.potential_savings, reverse=True)
        
        # Calculate summary statistics
        total_monthly_cost = sum(f.monthly_cost for f in self.findings)
        total_potential_savings = sum(f.potential_savings for f in self.findings)
        total_annual_savings = total_potential_savings * 12
        
        # Group by risk level
        risk_counts = defaultdict(int)
        risk_savings = defaultdict(float)
        for finding in self.findings:
            risk_counts[finding.risk_level] += 1
            risk_savings[finding.risk_level] += finding.potential_savings
        
        with open(output_file, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            
            # Write summary header
            writer.writerow(['# AWS Cost Optimization Analysis Summary'])
            writer.writerow([f'Total Resources Analyzed: {len(self.findings)}'])
            writer.writerow([f'Total Monthly Cost: ${total_monthly_cost:.2f}'])
            writer.writerow([f'Total Potential Monthly Savings: ${total_potential_savings:.2f}'])
            writer.writerow([f'Total Potential Annual Savings: ${total_annual_savings:.2f}'])
            writer.writerow([])
            
            # Write risk level breakdown
            writer.writerow(['Risk Level Breakdown:'])
            for risk_level in ['High', 'Medium', 'Low']:
                if risk_level in risk_counts:
                    writer.writerow([f'{risk_level} Risk: {risk_counts[risk_level]} resources, ${risk_savings[risk_level]:.2f} monthly savings'])
            writer.writerow([])
            
            # Write column headers
            writer.writerow(['Resource Type', 'Resource ID', 'Resource Name', 'Region', 'Account ID', 
                           'Profile Name', 'Monthly Cost ($)', 'Potential Savings ($)', 'Risk Level', 
                           'Reason', 'Recommended Action', 'Tags'])
            
            # Write findings data
            for finding in sorted_findings:
                # Format tags as key=value pairs
                tags_str = '; '.join([f'{k}={v}' for k, v in finding.tags.items()]) if finding.tags else ''
                
                writer.writerow([
                    finding.resource_type,
                    finding.resource_id,
                    finding.resource_name or 'N/A',
                    finding.region,
                    finding.account_id,
                    finding.profile_name,
                    f'{finding.monthly_cost:.2f}',
                    f'{finding.potential_savings:.2f}',
                    finding.risk_level,
                    finding.reason,
                    finding.recommended_action,
                    tags_str
                ])
        
        print(f"CSV report saved to {output_file}")
        return output_file
    
    def _get_security_summary(self, security_findings: List[ResourceAnalysis], all_findings: List[ResourceAnalysis]) -> str:
        """Generate security-focused summary section"""
        if not security_findings:
            return "**[OK] No major security cleanup opportunities identified.**\n"
        
        by_risk = defaultdict(list)
        for finding in security_findings:
            by_risk[finding.risk_level].append(finding)
        
        summary = f"**Security Resources Identified**: {len(security_findings)}\n\n"
        
        if by_risk['High']:
            summary += f"**🔴 Critical Security Issues ({len(by_risk['High'])})**:\n"
            for finding in by_risk['High'][:3]:
                summary += f"- {finding.resource_type}: {finding.resource_id} - {finding.reason}\n"
            summary += "\n"
        
        if by_risk['Medium']:
            summary += f"**🟡 Security Concerns ({len(by_risk['Medium'])})**:\n"
            for finding in by_risk['Medium'][:3]:
                summary += f"- {finding.resource_type}: {finding.resource_id}\n"
            summary += "\n"
        
        return summary
    
    def _get_cost_breakdown_summary(self, by_type: Dict) -> str:
        """Generate cost breakdown section with potential savings by resource type"""
        if not by_type:
            return "## 💰 Cost Breakdown\n\nNo cost optimization opportunities found.\n"
        
        # Sort resource types by total potential savings (descending)
        sorted_types = sorted(by_type.items(), key=lambda x: sum(f.potential_savings for f in x[1]), reverse=True)
        
        breakdown_text = "## 💰 Cost Breakdown\n\n"
        
        for resource_type, findings in sorted_types:
            type_savings = sum(f.potential_savings for f in findings)
            resource_count = len(findings)
            
            # Skip resource types with no cost savings
            if type_savings == 0:
                continue
            
            # Add emoji based on resource type
            emoji = "💰"
            if "Security" in resource_type or "IAM" in resource_type or "ACM" in resource_type:
                emoji = "🔒"
            elif "EC2" in resource_type:
                emoji = "🖥️"
            elif "EBS" in resource_type:
                emoji = "💾"
            elif "S3" in resource_type:
                emoji = "🪣"
            elif "RDS" in resource_type:
                emoji = "🗄️"
            elif "Lambda" in resource_type:
                emoji = "⚡"
            elif "Load Balancer" in resource_type:
                emoji = "⚖️"
            elif "NAT" in resource_type:
                emoji = "🌐"
            elif "VPC" in resource_type:
                emoji = "🏗️"
                
            breakdown_text += f"### {emoji} {resource_type} ({resource_count} resources)\n\n"
            breakdown_text += f"**Potential Monthly Savings**: ${type_savings:,.2f}\n\n"
            
            # Add top 3 highest cost items for this resource type
            top_findings = sorted(findings, key=lambda x: x.potential_savings, reverse=True)[:3]
            
            for i, finding in enumerate(top_findings):
                if finding.potential_savings > 0:
                    risk_emoji = {"High": "🔴", "Medium": "🟡", "Low": "🟢"}.get(finding.risk_level, "⚪")
                    breakdown_text += f"{i+1}. **{finding.resource_name or finding.resource_id}** "
                    breakdown_text += f"({finding.region}) - ${finding.potential_savings:,.2f}/month {risk_emoji}\n"
            
            if len(findings) > 3:
                remaining = len(findings) - 3
                remaining_savings = sum(f.potential_savings for f in findings[3:])
                breakdown_text += f"   *...and {remaining} more resources with ${remaining_savings:,.2f}/month potential savings*\n"
                
            breakdown_text += "\n"
        
        return breakdown_text
    
    def _get_profile_summary(self, by_profile: Dict, all_findings: List[ResourceAnalysis]) -> str:
        """Generate multi-profile summary section"""
        if len(by_profile) <= 1:
            return "**Single profile analysis - no cross-account comparison available.**\n"
        
        summary = "### Profile Breakdown:\n\n"
        
        for profile_name, findings in by_profile.items():
            if not findings:
                continue
                
            profile_savings = sum(f.potential_savings for f in findings)
            profile_high_risk = len([f for f in findings if f.risk_level == 'High'])
            account_id = findings[0].account_id if findings else 'unknown'
            
            summary += f"**{profile_name}** ({account_id}):\n"
            summary += f"- Resources: {len(findings)} | Savings: ${profile_savings:,.2f}/month | High Risk: {profile_high_risk}\n"
            
            # Show top finding for this profile
            top_finding = max(findings, key=lambda x: x.potential_savings)
            if top_finding.potential_savings > 0:
                summary += f"- Top opportunity: {top_finding.resource_type} ({top_finding.resource_id}) - ${top_finding.potential_savings:,.2f}/month\n"
            
            summary += "\n"
        
        return summary
    
    def _get_security_recommendations(self, security_findings: List[ResourceAnalysis]) -> str:
        """Generate security-specific recommendations"""
        if not security_findings:
            return "**[OK] No specific security recommendations at this time.**\n"
        
        recommendations = "### Immediate Security Actions:\n\n"
        
        # Group by resource type for targeted recommendations
        by_type = defaultdict(list)
        for finding in security_findings:
            by_type[finding.resource_type].append(finding)
        
        if 'Security Group' in by_type:
            sg_count = len(by_type['Security Group'])
            recommendations += f"1. **Review {sg_count} unused security groups** - These pose security risks and should be deleted\n"
        
        if 'IAM Role' in by_type:
            iam_count = len(by_type['IAM Role'])
            recommendations += f"2. **Audit {iam_count} dormant IAM roles** - Follow principle of least privilege\n"
        
        if 'ACM Certificate' in by_type:
            cert_count = len(by_type['ACM Certificate'])
            recommendations += f"3. **Clean up {cert_count} expired certificates** - Prevent service disruptions\n"
        
        recommendations += "\n### Security Best Practices:\n\n"
        recommendations += "- Implement automated resource tagging for better governance\n"
        recommendations += "- Set up CloudTrail for resource usage monitoring\n"
        recommendations += "- Enable Config rules for compliance monitoring\n"
        recommendations += "- Schedule regular security and cost reviews\n\n"
        
        return recommendations
    
    def _get_priority_section(self, findings: List[ResourceAnalysis], risk_level: str, total_savings: float) -> str:
        """Generate priority section for report"""
        priority_findings = [f for f in findings if f.risk_level == risk_level]
        if not priority_findings:
            return f"No {risk_level.lower()} priority items found.\n"
        
        priority_savings = sum(f.potential_savings for f in priority_findings)
        percentage = (priority_savings / total_savings) * 100 if total_savings > 0 else 0
        
        section = f"**Resources**: {len(priority_findings)} | **Monthly Savings**: ${priority_savings:,.2f} ({percentage:.1f}%)\n\n"
        
        for finding in priority_findings[:5]:  # Show top 5
            risk_emoji = {"High": "🔴", "Medium": "🟡", "Low": "🟢"}.get(finding.risk_level, "⚪")
            section += f"- {risk_emoji} {finding.resource_type}: `{finding.resource_id}` (${finding.potential_savings:,.2f}/month)\n"
        
        if len(priority_findings) > 5:
            section += f"- ... and {len(priority_findings) - 5} more resources\n"
        
        section += "\n"
        return section

def main():
    parser = argparse.ArgumentParser(description='AWS Cost Optimization & Security Analyzer')
    parser.add_argument('--regions', nargs='+', default=['us-east-1', 'us-west-2'], 
                       help='AWS regions to analyze')
    parser.add_argument('--lookback-days', type=int, default=30,
                       help='Number of days to look back for metrics')
    parser.add_argument('--account-id', type=str,
                       help='Specific AWS account ID to analyze')
    parser.add_argument('--critical-tag', type=str,
                       help='Tag to identify critical resources to exclude')
    parser.add_argument('--output', type=str, default='aws_cost_optimization_report.md',
                       help='Output file for the report')
    parser.add_argument('--csv-output', type=str,
                       help='Generate CSV report in addition to markdown (specify CSV file path)')
    parser.add_argument('--format', type=str, choices=['markdown', 'csv', 'both'], default='markdown',
                       help='Output format: markdown (default), csv, or both')
    
    # Profile management options
    profile_group = parser.add_mutually_exclusive_group()
    profile_group.add_argument('--profile', type=str,
                              help='Specific AWS profile to use')
    profile_group.add_argument('--profiles', nargs='+',
                              help='List of AWS profiles to analyze')
    profile_group.add_argument('--all-profiles', action='store_true',
                              help='Analyze all available AWS profiles')
    profile_group.add_argument('--interactive', action='store_true', default=True,
                              help='Interactive profile selection (default)')
    
    args = parser.parse_args()
    
    try:
        profile_manager = AWSProfileManager()
        selected_profiles = []
        
        # Determine which profiles to use
        if args.profile:
            if profile_manager.validate_profile(args.profile):
                selected_profiles = [args.profile]
                print(f"TARGET: Using profile: {args.profile}")
            else:
                print(f"ERROR: Profile '{args.profile}' not found or not accessible")
                sys.exit(1)
        elif args.profiles:
            for profile in args.profiles:
                if profile_manager.validate_profile(profile):
                    selected_profiles.append(profile)
                else:
                    print(f"⚠️  Profile '{profile}' not accessible, skipping")
            if not selected_profiles:
                print("ERROR: No accessible profiles specified")
                sys.exit(1)
            print(f"TARGET: Using profiles: {', '.join(selected_profiles)}")
        elif args.all_profiles:
            accessible_profiles = profile_manager.get_accessible_profiles()
            selected_profiles = [p.name for p in accessible_profiles]
            print(f"TARGET: Using all profiles: {', '.join([p.display_name for p in accessible_profiles])}")
        else:
            # Interactive selection (default)
            try:
                selected_profiles = profile_manager.interactive_profile_selection()
            except KeyboardInterrupt:
                print("\nERROR: Analysis cancelled by user")
                sys.exit(0)
        
        if not selected_profiles:
            print("ERROR: No profiles selected for analysis")
            sys.exit(1)
        
        # Interactive region and lookback days selection (only for --interactive mode)
        final_regions = args.regions
        final_lookback_days = args.lookback_days
        
        if args.interactive and not (args.profile or args.profiles or args.all_profiles):
            # User chose interactive mode, get regions and lookback days interactively
            try:
                final_regions = profile_manager.interactive_region_selection(args.regions)
                final_lookback_days = profile_manager.interactive_lookback_days_selection(args.lookback_days)
            except KeyboardInterrupt:
                print("\nERROR: Configuration cancelled by user")
                sys.exit(0)
        
        optimizer = AWSCostOptimizer(
            regions=final_regions,
            lookback_days=final_lookback_days,
            account_id=args.account_id,
            critical_tag=args.critical_tag,
            profiles=selected_profiles
        )
        
        findings = optimizer.run_analysis()
        
        # Generate reports based on format selection
        if args.format == 'markdown' or args.format == 'both':
            report = optimizer.generate_report(args.output)
        
        if args.format == 'csv' or args.format == 'both' or args.csv_output:
            # Determine CSV output file name
            if args.csv_output:
                csv_file = args.csv_output
            elif args.format == 'csv':
                # Replace .md extension with .csv or add .csv
                base_name = args.output.rsplit('.', 1)[0] if '.' in args.output else args.output
                csv_file = f"{base_name}.csv"
            else:  # format == 'both'
                base_name = args.output.rsplit('.', 1)[0] if '.' in args.output else args.output
                csv_file = f"{base_name}.csv"
            
            optimizer.generate_csv_report(csv_file)
        
        if findings:
            total_savings = sum(f.potential_savings for f in findings)
            security_findings = len([f for f in findings if f.resource_type in ['Security Group', 'IAM Role', 'ACM Certificate', 'KMS Key']])
            
            print(f"\nSUMMARY: Analysis Summary:")
            print(f"  • Total opportunities: {len(findings)}")
            print(f"  • Security-focused: {security_findings}")
            print(f"  • Monthly savings potential: ${total_savings:,.2f}")
            print(f"  • Annual savings potential: ${total_savings * 12:,.2f}")
            print(f"\n📄 Report saved to: {args.output}")
        else:
            print("\n[OK] No optimization opportunities found. Your AWS environment is well-optimized!")
            
    except Exception as e:
        print(f"ERROR: Error running analysis: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()