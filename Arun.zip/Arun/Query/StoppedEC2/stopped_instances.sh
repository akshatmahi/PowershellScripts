#!/bin/bash

# Function to pause execution
safe_pause() {
    local sec=$1
    echo "Pausing $sec seconds..."
    sleep $sec
}

# Define AWS regions to check
regions=("us-east-1" "us-west-2")

# Get all AWS CLI profiles
echo "Getting AWS CLI profiles..."
mapfile -t all_profiles < <(aws configure list-profiles 2>/dev/null)

if [ ${#all_profiles[@]} -eq 0 ]; then
    echo "No AWS CLI profiles found. Please configure AWS CLI first."
    exit 1
fi

# Show menu
echo -e "\033[36mAvailable AWS CLI profiles:\033[0m"
for i in "${!all_profiles[@]}"; do
    num=$((i + 1))
    echo "$num. ${all_profiles[$i]}"
done

echo ""
read -p "Enter 'all' to run for all profiles, or enter numbers separated by commas (e.g., 1,3,5): " choice

# Decide profiles to run
if [ "$choice" = "all" ]; then
    profiles_to_run=("${all_profiles[@]}")
else
    # Parse comma-separated numbers
    IFS=',' read -ra selected_numbers <<< "$choice"
    profiles_to_run=()
    
    for num in "${selected_numbers[@]}"; do
        # Trim whitespace
        num=$(echo "$num" | xargs)
        
        # Validate it's a number
        if [[ "$num" =~ ^[0-9]+$ ]]; then
            index=$((num - 1))
            
            # Check if index is valid
            if [ $index -ge 0 ] && [ $index -lt ${#all_profiles[@]} ]; then
                profiles_to_run+=("${all_profiles[$index]}")
            else
                echo -e "\033[31mInvalid number: $num\033[0m"
            fi
        else
            echo -e "\033[31mInvalid input: $num (not a number)\033[0m"
        fi
    done
    
    if [ ${#profiles_to_run[@]} -eq 0 ]; then
        echo -e "\033[31mNo valid profiles selected. Exiting.\033[0m"
        exit 1
    fi
fi

# Initialize results collection
timestamp=$(date +"%Y%m%d-%H%M%S")
csv_path="StoppedEC2Instances_$timestamp.csv"
error_log_path="EC2ScanErrors_$timestamp.log"

# Create CSV header
echo "Profile,Region,InstanceId,InstanceName,InstanceType,LaunchTime,State,PrivateIp,PublicIp,VpcId,SubnetId,Platform,KeyName" > "$csv_path"

# Initialize counters
total_instances=0
total_errors=0

# Loop through selected profiles
for profile in "${profiles_to_run[@]}"; do
    echo -e "\n\033[36m=== Processing profile: $profile ===\033[0m"
    
    for region in "${regions[@]}"; do
        echo -e "  \033[96mChecking region: $region\033[0m"
        
        # Get stopped instances from AWS CLI with detailed error handling
        result=$(aws ec2 describe-instances \
            --filters "Name=instance-state-name,Values=stopped" \
            --region "$region" \
            --profile "$profile" \
            --output json 2>&1)
        
        # Check AWS CLI exit code
        if [ $? -ne 0 ]; then
            error_type="Unknown API Error"
            
            # Known error patterns
            if echo "$result" | grep -q "could not be found"; then
                error_type="Region disabled or unavailable"
            elif echo "$result" | grep -q "not authorized to perform"; then
                error_type="Permission denied"
            elif echo "$result" | grep -q "InvalidClientTokenId"; then
                error_type="Invalid AWS credentials"
            elif echo "$result" | grep -q "AuthFailure"; then
                error_type="Authentication failure"
            elif echo "$result" | grep -q "OptInRequired"; then
                error_type="Region not enabled for this account"
            elif echo "$result" | grep -q "RequestLimitExceeded"; then
                error_type="API rate limit exceeded"
            fi
            
            log_message="PROFILE: $profile | REGION: $region | ERROR: $error_type\nDETAILS: $result"
            echo -e "$log_message" >> "$error_log_path"
            
            echo -e "    \033[31m$error_type - see error log for details\033[0m"
            ((total_errors++))
            continue
        fi
        
        # Process successful response
        if ! echo "$result" | jq -e '.Reservations' > /dev/null 2>&1; then
            echo -e "    \033[90mNo stopped instances found\033[0m"
            continue
        fi
        
        # Check if reservations array is empty
        reservation_count=$(echo "$result" | jq '.Reservations | length')
        if [ "$reservation_count" -eq 0 ]; then
            echo -e "    \033[90mNo stopped instances found\033[0m"
            continue
        fi
        
        # Process instances
        instance_count=0
        
        # Extract instance data using jq
        echo "$result" | jq -r '
            .Reservations[] | 
            .Instances[] | 
            [
                "'"$profile"'",
                "'"$region"'",
                .InstanceId,
                ((.Tags[]? | select(.Key == "Name") | .Value) // "N/A"),
                .InstanceType,
                .LaunchTime,
                .State.Name,
                (.PrivateIpAddress // "N/A"),
                (.PublicIpAddress // "N/A"),
                .VpcId,
                .SubnetId,
                (.Platform // "Linux/UNIX"),
                (.KeyName // "N/A")
            ] | 
            @csv' >> "$csv_path"
        
        # Count instances for this region
        instance_count=$(echo "$result" | jq '[.Reservations[] | .Instances[]] | length')
        total_instances=$((total_instances + instance_count))
        
        echo -e "    \033[32mFound $instance_count stopped instance(s)\033[0m"
        
        # Brief pause between regions
        safe_pause 1
    done
    
    echo -e "\n$(printf '=%.0s' {1..50})"
done

# Show results
if [ $total_instances -gt 0 ]; then
    echo -e "\n\033[36mExported $total_instances stopped instances to CSV:\033[0m"
    echo -e "\033[33m$(realpath "$csv_path")\033[0m"
else
    echo -e "\n\033[93mNo stopped instances found across all profiles and regions\033[0m"
    rm "$csv_path"  # Remove empty CSV file
fi

# Show error log status
if [ -f "$error_log_path" ] && [ -s "$error_log_path" ]; then
    error_count=$(grep -c "PROFILE:" "$error_log_path")
    echo -e "\n\033[31mEncountered $error_count errors - full details in error log:\033[0m"
    echo -e "\033[33m$(realpath "$error_log_path")\033[0m"
    
    # Show error summary
    echo -e "\n\033[31mError Summary:\033[0m"
    grep "ERROR:" "$error_log_path" | cut -d' ' -f6- | sort | uniq -c | while read count error; do
        echo -e "\033[31m$count x $error\033[0m"
    done
else
    # Remove empty error log
    [ -f "$error_log_path" ] && rm "$error_log_path"
fi

echo -e "\n\033[32mScript completed!\033[0m"