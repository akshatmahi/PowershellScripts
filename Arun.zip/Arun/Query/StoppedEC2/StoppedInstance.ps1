function Safe-Pause ($sec) {
    Write-Host "Pausing $sec seconds..."
    Start-Sleep -Seconds $sec
}

# Define AWS regions to check
$regions = @(
    "us-east-1", "us-west-2"
)

# Get all AWS CLI profiles
$allProfiles = aws configure list-profiles

# Show menu
Write-Host "Available AWS CLI profiles:" -ForegroundColor Cyan
for ($i = 0; $i -lt $allProfiles.Count; $i++) {
    $num = $i + 1
    Write-Host "$num. $($allProfiles[$i])"
}

Write-Host ""
$choice = Read-Host "Enter 'all' to run for all profiles, or enter numbers separated by commas (e.g., 1,3,5)"

# Decide profiles to run
if ($choice -eq "all") {
    $profilesToRun = $allProfiles
} else {
    $selectedNumbers = $choice -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^\d+$' }
    $indices = $selectedNumbers | ForEach-Object { [int]$_ - 1 }

    # Validate numbers
    $profilesToRun = @()
    foreach ($index in $indices) {
        if ($index -ge 0 -and $index -lt $allProfiles.Count) {
            $profilesToRun += $allProfiles[$index]
        } else {
            Write-Host "Invalid number: $($index+1)" -ForegroundColor Red
        }
    }

    if ($profilesToRun.Count -eq 0) {
        Write-Host "No valid profiles selected. Exiting." -ForegroundColor Red
        return
    }
}

# Initialize results collection
$globalResults = @()
$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$csvPath = "StoppedEC2Instances_$timestamp.csv"
$errorLogPath = "EC2ScanErrors_$timestamp.log"

# Loop through selected profiles
foreach ($profile in $profilesToRun) {
    Write-Host "`n=== Processing profile: $profile ===" -ForegroundColor Cyan
    
    foreach ($region in $regions) {
        Write-Host "  Checking region: $region" -ForegroundColor DarkCyan
        
        try {
            # Get stopped instances from AWS CLI with detailed error handling
            $result = aws ec2 describe-instances `
                --filters "Name=instance-state-name,Values=stopped" `
                --region $region `
                --profile $profile `
                --output json 2>&1

            # Handle AWS CLI errors with detailed messages
            if ($LASTEXITCODE -ne 0) {
                $errorMessage = $result | Out-String
                
                # Known error patterns
                $knownErrors = @{
                    "could not be found" = "Region disabled or unavailable"
                    "not authorized to perform" = "Permission denied"
                    "InvalidClientTokenId" = "Invalid AWS credentials"
                    "AuthFailure" = "Authentication failure"
                    "OptInRequired" = "Region not enabled for this account"
                    "RequestLimitExceeded" = "API rate limit exceeded"
                }
                
                $errorType = "Unknown API Error"
                foreach ($key in $knownErrors.Keys) {
                    if ($errorMessage -match $key) {
                        $errorType = $knownErrors[$key]
                        break
                    }
                }
                
                $logMessage = "PROFILE: $profile | REGION: $region | ERROR: $errorType`nDETAILS: $errorMessage"
                $logMessage | Out-File -FilePath $errorLogPath -Append
                
                Write-Host "    $errorType - see error log for details" -ForegroundColor Red
                continue
            }

            # Process successful response
            $data = $result | ConvertFrom-Json
            
            if (-not $data.Reservations) {
                Write-Host "    No stopped instances found" -ForegroundColor DarkGray
                continue
            }

            # Process instances
            $instanceCount = 0
            foreach ($reservation in $data.Reservations) {
                foreach ($instance in $reservation.Instances) {
                    # Extract Name tag
                    $nameTag = $instance.Tags | Where-Object { $_.Key -eq "Name" } | Select-Object -ExpandProperty Value
                    
                    # Create result object
                    $instanceInfo = [PSCustomObject]@{
                        Profile        = $profile
                        Region         = $region
                        InstanceId     = $instance.InstanceId
                        InstanceName   = if ($nameTag) { $nameTag } else { "N/A" }
                        InstanceType   = $instance.InstanceType
                        LaunchTime     = $instance.LaunchTime
                        State          = $instance.State.Name
                        PrivateIp      = $instance.PrivateIpAddress
                        PublicIp       = if ($instance.PublicIpAddress) { $instance.PublicIpAddress } else { "N/A" }
                        VpcId          = $instance.VpcId
                        SubnetId       = $instance.SubnetId
                        Platform       = if ($instance.Platform) { $instance.Platform } else { "Linux/UNIX" }
                        KeyName        = if ($instance.KeyName) { $instance.KeyName } else { "N/A" }
                    }
                    
                    $globalResults += $instanceInfo
                    $instanceCount++
                }
            }
            
            Write-Host "    Found $instanceCount stopped instance(s)" -ForegroundColor Green
        }
        catch {
            $errorDetails = $_.Exception.Message
            $logMessage = "PROFILE: $profile | REGION: $region | ERROR: Processing Exception`nDETAILS: $errorDetails"
            $logMessage | Out-File -FilePath $errorLogPath -Append
            
            Write-Host "    Processing error: $errorDetails" -ForegroundColor Red
        }
        
        # Brief pause between regions
        Safe-Pause -sec 1
    }
    
    Write-Host "`n" + ('=' * 50)
}

# Export to CSV if results found
if ($globalResults.Count -gt 0) {
    $globalResults | Export-Csv -Path $csvPath -NoTypeInformation -Force
    Write-Host "`nExported $($globalResults.Count) stopped instances to CSV:" -ForegroundColor Cyan
    Write-Host (Resolve-Path $csvPath).Path -ForegroundColor Yellow
} else {
    Write-Host "`nNo stopped instances found across all profiles and regions" -ForegroundColor DarkYellow
}

# Show error log status
if (Test-Path $errorLogPath) {
    $errorCount = (Get-Content $errorLogPath | Measure-Object -Line).Lines
    Write-Host "`nEncountered $errorCount errors - full details in error log:" -ForegroundColor Red
    Write-Host (Resolve-Path $errorLogPath).Path -ForegroundColor Yellow
    
    # Show error summary
    Write-Host "`nError Summary:" -ForegroundColor Red
    Get-Content $errorLogPath | Select-String "PROFILE:" | Group-Object | ForEach-Object {
        $count = $_.Count
        $first = $_.Group[0] -split "ERROR: " | Select-Object -Last 1
        Write-Host "$count x $first" -ForegroundColor Red
    }
}

Write-Host "`nScript completed!" -ForegroundColor Green