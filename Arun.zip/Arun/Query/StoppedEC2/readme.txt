STOPPED EC2 INSTANCE SCANNER
===============================

WHAT IT DOES:
This tool scans your Amazon Web Services (AWS) accounts to find any EC2 instances 
(virtual servers) that are currently stopped. It checks multiple AWS accounts and 
regions, then creates a report showing all stopped instances with their details.

WHAT YOU NEED BEFORE RUNNING:
1. AWS CLI installed on your computer
2. AWS credentials configured (your AWS account access keys)
3. Proper permissions to view EC2 instances in your AWS accounts

HOW TO USE:
1. Double-click "StoppedInstance.bat" to run the tool
2. The tool will show you a list of your configured AWS accounts
3. Choose which accounts to scan:
   - Type "all" to scan all accounts
   - Type specific numbers (like "1,3,5") to scan only certain accounts
4. Press Enter and wait for the scan to complete

WHAT YOU GET:
- A CSV file named "StoppedEC2Instances_[date-time].csv" with details of all stopped instances
- An error log file if any problems occurred during scanning

CSV FILE CONTAINS:
- AWS Account (Profile)
- Region where the instance is located
- Instance ID
- Instance Name (if one was assigned)
- Instance Type (server size)
- When it was launched
- IP addresses
- Other technical details

TYPICAL USE CASES:
- Find forgotten stopped instances that might be costing money
- Audit which servers are not currently running
- Inventory management of your cloud resources
- Compliance reporting

NOTES:
- The tool only finds STOPPED instances, not running ones
- It checks US East (Virginia) and US West (Oregon) regions by default
- Each scan creates timestamped files so you won't overwrite previous reports
- If you see errors, check the error log file for details