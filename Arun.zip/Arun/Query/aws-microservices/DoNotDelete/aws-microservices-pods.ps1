<#
.SYNOPSIS
Discover AWS microservices across regions and profiles (READ-ONLY OPERATION)

.DESCRIPTION
This script performs safe, read-only discovery of AWS microservices including:
- EKS Clusters and Deployments
- ECS Services
- Lambda Functions
- API Gateway APIs
- App Runner Services
- Step Functions
- EKS Fargate Profiles

.NOTES
Features:
- Strict read-only operations (no modifications)
- Temporary resource cleanup
- Detailed error logging
- CSV export
- Multi-region/profile support
- IAM permission validation

Prerequisites:
- AWS CLI installed and configured
- PowerShell 5.1+
- kubectl (optional for EKS details)

Version: 2.0
Author: AWS Microservices Discovery Team
#>

param(
    [string[]]$Regions = @("us-east-1", "us-west-2"),
    [string]$OutputPath = ".\aws-microservices-report.csv",
    [int]$KubeConfigTimeout = 90,
    [int]$KubectlTimeout = 180
)

#region Initialization and Logging
function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = switch ($Level) {
        "ERROR" { "Red" }
        "WARNING" { "Yellow" }
        "SUCCESS" { "Green" }
        "DEBUG" { "Gray" }
        default { "White" }
    }
    Write-Host "[$timestamp] [$Level] $Message" -ForegroundColor $color
}

Write-Log "Starting AWS Microservices Discovery" "SUCCESS"
Write-Log "Operating in read-only mode - no resources will be modified" "INFO"
#endregion

#region Helper Functions
function Get-AWSProfiles {
    try {
        $configPath = "$env:USERPROFILE\.aws\config"
        if (Test-Path $configPath) {
            $profiles = @()
            Get-Content $configPath | ForEach-Object {
                if ($_ -match '^\[profile (.+)\]$') {
                    $profiles += $matches[1]
                } elseif ($_ -match '^\[default\]$') {
                    $profiles += "default"
                }
            }
            return $profiles | Sort-Object -Unique
        }
    } catch {
        Write-Log "Error reading AWS profiles: $($_.Exception.Message)" "ERROR"
    }
    return @()
}

function Test-AWSConnectivity {
    param([string]$Profile, [string]$Region)
    try {
        $result = aws sts get-caller-identity --profile $Profile --region $Region --output json 2>$null
        if ($LASTEXITCODE -ne 0) {
            Write-Log "Connectivity test failed for $Profile in $Region" "WARNING"
            return @{ Success = $false }
        }
        
        $identity = $result | ConvertFrom-Json
        Write-Log "Connected to AWS Account: $($identity.Account)" "SUCCESS"
        return @{
            Success = $true
            Account = $identity.Account
            UserId = $identity.UserId
            Arn = $identity.Arn
        }
    } catch {
        Write-Log "Connectivity test exception: $($_.Exception.Message)" "ERROR"
        return @{ Success = $false }
    }
}

function Test-KubectlAvailability {
    try {
        $null = Get-Command kubectl -ErrorAction Stop
        return $true
    } catch {
        Write-Log "kubectl not available (EKS details limited)" "WARNING"
        return $false
    }
}
#endregion

#region Service Discovery Functions
function Get-EKSServices {
    param([string]$Profile, [string]$Region)
    $services = @()
    try {
        Write-Log "Discovering EKS clusters in $Region..." "INFO"
        $clustersJson = aws eks list-clusters --profile $Profile --region $Region --output json 2>$null
        
        if ($LASTEXITCODE -ne 0) {
            Write-Log "EKS access denied. Required permission: eks:ListClusters" "ERROR"
            return $services
        }
        
        $clusters = ($clustersJson | ConvertFrom-Json).clusters
        if (-not $clusters -or $clusters.Count -eq 0) {
            Write-Log "No EKS clusters found in $Region" "INFO"
            return $services
        }
        
        Write-Log "Found $($clusters.Count) EKS clusters" "SUCCESS"
        $kubectlAvailable = Test-KubectlAvailability
        
        foreach ($cluster in $clusters) {
            Write-Log "Processing cluster: $cluster" "INFO"
            $clusterDetails = $null
            
            # Get cluster metadata
            try {
                $clusterInfoJson = aws eks describe-cluster --name $cluster --profile $Profile --region $Region --output json 2>$null
                if ($LASTEXITCODE -eq 0) {
                    $clusterDetails = ($clusterInfoJson | ConvertFrom-Json).cluster
                }
            } catch {
                Write-Log "Cluster description failed: $($_.Exception.Message)" "WARNING"
            }
            
            if ($kubectlAvailable) {
                $kubeconfigPath = "$env:TEMP\kubeconfig-$($cluster)-$(Get-Date -Format 'yyyyMMddHHmmss').yaml"
                try {
                    # Update kubeconfig (temporary file)
                    Write-Log "Creating temporary kubeconfig ($kubeconfigPath)" "DEBUG"
                    $null = aws eks update-kubeconfig --name $cluster `
                        --profile $Profile `
                        --region $Region `
                        --kubeconfig $kubeconfigPath `
                        2>&1 | Out-String
                    
                    if ($LASTEXITCODE -ne 0) {
                        throw "Kubeconfig creation failed"
                    }
                    
                    # Get deployments
                    Write-Log "Discovering deployments (Timeout: ${KubectlTimeout}s)..." "DEBUG"
                    $deploymentsOutput = kubectl get deployments --all-namespaces `
                        --kubeconfig $kubeconfigPath `
                        -o json `
                        --request-timeout=30s `
                        2>&1 | Out-String
                    
                    if ($LASTEXITCODE -ne 0) {
                        throw "Deployment discovery failed: $deploymentsOutput"
                    }
                    
                    $deploymentsObj = $deploymentsOutput | ConvertFrom-Json
                    Write-Log "Found $($deploymentsObj.items.Count) deployments" "INFO"
                    
                    foreach ($deployment in $deploymentsObj.items) {
                        $services += [PSCustomObject]@{
                            Profile = $Profile
                            Region = $Region
                            ServiceType = "EKS-Deployment"
                            ServiceName = $deployment.metadata.name
                            Namespace = $deployment.metadata.namespace
                            Cluster = $cluster
                            Replicas = $deployment.spec.replicas
                            Status = if ($deployment.status.readyReplicas -eq $deployment.spec.replicas) { 
                                        "Running" 
                                    } elseif ($deployment.status.readyReplicas -gt 0) { 
                                        "Partial" 
                                    } else { 
                                        "Stopped" 
                                    }
                            CreatedDate = $deployment.metadata.creationTimestamp
                        }
                    }
                } catch {
                    Write-Log "Detailed discovery failed for ${cluster}: $($_.Exception.Message)" "WARNING"
                    # Fallback to cluster-level info
                    if ($clusterDetails) {
                        $services += [PSCustomObject]@{
                            Profile = $Profile
                            Region = $Region
                            ServiceType = "EKS-Cluster"
                            ServiceName = $cluster
                            Namespace = "N/A"
                            Cluster = $cluster
                            Replicas = "Unknown"
                            Status = $clusterDetails.status
                            CreatedDate = $clusterDetails.createdAt
                        }
                    }
                } finally {
                    # Cleanup temp file
                    if (Test-Path $kubeconfigPath) {
                        Remove-Item $kubeconfigPath -Force -ErrorAction SilentlyContinue
                        Write-Log "Cleaned up temporary kubeconfig" "DEBUG"
                    }
                }
            } else {
                # Kubectl not available - use basic info
                if ($clusterDetails) {
                    $services += [PSCustomObject]@{
                        Profile = $Profile
                        Region = $Region
                        ServiceType = "EKS-Cluster"
                        ServiceName = $cluster
                        Namespace = "N/A"
                        Cluster = $cluster
                        Replicas = "Unknown"
                        Status = $clusterDetails.status
                        CreatedDate = $clusterDetails.createdAt
                    }
                }
            }
        }
    } catch {
        Write-Log "Critical EKS error: $($_.Exception.Message)" "ERROR"
    }
    return $services
}

function Get-EKSFargateProfiles {
    param([string]$Profile, [string]$Region)
    $services = @()
    try {
        $clustersJson = aws eks list-clusters --profile $Profile --region $Region --output json 2>$null
        if ($LASTEXITCODE -ne 0) { return $services }
        
        $clusters = ($clustersJson | ConvertFrom-Json).clusters
        foreach ($cluster in $clusters) {
            $profilesJson = aws eks list-fargate-profiles --cluster-name $cluster --profile $Profile --region $Region --output json 2>$null
            if ($LASTEXITCODE -eq 0) {
                $profiles = ($profilesJson | ConvertFrom-Json).fargateProfileNames
                foreach ($profileName in $profiles) {
                    $services += [PSCustomObject]@{
                        Profile = $Profile
                        Region = $Region
                        ServiceType = "EKS-Fargate"
                        ServiceName = $profileName
                        Namespace = "N/A"
                        Cluster = $cluster
                        Replicas = "N/A"
                        Status = "Active"
                        CreatedDate = (Get-Date).ToString("yyyy-MM-dd")
                    }
                }
            }
        }
    } catch {
        Write-Log "EKS Fargate discovery error: $($_.Exception.Message)" "WARNING"
    }
    return $services
}

function Get-ECSServices {
    param([string]$Profile, [string]$Region)
    $services = @()
    try {
        Write-Log "Discovering ECS services in $Region..." "INFO"
        $clustersJson = aws ecs list-clusters --profile $Profile --region $Region --output json 2>$null
        if ($LASTEXITCODE -eq 0) {
            $clusters = ($clustersJson | ConvertFrom-Json).clusterArns
            foreach ($cluster in $clusters) {
                $clusterName = ($cluster -split "/")[-1]
                $servicesJson = aws ecs list-services --cluster $clusterName --profile $Profile --region $Region --output json 2>$null
                if ($LASTEXITCODE -eq 0) {
                    $serviceArns = ($servicesJson | ConvertFrom-Json).serviceArns
                    if ($serviceArns.Count -gt 0) {
                        $serviceDetailsJson = aws ecs describe-services --cluster $clusterName --services $serviceArns --profile $Profile --region $Region --output json 2>$null
                        if ($LASTEXITCODE -eq 0) {
                            $serviceDetails = ($serviceDetailsJson | ConvertFrom-Json).services
                            foreach ($service in $serviceDetails) {
                                $services += [PSCustomObject]@{
                                    Profile = $Profile
                                    Region = $Region
                                    ServiceType = "ECS-Service"
                                    ServiceName = $service.serviceName
                                    Namespace = "N/A"
                                    Cluster = $clusterName
                                    Replicas = $service.desiredCount
                                    Status = $service.status
                                    CreatedDate = $service.createdAt
                                }
                            }
                        }
                    }
                }
            }
        }
    } catch {
        Write-Log "ECS discovery error: $($_.Exception.Message)" "WARNING"
    }
    return $services
}

function Get-LambdaFunctions {
    param([string]$Profile, [string]$Region)
    $services = @()
    try {
        Write-Log "Discovering Lambda functions in $Region..." "INFO"
        $functionsJson = aws lambda list-functions --profile $Profile --region $Region --output json 2>$null
        if ($LASTEXITCODE -eq 0) {
            $functions = ($functionsJson | ConvertFrom-Json).Functions
            foreach ($function in $functions) {
                $services += [PSCustomObject]@{
                    Profile = $Profile
                    Region = $Region
                    ServiceType = "Lambda"
                    ServiceName = $function.FunctionName
                    Namespace = "N/A"
                    Cluster = "N/A"
                    Replicas = "N/A"
                    Status = $function.State
                    CreatedDate = $function.LastModified
                }
            }
        }
    } catch {
        Write-Log "Lambda discovery error: $($_.Exception.Message)" "WARNING"
    }
    return $services
}

function Get-APIGatewayAPIs {
    param([string]$Profile, [string]$Region)
    $services = @()
    try {
        Write-Log "Discovering API Gateway APIs in $Region..." "INFO"
        
        # REST APIs (v1)
        $restApisJson = aws apigateway get-rest-apis --profile $Profile --region $Region --output json 2>$null
        if ($LASTEXITCODE -eq 0) {
            $restApis = ($restApisJson | ConvertFrom-Json).items
            foreach ($api in $restApis) {
                $services += [PSCustomObject]@{
                    Profile = $Profile
                    Region = $Region
                    ServiceType = "API-Gateway-REST"
                    ServiceName = $api.name
                    Namespace = "N/A"
                    Cluster = "N/A"
                    Replicas = "N/A"
                    Status = "Active"
                    CreatedDate = $api.createdDate
                }
            }
        }

        # HTTP APIs (v2)
        $httpApisJson = aws apigatewayv2 get-apis --profile $Profile --region $Region --output json 2>$null
        if ($LASTEXITCODE -eq 0) {
            $httpApis = ($httpApisJson | ConvertFrom-Json).Items
            foreach ($api in $httpApis) {
                $services += [PSCustomObject]@{
                    Profile = $Profile
                    Region = $Region
                    ServiceType = "API-Gateway-HTTP"
                    ServiceName = $api.Name
                    Namespace = "N/A"
                    Cluster = "N/A"
                    Replicas = "N/A"
                    Status = "Active"
                    CreatedDate = $api.CreatedDate
                }
            }
        }
    } catch {
        Write-Log "API Gateway discovery error: $($_.Exception.Message)" "WARNING"
    }
    return $services
}

function Get-AppRunnerServices {
    param([string]$Profile, [string]$Region)
    $services = @()
    try {
        Write-Log "Discovering App Runner services in $Region..." "INFO"
        $appRunnerJson = aws apprunner list-services --profile $Profile --region $Region --output json 2>$null
        if ($LASTEXITCODE -eq 0) {
            $appRunnerServices = ($appRunnerJson | ConvertFrom-Json).ServiceSummaryList
            foreach ($service in $appRunnerServices) {
                $services += [PSCustomObject]@{
                    Profile = $Profile
                    Region = $Region
                    ServiceType = "App-Runner"
                    ServiceName = $service.ServiceName
                    Namespace = "N/A"
                    Cluster = "N/A"
                    Replicas = "N/A"
                    Status = $service.Status
                    CreatedDate = $service.CreatedAt
                }
            }
        }
    } catch {
        Write-Log "App Runner discovery error: $($_.Exception.Message)" "WARNING"
    }
    return $services
}

function Get-StepFunctions {
    param([string]$Profile, [string]$Region)
    $services = @()
    try {
        Write-Log "Discovering Step Functions in $Region..." "INFO"
        $stateMachinesJson = aws stepfunctions list-state-machines --profile $Profile --region $Region --output json 2>$null
        if ($LASTEXITCODE -eq 0) {
            $stateMachines = ($stateMachinesJson | ConvertFrom-Json).stateMachines
            foreach ($sm in $stateMachines) {
                $services += [PSCustomObject]@{
                    Profile = $Profile
                    Region = $Region
                    ServiceType = "Step-Function"
                    ServiceName = $sm.name
                    Namespace = "N/A"
                    Cluster = "N/A"
                    Replicas = "N/A"
                    Status = "Active"
                    CreatedDate = $sm.creationDate
                }
            }
        }
    } catch {
        Write-Log "Step Functions discovery error: $($_.Exception.Message)" "WARNING"
    }
    return $services
}
#endregion

#region Main Execution
try {
    # Get AWS profiles
    $allProfiles = Get-AWSProfiles
    if ($allProfiles.Count -eq 0) {
        Write-Log "No AWS profiles found. Configure AWS CLI first." "ERROR"
        exit 1
    }

    # Profile selection with numbering
    Write-Host "`nAvailable AWS CLI profiles:" -ForegroundColor Cyan
    for ($i = 0; $i -lt $allProfiles.Count; $i++) {
        $num = $i + 1
        Write-Host "$num. $($allProfiles[$i])"
    }
    Write-Host ""

    $choice = Read-Host "Enter 'all' to run for all profiles, or enter numbers separated by commas (e.g., 1,3,5)"

    # Determine selected profiles
    $selectedProfiles = @()
    if ($choice -eq "all") {
        $selectedProfiles = $allProfiles
    }
    else {
        $numbers = $choice -split ","
        foreach ($num in $numbers) {
            $index = [int]$num.Trim() - 1
            if ($index -ge 0 -and $index -lt $allProfiles.Count) {
                $selectedProfiles += $allProfiles[$index]
            }
        }
    }

    Write-Log "Selected regions: $($Regions -join ', ')" "SUCCESS"
    Write-Log "Selected profiles: $($selectedProfiles -join ', ')" "SUCCESS"

    # Initialize results
    $allServices = @()
    $summary = @{}

    foreach ($profile in $selectedProfiles) {
        foreach ($region in $Regions) {
            Write-Log "Processing $profile in $region" "INFO"
            
            # Verify connectivity
            $connectivity = Test-AWSConnectivity -Profile $profile -Region $region
            if (-not $connectivity.Success) {
                Write-Log "Skipping $region due to connectivity issues" "WARNING"
                continue
            }

            # Discover services
            $services = @()
            $services += Get-EKSServices -Profile $profile -Region $region
            $services += Get-EKSFargateProfiles -Profile $profile -Region $region
            $services += Get-ECSServices -Profile $profile -Region $region
            $services += Get-LambdaFunctions -Profile $profile -Region $region
            $services += Get-APIGatewayAPIs -Profile $profile -Region $region
            $services += Get-AppRunnerServices -Profile $profile -Region $region
            $services += Get-StepFunctions -Profile $profile -Region $region

            $allServices += $services
            $count = $services.Count
            Write-Log "Discovered $count services in $region" "SUCCESS"

            # Update summary
            $key = "$profile-$region"
            $summary[$key] = @{
                Profile = $profile
                Region = $region
                Account = $connectivity.Account
                TotalServices = $count
                ByType = ($services | Group-Object ServiceType | ForEach-Object { "$($_.Name): $($_.Count)" }) -join ", "
            }
        }
    }

    # Display summary
    if ($summary.Count -gt 0) {
        Write-Host "`nDiscovery Summary" -ForegroundColor Cyan
        Write-Host "================" -ForegroundColor Cyan
        $totalCount = 0
        $summary.Values | ForEach-Object {
            $totalCount += $_.TotalServices
            Write-Host "Profile: $($_.Profile) | Region: $($_.Region) | Account: $($_.Account)" -ForegroundColor Yellow
            Write-Host "  Total Services: $($_.TotalServices)" -ForegroundColor White
            Write-Host "  By Type: $($_.ByType)" -ForegroundColor Gray
            Write-Host ""
        }
        Write-Host "TOTAL MICROSERVICES DISCOVERED: $totalCount" -ForegroundColor Green
    } else {
        Write-Log "No services discovered across all regions/profiles" "WARNING"
    }

    # Export results
    if ($allServices.Count -gt 0) {
        $allServices | Export-Csv -Path $OutputPath -NoTypeInformation -Force
        Write-Log "Report exported to: $OutputPath" "SUCCESS"
        
        # Type breakdown
        Write-Host "`nService Type Distribution:" -ForegroundColor Cyan
        $allServices | Group-Object ServiceType | Sort-Object Count -Descending | ForEach-Object {
            Write-Host ("- {0}: {1} services" -f $_.Name.PadRight(20), $_.Count)
        }
    }
}
catch {
    Write-Log "Critical error: $($_.Exception.Message)" "ERROR"
    Write-Log "Stack Trace: $($_.ScriptStackTrace)" "DEBUG"
}
finally {
    Write-Log "Discovery completed. Cleaned up all temporary resources." "SUCCESS"
}
#endregion