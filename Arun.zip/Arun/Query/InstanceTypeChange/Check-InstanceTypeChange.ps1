[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$InstanceId
)

<#
.SYNOPSIS
    Check CloudTrail logs for EC2 instance type change events.

.DESCRIPTION
    This script queries AWS CloudTrail to find ModifyInstanceAttribute events
    that indicate instance type changes. It searches the maximum available
    CloudTrail history (90 days) and provides detailed information about
    who made the change, when it occurred, and the old/new instance types.

.PARAMETER InstanceId
    Instance ID to check (e.g., i-1234567890abcdef0)

.EXAMPLE
    .\Check-InstanceTypeChange.ps1

.EXAMPLE
    .\Check-InstanceTypeChange.ps1 -InstanceId i-1234567890abcdef0
#>

function Get-AWSProfiles {
    try {
        $profiles = aws configure list-profiles 2>$null
        if ($LASTEXITCODE -ne 0) {
            Write-Warning "AWS CLI not found or no profiles configured"
            return @()
        }
        return $profiles | Where-Object { $_ -ne "" }
    }
    catch {
        Write-Warning "Error getting AWS profiles: $($_.Exception.Message)"
        return @()
    }
}

function Get-InstanceTypeChangeEvents {
    param(
        [string]$InstanceId,
        [string]$AwsProfile,
        [string]$Region
    )

    # CloudTrail lookup-events supports max 90 days
    Write-Host "  Querying CloudTrail for instance type changes..." -ForegroundColor Gray

    $allEvents = @()

    try {
        # APPROACH 1: Query by EventName=ModifyInstanceAttribute (more reliable for instance type changes)
        Write-Host "    Method 1: Searching all ModifyInstanceAttribute events..." -ForegroundColor Gray
        $cmd1 = "aws cloudtrail lookup-events --lookup-attributes AttributeKey=EventName,AttributeValue=ModifyInstanceAttribute --max-items 100 --profile $AwsProfile --region $Region --output json"
        $result1 = Invoke-Expression $cmd1 2>&1

        if ($LASTEXITCODE -eq 0 -and $result1) {
            $events1 = $result1 | ConvertFrom-Json
            if ($events1 -and $events1.Events) {
                Write-Host "    Found $($events1.Events.Count) ModifyInstanceAttribute events" -ForegroundColor Gray

                # Filter for our specific instance ID
                foreach ($event in $events1.Events) {
                    try {
                        $eventDetails = $event.CloudTrailEvent | ConvertFrom-Json
                        if ($eventDetails.requestParameters.instanceId -eq $InstanceId) {
                            $allEvents += $event
                        }
                    }
                    catch { continue }
                }
                Write-Host "    Filtered to $($allEvents.Count) events for instance $InstanceId" -ForegroundColor Green
            }
        }

        # APPROACH 2: Query by ResourceName (for other events like RunInstances, StopInstances, etc.)
        Write-Host "    Method 2: Searching by ResourceName (instance ID)..." -ForegroundColor Gray
        $cmd2 = "aws cloudtrail lookup-events --lookup-attributes AttributeKey=ResourceName,AttributeValue=$InstanceId --max-items 50 --profile $AwsProfile --region $Region --output json"
        $result2 = Invoke-Expression $cmd2 2>&1

        if ($LASTEXITCODE -eq 0 -and $result2) {
            $events2 = $result2 | ConvertFrom-Json
            if ($events2 -and $events2.Events) {
                Write-Host "    Found $($events2.Events.Count) events by ResourceName" -ForegroundColor Gray

                # Add events that aren't already in our list
                foreach ($event in $events2.Events) {
                    $isDuplicate = $false
                    foreach ($existingEvent in $allEvents) {
                        if ($existingEvent.EventId -eq $event.EventId) {
                            $isDuplicate = $true
                            break
                        }
                    }
                    if (-not $isDuplicate) {
                        $allEvents += $event
                    }
                }
            }
        }

        if ($allEvents.Count -eq 0) {
            Write-Host "  No events found in $Region" -ForegroundColor Red
            return @()
        }

        # Show summary
        $eventNames = $allEvents | Select-Object -ExpandProperty EventName -Unique
        Write-Host "  Total unique events: $($allEvents.Count)" -ForegroundColor Cyan
        Write-Host "  Event types: $($eventNames -join ', ')" -ForegroundColor Gray

        return $allEvents
    }
    catch {
        Write-Warning "  Error querying CloudTrail in ${Region}: $($_.Exception.Message)"
        return @()
    }
}

function Parse-InstanceTypeChange {
    param($CloudTrailEvent, [switch]$ShowAll)

    try {
        $eventDetails = $CloudTrailEvent.CloudTrailEvent | ConvertFrom-Json

        $changeInfo = @{
            EventName = $CloudTrailEvent.EventName
            EventTime = $CloudTrailEvent.EventTime
            Username = $CloudTrailEvent.Username
            SourceIPAddress = if ($eventDetails.sourceIPAddress) { $eventDetails.sourceIPAddress } else { "N/A" }
            UserAgent = if ($eventDetails.userAgent) { $eventDetails.userAgent } else { "N/A" }
            OldInstanceType = $null
            NewInstanceType = $null
            InstanceId = $null
            ErrorMessage = $null
            EventDescription = $null
        }

        # Extract instance ID
        if ($eventDetails.requestParameters) {
            if ($eventDetails.requestParameters.instanceId) {
                $changeInfo.InstanceId = $eventDetails.requestParameters.instanceId
            }
            elseif ($eventDetails.requestParameters.instancesSet -and $eventDetails.requestParameters.instancesSet.items) {
                $changeInfo.InstanceId = ($eventDetails.requestParameters.instancesSet.items | Select-Object -First 1).instanceId
            }
        }

        # Check for ModifyInstanceAttribute (instance type change)
        if ($CloudTrailEvent.EventName -eq 'ModifyInstanceAttribute') {
            # Try different possible structures
            if ($eventDetails.requestParameters.instanceType) {
                if ($eventDetails.requestParameters.instanceType.value) {
                    $changeInfo.NewInstanceType = $eventDetails.requestParameters.instanceType.value
                } else {
                    $changeInfo.NewInstanceType = $eventDetails.requestParameters.instanceType
                }
                $changeInfo.OldInstanceType = "See previous RunInstances event"
            }
            elseif ($eventDetails.requestParameters.attribute -eq 'instanceType') {
                $changeInfo.NewInstanceType = if ($eventDetails.requestParameters.value) { $eventDetails.requestParameters.value } else { "Unknown" }
                $changeInfo.OldInstanceType = "See previous RunInstances event"
            }
        }

        # Check for RunInstances (initial instance type)
        if ($CloudTrailEvent.EventName -eq 'RunInstances') {
            if ($eventDetails.requestParameters.instanceType) {
                $changeInfo.NewInstanceType = $eventDetails.requestParameters.instanceType
                $changeInfo.OldInstanceType = "N/A (New Instance)"
            }
        }

        # Add descriptions for other event types
        switch ($CloudTrailEvent.EventName) {
            'CreateImage' { $changeInfo.EventDescription = "AMI created from this instance" }
            'AssumeRole' { $changeInfo.EventDescription = "Role assumed (possibly for automated action)" }
            'StopInstances' { $changeInfo.EventDescription = "Instance stopped" }
            'StartInstances' { $changeInfo.EventDescription = "Instance started" }
            'RebootInstances' { $changeInfo.EventDescription = "Instance rebooted" }
            'TerminateInstances' { $changeInfo.EventDescription = "Instance terminated" }
        }

        # Check for errors
        if ($eventDetails.errorCode) {
            $changeInfo.ErrorMessage = "$($eventDetails.errorCode): $($eventDetails.errorMessage)"
        }

        return $changeInfo
    }
    catch {
        Write-Warning "    Error parsing event: $($_.Exception.Message)"
        return $null
    }
}

function Get-CurrentInstanceType {
    param(
        [string]$InstanceId,
        [string]$AwsProfile,
        [string]$Region
    )

    try {
        $cmd = "aws ec2 describe-instances --instance-ids $InstanceId --profile $AwsProfile --region $Region --output json 2>$null"
        $result = Invoke-Expression $cmd

        if ($LASTEXITCODE -eq 0 -and $result) {
            $instanceData = $result | ConvertFrom-Json
            if ($instanceData.Reservations -and $instanceData.Reservations.Count -gt 0) {
                $instance = $instanceData.Reservations[0].Instances[0]
                return @{
                    InstanceType = $instance.InstanceType
                    State = $instance.State.Name
                }
            }
        }
    }
    catch {
        Write-Verbose "Could not retrieve current instance info: $($_.Exception.Message)"
    }

    return $null
}

function Trace-InstanceTypeChanges {
    param(
        [string]$InstanceId,
        [string]$AwsProfile,
        [string]$Region
    )

    Write-Host "Profile: $AwsProfile | Region: $Region" -ForegroundColor Yellow

    # Get current instance info
    $currentInfo = Get-CurrentInstanceType -InstanceId $InstanceId -AwsProfile $AwsProfile -Region $Region
    if ($currentInfo) {
        Write-Host "  Current Instance Type: $($currentInfo.InstanceType) | State: $($currentInfo.State)" -ForegroundColor Cyan
    }

    # Get CloudTrail events (max 90 days)
    $events = Get-InstanceTypeChangeEvents -InstanceId $InstanceId -AwsProfile $AwsProfile -Region $Region

    if ($events.Count -eq 0) {
        Write-Host "  No relevant events found" -ForegroundColor Red
        return $null
    }

    # Parse all events
    $parsedEvents = @()
    Write-Host "  Parsing events..." -ForegroundColor Gray
    foreach ($event in $events) {
        $parsed = Parse-InstanceTypeChange -CloudTrailEvent $event -ShowAll
        if ($parsed) {
            $parsedEvents += $parsed
        }
    }

    if ($parsedEvents.Count -eq 0) {
        Write-Host "  No events could be parsed" -ForegroundColor Yellow
        return $null
    }

    Write-Host "  Parsed $($parsedEvents.Count) events" -ForegroundColor Green

    # Count actual type changes
    $typeChangeCount = ($parsedEvents | Where-Object { $_.EventName -eq 'ModifyInstanceAttribute' }).Count
    if ($typeChangeCount -eq 0) {
        $ninetyDaysAgo = (Get-Date).AddDays(-90)
        Write-Host ""
        Write-Host "  ╔════════════════════════════════════════════════════════════╗" -ForegroundColor Red
        Write-Host "  ║  NO INSTANCE TYPE CHANGE EVENTS FOUND                      ║" -ForegroundColor Red
        Write-Host "  ╚════════════════════════════════════════════════════════════╝" -ForegroundColor Red
        Write-Host ""
        Write-Host "  Possible reasons:" -ForegroundColor Yellow
        Write-Host "    1. Instance type changed BEFORE $($ninetyDaysAgo.ToString('yyyy-MM-dd'))" -ForegroundColor White
        Write-Host "       (beyond CloudTrail's 90-day event history retention)" -ForegroundColor Gray
        Write-Host ""
        Write-Host "    2. Instance was created with current type (never changed)" -ForegroundColor White
        Write-Host ""
        Write-Host "    3. Change not logged (unlikely if CloudTrail is enabled)" -ForegroundColor White
        Write-Host ""
        Write-Host "  To find older events:" -ForegroundColor Cyan
        Write-Host "    - Check CloudTrail S3 bucket logs (if configured)" -ForegroundColor Gray
        Write-Host "    - Query CloudTrail Lake (if enabled)" -ForegroundColor Gray
        Write-Host ""
        Write-Host "  Showing all available events for this instance:" -ForegroundColor Cyan
        Write-Host ""
    } else {
        Write-Host "  ✓ Found $typeChangeCount instance type change event(s)!" -ForegroundColor Green
    }

    return @{
        Success = $true
        InstanceId = $InstanceId
        Profile = $AwsProfile
        Region = $Region
        CurrentInstanceType = if ($currentInfo) { $currentInfo.InstanceType } else { "Unknown" }
        CurrentState = if ($currentInfo) { $currentInfo.State } else { "Unknown" }
        Events = $parsedEvents | Sort-Object EventTime
    }
}

# Main script execution
Write-Host "=== EC2 Instance Type Change Checker ===" -ForegroundColor Magenta
Write-Host ""

# Calculate 90-day threshold
$ninetyDaysAgo = (Get-Date).AddDays(-90)
Write-Host "CloudTrail Event History Limitation:" -ForegroundColor Yellow
Write-Host "  - Searches last 90 days only (AWS limitation)" -ForegroundColor Gray
Write-Host "  - Events before $($ninetyDaysAgo.ToString('yyyy-MM-dd')) are NOT available" -ForegroundColor Gray
Write-Host "  - For older events, check CloudTrail S3 bucket (if configured)" -ForegroundColor Gray
Write-Host ""

# Get Instance ID if not provided
if ([string]::IsNullOrWhiteSpace($InstanceId)) {
    $InstanceId = Read-Host "Enter Instance ID (e.g., i-1234567890abcdef0)"
    if ([string]::IsNullOrWhiteSpace($InstanceId)) {
        Write-Error "No Instance ID provided."
        exit 1
    }
    $InstanceId = $InstanceId.Trim()
}

Write-Host "Instance ID: $InstanceId" -ForegroundColor Cyan
Write-Host ""

# Get available profiles from AWS CLI
$availableProfiles = Get-AWSProfiles
if ($availableProfiles.Count -eq 0) {
    Write-Error "No AWS profiles found. Please configure AWS CLI profiles first."
    exit 1
}

# Auto-select default profile or prompt if multiple
if ($availableProfiles.Count -eq 1) {
    $selectedProfile = $availableProfiles[0]
    Write-Host "Using AWS profile: $selectedProfile" -ForegroundColor Cyan
} else {
    Write-Host "Available AWS CLI profiles:" -ForegroundColor Cyan
    for ($i = 0; $i -lt $availableProfiles.Count; $i++) {
        $num = $i + 1
        Write-Host "$num. $($availableProfiles[$i])"
    }
    Write-Host ""
    $choice = Read-Host "Enter profile number (default: 1)"

    if ([string]::IsNullOrWhiteSpace($choice)) {
        $choice = "1"
    }

    if ($choice -match '^\d+$') {
        $index = [int]$choice - 1
        if ($index -ge 0 -and $index -lt $availableProfiles.Count) {
            $selectedProfile = $availableProfiles[$index]
        } else {
            Write-Error "Invalid profile selection."
            exit 1
        }
    } else {
        Write-Error "Invalid input."
        exit 1
    }

    Write-Host "Using AWS profile: $selectedProfile" -ForegroundColor Cyan
}

# Detect instance region
Write-Host ""
Write-Host "Detecting instance region..." -ForegroundColor Gray

$commonRegions = @('us-east-1', 'us-east-2', 'us-west-1', 'us-west-2', 'eu-west-1', 'eu-central-1', 'ap-southeast-1', 'ap-northeast-1')
$detectedRegion = $null

foreach ($region in $commonRegions) {
    try {
        $cmd = "aws ec2 describe-instances --instance-ids $InstanceId --profile $selectedProfile --region $region --output json 2>$null"
        $result = Invoke-Expression $cmd

        if ($LASTEXITCODE -eq 0 -and $result) {
            $detectedRegion = $region
            Write-Host "Instance found in region: $region" -ForegroundColor Green
            break
        }
    }
    catch {
        continue
    }
}

if (-not $detectedRegion) {
    Write-Warning "Could not auto-detect region. Please select manually:"
    for ($i = 0; $i -lt $commonRegions.Count; $i++) {
        $num = $i + 1
        Write-Host "$num. $($commonRegions[$i])"
    }
    Write-Host ""
    $choice = Read-Host "Enter region number (default: 1)"

    if ([string]::IsNullOrWhiteSpace($choice)) {
        $choice = "1"
    }

    if ($choice -match '^\d+$') {
        $index = [int]$choice - 1
        if ($index -ge 0 -and $index -lt $commonRegions.Count) {
            $detectedRegion = $commonRegions[$index]
        } else {
            Write-Error "Invalid region selection."
            exit 1
        }
    } else {
        Write-Error "Invalid input."
        exit 1
    }
}

Write-Host ""
Write-Host "=== Searching CloudTrail Events ===" -ForegroundColor Magenta

# Execute tracing
$result = Trace-InstanceTypeChanges -InstanceId $InstanceId -AwsProfile $selectedProfile -Region $detectedRegion

Write-Host ""

# Display results
Write-Host "=== RESULTS ===" -ForegroundColor Magenta

if (-not $result) {
    Write-Host "No instance type change events found in CloudTrail (last 90 days)." -ForegroundColor Red
    exit 0
}

Write-Host "Instance ID: $($result.InstanceId)" -ForegroundColor Cyan
Write-Host "Profile: $($result.Profile) | Region: $($result.Region)" -ForegroundColor Yellow
Write-Host "Current Type: $($result.CurrentInstanceType) | State: $($result.CurrentState)" -ForegroundColor Green
Write-Host ""
Write-Host "Event History (newest first):" -ForegroundColor White

$sortedEvents = $result.Events | Sort-Object EventTime -Descending

foreach ($event in $sortedEvents) {
    Write-Host "  ----------------------------------------" -ForegroundColor DarkGray

    # Highlight ModifyInstanceAttribute events
    if ($event.EventName -eq 'ModifyInstanceAttribute') {
        Write-Host "  >>> INSTANCE TYPE CHANGE <<<" -ForegroundColor Green -BackgroundColor Black
    }

    Write-Host "  Event: $($event.EventName)" -ForegroundColor Cyan
    Write-Host "  Time: $($event.EventTime)" -ForegroundColor Gray
    Write-Host "  User: $($event.Username)" -ForegroundColor Gray
    Write-Host "  Source IP: $($event.SourceIPAddress)" -ForegroundColor Gray
    Write-Host "  User Agent: $($event.UserAgent)" -ForegroundColor Gray

    if ($event.EventName -eq 'ModifyInstanceAttribute') {
        Write-Host "  Instance Type Change:" -ForegroundColor Yellow
        Write-Host "    Old Type: $($event.OldInstanceType)" -ForegroundColor Red
        Write-Host "    New Type: $($event.NewInstanceType)" -ForegroundColor Green
    }
    elseif ($event.EventName -eq 'RunInstances') {
        Write-Host "  Initial Instance Type: $($event.NewInstanceType)" -ForegroundColor Green
    }
    elseif ($event.EventDescription) {
        Write-Host "  Description: $($event.EventDescription)" -ForegroundColor Gray
    }

    if ($event.ErrorMessage) {
        Write-Host "  Error: $($event.ErrorMessage)" -ForegroundColor Red
    }
    Write-Host ""
}

Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Magenta
Write-Host "                        SUMMARY" -ForegroundColor Magenta
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Magenta
Write-Host "Total events found: $($result.Events.Count)" -ForegroundColor Cyan
$typeChanges = $result.Events | Where-Object { $_.EventName -eq 'ModifyInstanceAttribute' }
if ($typeChanges.Count -gt 0) {
    Write-Host "Instance type changes: $($typeChanges.Count) ✓" -ForegroundColor Green
} else {
    Write-Host "Instance type changes: 0 (see reasons above)" -ForegroundColor Yellow
}
Write-Host ""
Write-Host "If your instance type changed in August and it's now October," -ForegroundColor Yellow
Write-Host "the event is beyond the 90-day CloudTrail retention window." -ForegroundColor Yellow
