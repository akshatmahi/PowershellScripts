================================================================================
              EC2 Instance Type Change Checker - README
================================================================================

OVERVIEW
--------
This PowerShell script queries AWS CloudTrail to track and identify EC2 instance
type changes. It searches through CloudTrail event history (up to 90 days) to
find ModifyInstanceAttribute events and other relevant instance activities.

AUTHOR: Arun
PURPOSE: Audit and investigate when and who changed an EC2 instance type


PREREQUISITES
-------------
1. Windows PowerShell 5.1 or later (or PowerShell Core 7+)
2. AWS CLI installed and configured
3. AWS CLI profiles configured with appropriate credentials
4. IAM permissions required:
   - cloudtrail:LookupEvents
   - ec2:DescribeInstances


USAGE
-----
Basic usage (interactive prompts):
  .\Check-InstanceTypeChange.ps1

With instance ID parameter:
  .\Check-InstanceTypeChange.ps1 -InstanceId i-1234567890abcdef0


WHAT IT DOES
------------
1. Prompts for EC2 Instance ID (if not provided as parameter)
2. Displays available AWS CLI profiles and allows selection
3. Auto-detects the instance's AWS region
4. Queries CloudTrail for instance-related events:
   - ModifyInstanceAttribute (instance type changes)
   - RunInstances (instance creation)
   - StopInstances, StartInstances, RebootInstances
   - TerminateInstances
5. Displays current instance type and state
6. Shows detailed event history with:
   - Who made the change (IAM user/role)
   - When it occurred
   - Source IP address
   - Old and new instance types
   - User agent information


OUTPUT INFORMATION
------------------
The script provides:
- Current instance type and state
- Total events found (last 90 days)
- Detailed event log sorted by date (newest first)
- Highlights actual instance type change events
- Summary of findings


IMPORTANT LIMITATIONS
---------------------
* CloudTrail Event History: Only last 90 DAYS
  - AWS CloudTrail lookup-events API is limited to 90 days
  - Events older than 90 days will NOT appear
  - If your instance type changed more than 90 days ago, it won't be found

* For older events:
  - Check CloudTrail S3 bucket logs (if CloudTrail logging to S3 is enabled)
  - Query CloudTrail Lake (if configured)
  - Check AWS Config history (if enabled)


TROUBLESHOOTING
---------------
Issue: "AWS CLI not found or no profiles configured"
Fix:   Install AWS CLI and run 'aws configure' to set up profiles

Issue: "No events found"
Reasons:
  1. Instance type changed more than 90 days ago
  2. Instance was created with current type (never changed)
  3. CloudTrail is not enabled in the region
  4. Insufficient IAM permissions

Issue: "Could not auto-detect region"
Fix:   Manually select the correct region from the list

Issue: Script fails with permission errors
Fix:   Ensure your AWS profile has cloudtrail:LookupEvents permission


EXAMPLE OUTPUT
--------------
=== EC2 Instance Type Change Checker ===

CloudTrail Event History Limitation:
  - Searches last 90 days only (AWS limitation)
  - Events before 2024-07-27 are NOT available

Instance ID: i-0123456789abcdef0
Using AWS profile: production

=== Searching CloudTrail Events ===
Profile: production | Region: us-east-1
  Current Instance Type: t3.large | State: running
  Querying CloudTrail for instance type changes...
  Found 1 ModifyInstanceAttribute events

=== RESULTS ===
  ----------------------------------------
  >>> INSTANCE TYPE CHANGE <<<
  Event: ModifyInstanceAttribute
  Time: 2024-09-15T14:32:10Z
  User: arn:aws:iam::123456789012:user/admin
  Source IP: 203.0.113.42
  Instance Type Change:
    Old Type: t3.medium
    New Type: t3.large


SECURITY CONSIDERATIONS
------------------------
- The script queries CloudTrail which may incur minimal AWS API costs
- No modifications are made to any AWS resources (read-only operations)
- Credentials are accessed through AWS CLI profiles (not stored in script)
- All AWS API calls are logged in CloudTrail


SCRIPT DETAILS
--------------
Script Name:     Check-InstanceTypeChange.ps1
Language:        PowerShell
AWS Services:    CloudTrail, EC2
API Methods:     cloudtrail lookup-events, ec2 describe-instances


================================================================================
                            END OF README
================================================================================
